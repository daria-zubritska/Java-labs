import java.util.Random;

public class Particle {
	private double rx, ry; // position
	private double vx, vy; // velocity
	private final double radius; // radius
	private final double mass; // mass
	public int count; // number of collisions

	Random rand = new Random();

	public Particle() {
		this.mass = 1;
		this.radius = 500;
		this.rx = rand.nextInt(30000) + 500;
		this.ry = rand.nextInt(30000) + 500;
		this.vx = rand.nextInt(300) + 1;
		this.vy = rand.nextInt(300) + 1;
		this.draw();
	}

	public void move(double dt) {

		rx = rx + vx * dt;
		ry = ry + vy * dt;

	}

	public void draw() {
		StdDraw.filledCircle(rx, ry, radius);
	}

	public double timeToHit(Particle that) {
		if (this == that)
			return Double.POSITIVE_INFINITY;
		double dx = that.rx - this.rx, dy = that.ry - this.ry;
		double dvx = that.vx - this.vx;
		double dvy = that.vy - this.vy;
		double dvdr = dx * dvx + dy * dvy;
		if (dvdr > 0)
			return Double.POSITIVE_INFINITY;
		double dvdv = dvx * dvx + dvy * dvy;
		double drdr = dx * dx + dy * dy;
		double sigma = this.radius + that.radius;
		double d = (dvdr * dvdr) - dvdv * (drdr - sigma * sigma);
		if (d < 0)
			return Double.POSITIVE_INFINITY;
		return -(dvdr + Math.sqrt(d)) / dvdv;

	}

	public double timeToHitVerticalWall() {
		double timeToHitVerticalWall = timeToHitVerticalWallCalc();
		if (timeToHitVerticalWall != Double.POSITIVE_INFINITY) {
			double timeToHitHorizontalWall = timeToHitHorizontalWallCalc();
			if (timeToHitVerticalWall > timeToHitHorizontalWall) {
				return Double.POSITIVE_INFINITY;
			}
		}
		return timeToHitVerticalWall;
	}

	public double timeToHitHorizontalWall() {
		double timeToHitHorizontalWall = timeToHitHorizontalWallCalc();
		if (timeToHitHorizontalWall != Double.POSITIVE_INFINITY) {
			double timeToHitVerticalWall = timeToHitVerticalWallCalc();
			if (timeToHitHorizontalWall > timeToHitVerticalWall) {
				return Double.POSITIVE_INFINITY;
			}
		}

		return timeToHitHorizontalWall;
	}

	private double timeToHitVerticalWallCalc() {
		double timeToHitVerticalWall = Double.POSITIVE_INFINITY;
		if (vx > 0)
			timeToHitVerticalWall = Math.abs((32268 - this.radius - this.rx) / vx);
		if (vx < 0)
			timeToHitVerticalWall = Math.abs((500 - this.radius + this.rx) / vx);
		return timeToHitVerticalWall;
	}

	private double timeToHitHorizontalWallCalc() {
		double timeToHitHorizontalWall = Double.POSITIVE_INFINITY;
		if (vy > 0)
			timeToHitHorizontalWall = Math.abs(32268 - this.radius - this.ry) / vy;
		if (vy < 0)
			timeToHitHorizontalWall = Math.abs((500 - this.radius + this.ry) / vy);
		return timeToHitHorizontalWall;
	}

	public void bounceOff(Particle that) {
		double dx = that.rx - this.rx, dy = that.ry - this.ry;
		double dvx = that.vx - this.vx, dvy = that.vy - this.vy;
		double dvdr = dx * dvx + dy * dvy;
		double dist = this.radius + that.radius;
		double J = 2 * this.mass * that.mass * dvdr / ((this.mass + that.mass) * dist);
		double Jx = J * dx / dist;
		double Jy = J * dy / dist;
		this.vx += Jx / this.mass;
		this.vy += Jy / this.mass;
		that.vx -= Jx / that.mass;
		that.vy -= Jy / that.mass;
		this.count++;
		that.count++;

	}

	public void bounceOffVerticalWall() {
		vx = -vx;
	}

	public void bounceOffHorizontalWall() {
		vy = -vy;
	}

}
