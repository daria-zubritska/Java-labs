import java.util.Random;

public class Ball {
	private double rx, ry; // position
	private double vx, vy; // velocity
	private final double radius; // radius
	
	Random rand = new Random();

	public Ball(){
		this.radius = 500; 
		this.rx = rand.nextInt(30000);
		this.ry = rand.nextInt(30000);
		this.vx = rand.nextInt(300);
		this.vy = rand.nextInt(300);
		this.draw();
	}

	public void move(double dt) {
		if ((rx + vx * dt + radius >= 32768) || (rx + vx * dt - radius <=0)) {
			vx = -vx;
		}
		if ((ry + vy * dt + radius >= 32768) || (ry + vy * dt - radius <=0)) {
			vy = -vy;
		}
		rx = rx + vx * dt;
		ry = ry + vy * dt;
	}

	public void draw() {
		StdDraw.filledCircle(rx, ry, radius);
	}
}
