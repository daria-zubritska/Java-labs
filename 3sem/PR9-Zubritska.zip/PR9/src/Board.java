import java.util.ArrayList;

public class Board {
	private int[][] board;
	private final int n;

	public Board(int[][] blocks) { // конструюємо дошку у вигляді двовимірного масиву N на N
		if (blocks == null)
			throw new NullPointerException();
		n = blocks.length;
		this.board = new int[n][n];
		
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				board[i][j] = blocks[i][j];
			}
		}

	}

	public int dimension() { // розмірність дошки N
		return n;
	}

	public int hamming() { // кількість блоків не на своєму місці
		int outOfPlace = 0;
		for (int row = 0; row < n; row++) {
			for (int col = 0; col < n; col++) {
				if (board[row][col] != 0 && board[row][col] != (row * n) + col + 1) {
					outOfPlace++;
				}
			}
		}
		return outOfPlace;
	}

	public int manhattan() { // сума Манхатенських відстаней між блоками і цільовим станом
		int manh = 0;
		int goalRow, goalCol;
		for (int row = 0; row < n; row++)
			for (int col = 0; col < n; col++)
				if (this.board[row][col] != 0 && this.board[row][col] != (row * n) + col + 1) {
					if (this.board[row][col] % n == 0) {
						goalRow = (this.board[row][col] / n) - 1;
						goalCol = (this.board[row][col] - 1) - (goalRow * n);
						manh += Math.abs(goalRow - row);
						manh += Math.abs(goalCol - col);
					} else {
						goalRow = (this.board[row][col] / n);
						goalCol = (this.board[row][col] - 1) - (goalRow * n);
						manh += Math.abs(goalRow - row);
						manh += Math.abs(goalCol - col);
					}
				}
		return manh;
	}

	public boolean isGoal() { // чи є ця дошка цільовим станом
		return hamming() == 0;
	}

	public boolean equals(Board y) { // чи ця дошка рівна y?
		if (y == null)
			return false;
		return toString().equals(y.toString());
	}

	public Iterable<Board> neighbors() {// всі сусдні дошки
		int row = 0;
		int col = 0;
		boolean found = false;
		ArrayList<Board> neib = new ArrayList<>();

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (this.board[i][j] == 0) {
					row = i;
					col = j;
					found = true;
					break;
				}
			}
			if (found)
				break;
		}
		int[][] clone = new int[n][n];
		
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				clone[i][j] = board[i][j];
			}
		}

		if (row > 0) {
			clone[row][col] = clone[row - 1][col];
			clone[row - 1][col] = 0;
			neib.add(new Board(clone));
			clone[row - 1][col] = clone[row][col];
			clone[row][col] = 0;
		}
		if (row < n-1) {
			clone[row][col] = clone[row + 1][col];
			clone[row + 1][col] = 0;
			neib.add(new Board(clone));
			clone[row + 1][col] = clone[row][col];
			clone[row][col] = 0;
		}
		if (col > 0) {
			clone[row][col] = clone[row][col - 1];
			clone[row][col - 1] = 0;
			neib.add(new Board(clone));
			clone[row][col - 1] = clone[row][col];
			clone[row][col] = 0;
		}
		if (col < n-1) {
			clone[row][col] = clone[row][col + 1];
			clone[row][col + 1] = 0;
			neib.add(new Board(clone));
			clone[row][col + 1] = clone[row][col];
			clone[row][col] = 0;
		}

		return neib;
	}

	public String toString() { // строкове подання
		String s = "";

		for (int row = 0; row < n; row++) {
			for (int col = 0; col < n; col++) {
				s += this.board[row][col] + " ";
			}
			s += "\n";
		}

		return s;
	}

	public Board twin() {
		int[][] boardClone = new int[n][n];
		
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				boardClone[i][j] = board[i][j];
			}
		}

		int temp, temp2;
		int tempRow = StdRandom.uniform(n);
		int tempCol = StdRandom.uniform(n);
		while (boardClone[tempRow][tempCol] == 0) {
			tempRow = StdRandom.uniform(n);
			tempCol = StdRandom.uniform(n);
		}
		temp = boardClone[tempRow][tempCol];

		int temp2Row = StdRandom.uniform(n);
		int temp2Col = StdRandom.uniform(n);
		while (boardClone[temp2Row][temp2Col] == 0 || boardClone[temp2Row][temp2Col] == temp) {
			temp2Row = StdRandom.uniform(n);
			temp2Col = StdRandom.uniform(n);
		}
		temp2 = boardClone[temp2Row][temp2Col];

		boardClone[tempRow][tempCol] = temp2;
		boardClone[temp2Row][temp2Col] = temp;

		Board twin = new Board(boardClone);
		return twin;
	}
}
