import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.PriorityQueue;
import java.util.Scanner;

public class Solver {
	private int moves;
	private Node solution, twin, temp;
	private boolean solvable;

	public Solver(Board initial) { // знайти рішення для дошки initial
		if (initial == null)
			throw new NullPointerException();

		if (initial.isGoal()) {
			solvable = true;
			moves = 0;
			solution = new Node();
			solution.board = initial;
			solution.moves = 0;
			solution.previous = null;
		} else {
			PriorityQueue<Node> pqSolution = new PriorityQueue<Node>();
			PriorityQueue<Node> pqTwin = new PriorityQueue<Node>();

			boolean initialFlag = false;
			boolean twinFlag = false;

			solution = new Node();
			twin = new Node();
			temp = new Node();

			solution.board = initial;
			solution.moves = 0;
			solution.previous = null;
			pqSolution.add(solution);

			twin.board = initial.twin();
			twin.moves = 0;
			twin.previous = null;
			pqTwin.add(twin);

			while (!initialFlag && !twinFlag) {

				solution = pqSolution.poll();
				twin = pqTwin.poll();

				if (solution.board.isGoal())
					initialFlag = true;
				else {
					for (Board board : solution.board.neighbors()) {
						if (solution.previous == null || !board.equals(solution.previous.board)) {
							temp = new Node();
							temp.board = board;
							temp.moves = solution.moves + 1;
							temp.previous = solution;
							pqSolution.add(temp);
						}
					}
				}

				if (twin.board.isGoal())
					twinFlag = true;
				else {
					for (Board x : twin.board.neighbors()) {
						if (twin.previous == null || !x.equals(twin.previous.board)) {
							temp = new Node();
							temp.board = x;
							temp.moves = twin.moves + 1;
							temp.previous = twin;
							pqTwin.add(temp);
						}
					}
				}
			}

			if (twinFlag && !initialFlag)
				solvable = false;
			else {
				solvable = true;
				moves = solution.moves;
			}
		}

	}

	public boolean isSolvable() { // чи має початкова дошка розв’язок
		return solvable;
	}

	public int moves() { // мінімальна кількість кроків для вирішення дошки, -1 якщо немає рішення
		if (!isSolvable())
			return -1;
		else
			return moves;
	}

	public Iterable<Board> solution() { // послідовність дошок в найкоротшому рішенні; null якщо немає рішення
		if (!isSolvable())
			return null;
		return new SolutionIterable();
	}

	private class SolutionIterable implements Iterable<Board> {
		public Iterator<Board> iterator() {
			return new SolutionIterator();
		}
	}

	private class SolutionIterator implements Iterator<Board> {
		private int count;
		private Node trans = new Node();

		public SolutionIterator() {
			count = solution.moves;
		}

		public boolean hasNext() {
			return count >= 0;
		}

		public Board next() {
			if (solution == null)
				throw new NoSuchElementException();

			int counter = 0;
			trans.board = solution.board;
			trans.moves = solution.moves;
			trans.previous = solution.previous;

			while (counter < count) {
				trans = trans.previous;
				counter++;
			}
			count--;
			return trans.board;
		}
	}

	public static void main(String[] args) throws FileNotFoundException {
		// створюємо початкову дошку з файлу
		FileReader fr = new FileReader("puzzle3x3-unsolvable.txt");
		Scanner in = new Scanner(fr);
		int N = in.nextInt();
		int[][] blocks = new int[N][N];
		for (int i = 0; i < N; i++)
			for (int j = 0; j < N; j++)
				blocks[i][j] = in.nextInt();
		Board initial = new Board(blocks);

		// розв’язати
		Solver solver = new Solver(initial);

		// надрукувати рішення
		if (!solver.isSolvable())
			StdOut.println("Дошка не має розв’язку");
		else {
			StdOut.println("Мінімальна кількість кроків = " + solver.moves());
			for (Board board : solver.solution())
				StdOut.println(board);
		}
	}
}

class Node implements Comparable<Node> {

	Board board;
	int moves;
	Node previous;

	public int compareTo(Node o) {
		if ((this.board.manhattan() + this.moves) > (o.board.manhattan() + o.moves)) {
			return 1;
		} else {
			return -1;
		}
	}
}
