import java.util.Scanner;

public class Graph {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		
		int[][] m = new int[n][n];
		
		for(int i = 0; i < n; i++) {
			for(int j = 0; j < n; j++) {
				m[i][j] = in.nextInt();
				
				if(i == j && m[i][j] == 1) {
					System.out.println("NO");
					return;
				}
			}
		}
		
		for(int i = 0; i < n; i++) {
			for(int j = 0; j < n; j++) {
				if(m[i][j] != m[j][i]) {
					System.out.println("NO");
					return;
				}
			}
		}
		
		System.out.println("YES");
		in.close();

	}

}
