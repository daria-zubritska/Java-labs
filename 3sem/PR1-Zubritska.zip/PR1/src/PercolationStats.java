import java.util.Random;
import java.math.*;

public class PercolationStats {
	
	public int[] tests;
	Percolation newPercolation;
	Random rand = new Random();
	double m = 0;
	double o = 0;
	int N;
	
	public PercolationStats(int N, int T) {
		this.N = N;
		this.tests = new int[T];
		
		for(int i = 0; i<T; i++) {
			newPercolation = new Percolation(N);
			
			do {
				int row = rand.nextInt(N)+1;
				int col = rand.nextInt(N)+1;
				if(!newPercolation.isOpened(row, col)) {
					newPercolation.open(row, col);
				}
			
			}while(!newPercolation.percolates());
			
			this.tests[i] = newPercolation.getOpenedCount();
			System.out.println("Test " + (i+1) + " opened cells " + tests[i]);
		}
		
	}
	
	public double mean() {
		
		for(int i = 0; i< tests.length; i++) {
			m = m + tests[i];
		}
		
		m = m/tests.length;
		
		return m/(N*N);
	}
	
	public double stddev() {
		
		for(int i = 0; i< tests.length; i++) {
			o = o +Math.pow((tests[i] - m), 2);
		}
		
		o = o/(tests.length - 1);
		
		o = Math.sqrt(o);
		
		o = o/(N*N);
		
		return o;
	}
	
	public static void main(String[] args) {
		System.out.print("Grid side: ");
		int N = StdIn.readInt();
		System.out.print("Amount of tests: ");
		int T = StdIn.readInt();
		
		PercolationStats perc = new PercolationStats(N, T);
		
		System.out.println("Середнє: " + perc.mean() + " Відхилення: " + perc.stddev());
		
	}

}
