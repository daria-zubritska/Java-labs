
public class Percolation {
	
	private int opened;
	private boolean[] tiles;
	private int N;
	private QuickFindUF uf;
	private int top;
	private int bottom;
	
	public Percolation(int N) {
		this.opened = 0;
		this.N = N;
		this.tiles = new boolean[N*N + 2];
		this.top = 0;
		this.bottom = N*N + 1;
		
		tiles[top] = true;
		tiles[bottom] = true;
		
		this.uf = new QuickFindUF(N*N + 2);
	}
	
	public int getOpenedCount() {
		return opened;
	}
	
	public void open(int i, int j) {
		if(isOpened(i, j)) return;
		
		int tileID = N * i - (N - j);
		
		tiles[tileID] = true;
		opened++;
		
		if(i-1 == 0) uf.union(tileID, top);
		
		if(i+1 == N + 1) uf.union(tileID, bottom);
		
		if(percolates()) return;
		
		if(i - 1 != 0 && isOpened(i - 1, j)) uf.union(tileID, N*(i - 1) - (N - j));
		if(j - 1 != 0 && isOpened(i, j - 1)) uf.union(tileID, N*i - (N - (j - 1)));
		if(i + 1 != N+1 && isOpened(i + 1, j)) uf.union(tileID, N*(i + 1) - (N - j));
		if(j + 1 != N+1 && isOpened(i, j - 1)) uf.union(tileID, N*i - (N - (j + 1)));
		
	}
	
	public boolean isOpened(int i, int j) {
		return tiles[N*i - (N - j)];
	}
	
	public boolean percolates() {
		return uf.connected(top, bottom);
	}

}
