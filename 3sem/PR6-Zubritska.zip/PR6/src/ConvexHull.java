import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class ConvexHull {
	
	private Point2D[] myPoints;
	
	public ConvexHull(Point2D[] userPoints) {
		StdDraw.setXscale(0, 32768);
		StdDraw.setYscale(0, 32768);

		StdDraw.setPenColor(StdDraw.RED);
		
		myPoints = userPoints;
		
		Arrays.sort(myPoints);
		
		for(Point2D p: myPoints) {
			p.draw();
		}
		
	}
	
	public void drawIt() {
		
		if(myPoints.length < 3) return;
		
		ArrayList<Point2D> res = new ArrayList<Point2D>();
		
		int p = 0; 
		int q;
		
		do {
			
			res.add(myPoints[p]);
			
			q = p+1;
			if(p+1 == myPoints.length) {
				q = 0;
			}
			
			for(int i = 0; i<myPoints.length; i++) {
				if(Point2D.ccw(myPoints[p], myPoints[i], myPoints[q])>0) {
					q = i;
				}
			}
			
			p = q;
			
		}while( p!= 0);
		
		for(int i = 0; i<res.size(); i++) {
			if(i+1 == res.size()) {
				res.get(i).drawTo(res.get(0));
				break;
			}
			
			res.get(i).drawTo(res.get(i+1));
		}
		
	}

	public static void main(String[] args) throws FileNotFoundException {
		FileReader fr = new FileReader("C:\\Users\\Dasha\\eclipse-workspace\\PR4\\pr4_5_data\\input50.txt");
		Scanner a = new Scanner(fr);
		
		Point2D[] userPoints = new Point2D[a.nextInt()];
		
		for(int i = 0; i<userPoints.length; i++) {
			int x = a.nextInt();
			int y = a.nextInt();
			
			userPoints[i] = new Point2D(x, y);
		}
		
		ConvexHull c = new ConvexHull(userPoints);
		c.drawIt();

	}

}
