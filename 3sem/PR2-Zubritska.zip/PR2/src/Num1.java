
public class Num1 {

	public static void main(String[] args) {
		int N = StdIn.readInt();
		
		Stopwatch watch = new Stopwatch();
		
		Timing.trial(N, 777280);
		
		double time = watch.elapsedTime();
		System.out.print(time);
	}
}
