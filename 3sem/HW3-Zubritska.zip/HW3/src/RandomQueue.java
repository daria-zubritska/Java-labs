import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class RandomQueue<Item> implements Iterable<Item> { 
	
	ArrayList<Item> rqueue;
	
	public RandomQueue() {
		rqueue = new ArrayList<Item>();
	}

	public boolean isEmpty() {
		return rqueue.isEmpty();
	}
// чи порожня? 

	public int size() {
		return rqueue.size();
	}
// кількість елементів

	public void enqueue(Item item) {
		if(item == null) throw new NullPointerException();
		
		rqueue.add(0, item);
	}
// додати елемент

	public Item dequeue() {
		if(isEmpty()) throw new NoSuchElementException();
		
		return rqueue.remove(StdRandom.uniform(size()));
	}
// видалити і повернути випадковий елемент

	public Item sample() {
		if(isEmpty()) throw new NoSuchElementException();
		
		return rqueue.get(StdRandom.uniform(size()));
	}
// повернути але не видалити випадковий елемент

	public Iterator<Item> iterator() {
		Object[] newrqueue = rqueue.toArray();
		StdRandom.shuffle(newrqueue);
		return (Iterator<Item>) Arrays.asList(newrqueue).iterator();
	}
// повернути ітератор по елементам з випадковою чергою
}
