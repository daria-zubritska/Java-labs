import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> { 
	
	ArrayList<Item> deque;
	
	public Deque() {
		deque = new ArrayList<Item>();
	}
// створюється порожня дека 

	public boolean isEmpty() {
		return deque.isEmpty();
	}
// чи порожня? 

	public int size() {
		return deque.size();
	}
// кількість елементів в деці

	public void addFirst(Item item) {
		if(item == null) throw new NullPointerException();
		deque.add(0, item);
		
	}
// додаємо на початок

	public void addLast(Item item) {
		if(item == null) throw new NullPointerException();
		deque.add(item);
	}
// додаємо в кінець

	public Item removeFirst() {
		if(isEmpty()) throw new NoSuchElementException();
			
		return deque.remove(0);
	}
// видаляємо і повертаємо перший

	public Item removeLast() {
		if(isEmpty()) throw new NoSuchElementException();
		
		return deque.remove(deque.size()-1);
	}
// видаляємо і повертаємо останній

	public Iterator<Item> iterator() {
		return (Iterator<Item>) deque.iterator();
	}
// повертаємо ітератор по елементам

}
