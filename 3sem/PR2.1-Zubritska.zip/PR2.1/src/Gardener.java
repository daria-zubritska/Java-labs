import java.util.Scanner;

public class Gardener {

	public static void main(String[] args) {
		String a;
		
		Scanner in = new Scanner(System.in);
		a = in.nextLine();
		int layers = Integer.parseInt(a);
		
		System.out.println(countLeaves(layers));

	}

	private static int countLeaves(int layers) {
		int leaves = 4;
		int litr = 3;
		
		if(layers == 0) return 1;
		if(layers == 1) return 3;
		
		for(int i = 2; i<=layers; i++) {
			litr = litr + leaves;
			leaves = leaves + 2;
		}
		
		return litr;
	}

}
