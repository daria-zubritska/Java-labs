import java.util.Scanner;


public class Rabbits {
	
	static int month;
	static int k;

	public static void main(String[] args) {
		String a;
		
			Scanner in = new Scanner(System.in);
			a = in.nextLine();
			month = Integer.parseInt(a);
			
			a = in.nextLine();
			k = Integer.parseInt(a);

			System.out.println(countRabbits());

			in.close();
	}
	
	private static int countRabbits() {
		int rab = 1;
		
		if(month == 0) return 1;
		
		for(int i = 1; i<=month; i++) {
			rab = rab*2;
			if(rab>k && i!=month) rab = rab - k;
		}
		
		return rab;
	}
}