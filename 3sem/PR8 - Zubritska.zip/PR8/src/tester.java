import java.util.Iterator;

public class tester {

	public static void main(String[] args) throws ClassNotFoundException {

		ST<Integer, String> st = new ST<>();

		BST<Integer, String> bst = new BST<>();

		st.put(3, "THREE");
		st.put(1, "ONE");
		st.put(4, "FOUR");
		st.put(0, "ZERO");
//		st.put(2, "TWO");
		
		System.out.println(st.size(1, 4));
		System.out.println();
		
		System.out.println(st.ceiling(2));
		System.out.println();

		System.out.println(st.floor(2));
		System.out.println();
		
		Iterator<Integer> it = st.keys().iterator();

		while (it.hasNext()) {
			System.out.println(it.next());
		}
		
		System.out.println();
		it = st.keys(3, 1).iterator();
		
		while (it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println();

		st.delete(3);

		it = st.keys().iterator();

		while (it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println();
		
		System.out.println(st.ceiling(2));
		System.out.println();

		st.deleteMax();

		it = st.keys().iterator();

		while (it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println();

		st.deleteMin();

		it = st.keys().iterator();

		while (it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println();
		
		

	}

}
