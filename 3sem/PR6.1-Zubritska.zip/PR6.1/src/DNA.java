import java.util.Scanner;

public class DNA {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		int t = in.nextInt();
		for (int i = 0; i < t; i++) {

			in.nextLine();

			int n = in.nextInt();
			int m = in.nextInt();
			int[] a = new int[m];
			String[] s = new String[m];
			in.nextLine();
			for (int j = 0; j < m; j++) {
				s[j] = in.nextLine();
				a[j] = getSortedness(s[j], n);

				if (j > 0) {
					String tmps = s[j];
					int tmpi = a[j];
					int k = j;
					while (k > 0 && a[k - 1] > tmpi) {
						s[k] = s[k - 1];
						a[k] = a[--k];
					}
					s[k] = tmps;
					a[k] = tmpi;
				}

			}

			for (int j = 0; j < s.length; j++) {
				System.out.println(s[j]);
			}
			if (i < t - 1)
				System.out.println();
		}

		in.close();
	}

	private static int getSortedness(String string, int n) {
		int a = 0;
		for (int i = 0; i < n - 1; i++) {
			for (int j = i + 1; j < n; j++) {
				char f = string.charAt(i);
				char sec = string.charAt(j);
				if (Character.compare(f, sec) > 0)
					a++;
			}
		}
		return a;
	}

}
