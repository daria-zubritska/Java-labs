

public class SelectionSort {

	private static boolean less(Apple v, Apple w){
		return v.compareTo(w)<0;
	}
	
	private static boolean lessByAge(Apple v, Apple w){
		return v.ageComp.compare(v, w) < 0;
	}
	
	private static boolean lessByColor(Apple v, Apple w){
		return v.colorComp.compare(v, w) < 0;
	}
	
	private static void exch(Apple[] a, int i, int j){
		Apple swap = a[i];
		a[i] = a[j];
		a[j] = swap;
	}
	
	private static boolean isSorted(Apple[] a){
		for (int i=1;i<a.length;i++)
			if (less(a[i],a[i-1])) return false;
		return true;
	}
	
	private static boolean isSortedByAge(Apple[] a){
		for (int i=1;i<a.length;i++)
			if (lessByAge(a[i],a[i-1])) return false;
		return true;
	}
	
	private static boolean isSortedByColor(Apple[] a){
		for (int i=1;i<a.length;i++)
			if (lessByColor(a[i],a[i-1])) return false;
		return true;
	}

	public static void sort(Apple[] a){
		int n = a.length;
		for (int i=0;i<n;i++){
			int min = i;
			for (int j = i+1;j<n;j++)
				if (less(a[j],a[min]))
					min = j;
			exch(a,i,min);
		}
	}
	
	public static void sortByAge(Apple[] a){
		int n = a.length;
		for (int i=0;i<n;i++){
			int min = i;
			for (int j = i+1;j<n;j++)
				if (lessByAge(a[j],a[min]))
					min = j;
			exch(a,i,min);
		}
	}
	
	public static void sortByColor(Apple[] a){
		int n = a.length;
		for (int i=0;i<n;i++){
			int min = i;
			for (int j = i+1;j<n;j++)
				if (lessByColor(a[j],a[min]))
					min = j;
			exch(a,i,min);
		}
	}
	
}
