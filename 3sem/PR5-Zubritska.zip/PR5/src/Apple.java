import java.util.Comparator;

public class Apple implements Comparable<Apple> {

	enum Color {
		RED, GREEN, YELLOW
	};
	
	public final Comparator<Apple> ageComp = new AppleAgeComp();
	public final Comparator<Apple> colorComp = new AppleColorComp();

	Color appCol;
	int mass;
	int age;

	Apple(Color userCol, int userMass, int userAge) {
		this.mass = userMass;
		this.age = userAge;
		this.appCol = userCol;
	}

	@Override
	public int compareTo(Apple o) {
		if (this.mass > o.mass)
			return 1;
		if (this.mass == o.mass)
			return 0;
		return -1;
	}
	
	public String toString() {
		String color = "unknown color ";
		if(this.appCol == Apple.Color.RED) {
			color = "Red ";
			}
		if(this.appCol == Apple.Color.GREEN) {
			color = "Green ";
			}
		if(this.appCol == Apple.Color.YELLOW) {
			color = "Yellow ";
			}
		return this.mass + " kg " + color + this.age + " days on shelf";
	}

}

class AppleAgeComp implements Comparator<Apple> {

	@Override
	public int compare(Apple o1, Apple o2) {
		if (o1.age > o2.age)
			return 1;
		if (o1.age == o2.age)
			return 0;
		return -1;
	}

}

class AppleColorComp implements Comparator<Apple> {

	@Override
	public int compare(Apple o1, Apple o2) {
		int i1 = 0;
		int i2 = 0;

		switch(o1.appCol){ 
		case RED:
			i1 = 1;
			break;
		case GREEN:
			i1 = 2;
			break;
		case YELLOW:
			i1 = 3;
			break;
		}
		
		switch(o2.appCol){ 
		case RED:
			i2 = 1;
			break;
		case GREEN:
			i2 = 2;
			break;
		case YELLOW:
			i2 = 3;
			break;
		}
		if (i1 > i2)
			return 1;
		if (i1 == i2)
			return 0;
		return -1;
	}

}