import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class tester {

	public static void main(String[] args) throws IOException {
		FileReader fr = new FileReader("Apples.txt");
		Scanner a = new Scanner(fr);
		String[] aa;

		int n = Integer.parseInt(a.nextLine());
		Apple[] myApples = new Apple[n];

		for (int i = 0; i < n; i++) {
			aa = a.nextLine().split(" ");

			int mass = Integer.parseInt(aa[0]);
			int age = Integer.parseInt(aa[2]);

			if (aa[1].compareToIgnoreCase("red") == 0) {
				myApples[i] = new Apple(Apple.Color.RED, mass, age);
				continue;
			}
			if (aa[1].compareToIgnoreCase("green") == 0) {
				myApples[i] = new Apple(Apple.Color.GREEN, mass, age);
				continue;
			}
			if (aa[1].compareToIgnoreCase("yellow") == 0) {
				myApples[i] = new Apple(Apple.Color.YELLOW, mass, age);
				continue;
			}
		}

		fr.close();
		
		Apple[] copy = myApples;
		
		Insertion(myApples, copy);

		
		MergeTest(myApples, copy);
		
		
		Selection(myApples, copy);

		
		Shell(myApples, copy);


	}

	private static void Shell(Apple[] myApples, Apple[] copy) {
		myApples = copy;

		System.out.println("ShellSort by kg:");
		ShellSort.sort(myApples);

		for (Apple ap : myApples) {
			System.out.println(ap.toString());
		}
		System.out.println(" ");
		myApples = copy;

		System.out.println("ShellSort by age:");
		ShellSort.sortByAge(myApples);

		for (Apple ap : myApples) {
			System.out.println(ap.toString());
		}
		System.out.println(" ");
		myApples = copy;

		System.out.println("ShellSort by color from red to yellow:");
		ShellSort.sortByColor(myApples);

		for (Apple ap : myApples) {
			System.out.println(ap.toString());
		}

	}

	private static void Selection(Apple[] myApples, Apple[] copy) {
		myApples = copy;
		System.out.println(" ");
		System.out.println("SelectionSort by kg:");
		SelectionSort.sort(myApples);

		for (Apple ap : myApples) {
			System.out.println(ap.toString());
		}

		myApples = copy;
		System.out.println(" ");
		System.out.println("SelectionSort by age:");
		SelectionSort.sortByAge(myApples);

		for (Apple ap : myApples) {
			System.out.println(ap.toString());
		}
		System.out.println(" ");
		myApples = copy;

		System.out.println("SelectionSort by color from red to yellow:");
		SelectionSort.sortByColor(myApples);

		for (Apple ap : myApples) {
			System.out.println(ap.toString());
		}

	}

	private static void MergeTest(Apple[] myApples, Apple[] copy) {
		myApples = copy;
		System.out.println(" ");
		System.out.println("MergeSort by kg:");
		MergeSort.sort(myApples);

		for (Apple ap : myApples) {
			System.out.println(ap.toString());
		}

		myApples = copy;
		System.out.println(" ");
		System.out.println("MergeSort by age:");
		MergeSort.sortByAge(myApples);

		for (Apple ap : myApples) {
			System.out.println(ap.toString());
		}

		myApples = copy;
		System.out.println(" ");
		System.out.println("MergeSort by color from red to yellow:");
		MergeSort.sortByColor(myApples);

		for (Apple ap : myApples) {
			System.out.println(ap.toString());
		}

	}

	private static void Insertion(Apple[] myApples, Apple[] copy) {
		System.out.println("InsertionSort by kg:");
		InsertionSort.sort(myApples);

		for (Apple ap : myApples) {
			System.out.println(ap.toString());
		}

		myApples = copy;
		System.out.println(" ");
		System.out.println("InsertionSort by age:");
		InsertionSort.sortByAge(myApples);

		for (Apple ap : myApples) {
			System.out.println(ap.toString());
		}

		myApples = copy;
		System.out.println(" ");
		System.out.println("InsertionSort by color from red to yellow:");
		InsertionSort.sortByColor(myApples);

		for (Apple ap : myApples) {
			System.out.println(ap.toString());
		}

	}

}
