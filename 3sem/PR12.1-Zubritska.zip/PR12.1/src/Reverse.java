import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Reverse {

	public static void main(String[] args) {

		try (BufferedReader read = new BufferedReader(new InputStreamReader(System.in))) {

			String[] answerArray = new String[Integer.parseInt(read.readLine()) + 1];
			
			for (int i = 1; i < answerArray.length; i++) {
				answerArray[i] = "";
			}

			for (int i = 1; i < answerArray.length; i++) {
				for (String str : read.readLine().split(" ")) {
					if (str.equals("")) {
						break;
					}
					answerArray[Integer.parseInt(str)] += i + " ";
				}
			}

			System.out.println(answerArray.length - 1);
			for (int i = 1; i < answerArray.length; i++) {
				System.out.println(answerArray[i]);
			}

		} catch (IOException IOException) {

		}

	}

}
