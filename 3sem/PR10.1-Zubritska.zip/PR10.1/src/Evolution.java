import java.math.BigInteger;
import java.util.Scanner;

public class Evolution {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		
		if(n == 1) {
			System.out.println(1);
			return;
		}
		
		BigInteger a = in.nextBigInteger();
		BigInteger b = in.nextBigInteger();
		
		while(!a.equals(b)) {
			if(a.compareTo(b) == 1) {
				a = a.divide(BigInteger.valueOf(2));
			}else {
				b = b.divide(BigInteger.valueOf(2));
			}
		}
		
		System.out.println(a);

		in.close();

	}
}
