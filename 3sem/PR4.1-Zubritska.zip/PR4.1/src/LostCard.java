import java.util.Scanner;

public class LostCard {
		
	public static void main(String[] args) {
	
		Scanner in = new Scanner(System.in);   

	    int n = in.nextInt();
	    int res = 0;

	    for(int i = 1; i <= n; i++) {
	      res ^= i;
	    }
	    
	    for(int i = 1; i < n; i++)
	    {
	      int val = in.nextInt();
	      res ^= val;
	    }

	    System.out.println(res);
		
	}
}
