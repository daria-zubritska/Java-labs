import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class SortByHeight {

	public static void main(String[] args) throws NumberFormatException, IOException {

	    BufferedReader read = new BufferedReader(new InputStreamReader(System.in));

	    while(read.ready()) {

	      int count = 0;
	      int n = Integer.parseInt(read.readLine());

	      int mas[] = new int[n];

	      String s[] = read.readLine().split(" ");

	      for(int i = 0; i < n; i++) { 
	    	  mas[i] = Integer.parseInt(s[i]);
	      }

	      	s = read.readLine().split(" ");

	      int min = Integer.parseInt(s[0]);
	      int max = Integer.parseInt(s[1]);

	      for(int i = 0; i < n; i++)

	        if ((mas[i] >= min) && (mas[i] <= max)) count++; 

	      System.out.println(count);

	    }

	  }

}

