import java.util.Scanner;

public class Shuffle {
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

	    int n = in.nextInt();

	    int m[] = new int[n+1];

	    for(int i = 0; i < n; i++) {
	      int a = in.nextInt();
	      if (a <= n) m[a]++;
	    }

	    int k = 0;
	    
	    for(int i = 1; i <= n; i++) {
	      if (m[i] == 0) {
	    	  k = i;
	    	  break;
	      }
	    }
	   
	    
	    
	    if (k <= n) {
	      System.out.println(k);
	    }else {
	      System.out.println(0);
	    }
	}

}
