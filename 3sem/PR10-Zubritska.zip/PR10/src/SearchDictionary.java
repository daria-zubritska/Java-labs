import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

public class SearchDictionary {

	private int n = 0;
	ST<String, String> dict;

	public SearchDictionary(String file) throws FileNotFoundException, ClassNotFoundException {
		FileReader fr = new FileReader(file);
		Scanner in = new Scanner(fr);

		dict = new ST<>();

		while (in.hasNext()) {
			StringTokenizer st = new StringTokenizer(in.nextLine(), " .,?!;:");
			while (st.hasMoreTokens()) {
				addWord(st.nextToken().toLowerCase());
			}
		}
	}

	public void addWord(String word) {
		if (!dict.contains(word)) {
			dict.put(word, word);
			n++;
		}
	}

	public String delWord(String word) {
		if (dict.contains(word)) {
			n--;
			dict.delete(word);
			return word;
		}
		return "This word doesn`t exist";
	}

	public boolean hasWord(String word) {
		return dict.contains(word);
	}

	public Iterable<String> query(String query) {
		ArrayList<String> list = new ArrayList<>();

		if (query.endsWith("*")) {
			query = query.replace("*", "");
			for (String s : dict.keys()) {
				if (s.startsWith(query))
					list.add(s);
			}
		} else {
			if (hasWord(query)) {
				list.add(query);
			}
		}

		return list;
	}

	public int countWords() {
		return n;
	}

	public static void main(String[] args) throws FileNotFoundException, ClassNotFoundException {

		SearchDictionary sd = new SearchDictionary("test.txt");

		for (String s : sd.query("a*")) {
			System.out.println(s);
		}

	}

}
