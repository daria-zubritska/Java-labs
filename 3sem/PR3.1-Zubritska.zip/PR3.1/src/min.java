
import java.util.ArrayDeque;
import java.util.Scanner;

public class min {

	static ArrayDeque<Long> stack = new ArrayDeque<>(); 

	static long minVal = 0;

	public static void main(String[] args) {
		String aa;

		Scanner in = new Scanner(System.in);
		aa = in.nextLine();
		String[] val = aa.split(" ");


		long n = Long.parseLong(val[0]); 
		long a = Long.parseLong(val[1]);
		long b = Long.parseLong(val[2]);
		long c = Long.parseLong(val[3]);
		long x0 = Long.parseLong(val[4]);


		long x = x0;

		for(int i = 0; i< n; i++) {
			x = ((Math.round(a*Math.pow(x, 2) + b*x + c)/100)%1000000);

			if(x%5 < 2) {
				// remove
				if(!stack.isEmpty()) {
					stack.pop();
				}
			}
			else {
				if (stack.isEmpty())
				{
					stack.push(x);
				}
				else
				{
					// calculate before addeing to stack
					stack.push(Math.min(stack.peek(), x));
				}
			}

			if (!stack.isEmpty())
			{
				minVal += stack.peek();
			}

		}

		System.out.print(minVal);
	}
}
