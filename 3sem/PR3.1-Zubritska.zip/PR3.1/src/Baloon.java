import java.util.Scanner;

public class Baloon {
	
	static int[] col = new int[9];
	static int quan;

	public static void main(String[] args) {
		String a;
		
		Scanner in = new Scanner(System.in);
		a = in.nextLine();
		quan = Integer.parseInt(a);
		
		if(quan == 0) {
			System.out.print(0);
			return;
		}
		
		a = in.nextLine();
		
		for(int i = 0; i<a.length(); i++) {
			char b = a.charAt(i);
		 if(Character.isDigit(b)) {
			 col[Integer.parseInt((Character.toString(b))) - 1] ++;
		 }
		}
		
		System.out.print(countmin());
		
	}
	
	public static int countmin() {
		int max = 0;
		for(int i: col) {
			if(i>max) max = i;
		}
		
		return quan - max;
	}

}
