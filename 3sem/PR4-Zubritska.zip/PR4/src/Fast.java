
public class Fast {

	private Point[] myPoints;
	private double[][] mySlopes;
	private int basis = 0;

	public Fast(Point[] userPoints) {
		StdDraw.setXscale(0, 32768);
		StdDraw.setYscale(0, 32768);

		StdDraw.setPenColor(StdDraw.RED);

		myPoints = userPoints;

		InsertionSort.sort(myPoints);
		mySlopes = new double[userPoints.length][2];

	}

	private void calculateSlopers() {

		myPoints[basis].draw();
		for (int i = 0; i < myPoints.length; i++) {
			mySlopes[i][0] = myPoints[basis].slopeTo(myPoints[i]);
			mySlopes[i][1] = i;
		}

		InsertionSortDouble.sort(mySlopes);

	}

	public void drawIt() {

		while (basis < myPoints.length) {

			calculateSlopers();

			for (int i = 0; i < mySlopes.length; i++) {

				if (i + 3 == mySlopes.length)
					break;

				if (mySlopes[i][0] != mySlopes[i + 1][0] || mySlopes[i][0] != mySlopes[i + 2][0])
					continue;

				myPoints[basis].drawTo(myPoints[(int) mySlopes[i + 2][1]]);
				System.out.println(myPoints[basis] + "--->" + myPoints[i] + "--->" + myPoints[i+1] + "--->" + myPoints[i+2]);

			}

			basis++;
		}

	}
}
