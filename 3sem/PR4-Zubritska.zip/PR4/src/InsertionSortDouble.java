
public class InsertionSortDouble {
	private static boolean less(double v, double w){
		return v < w;
	}
	
	private static void exch(double[][] a, int i, int j){
		double swap = a[i][0];
		a[i][0] = a[j][0];
		a[j][0] = swap;
		
		double swap1 = a[i][1];
		a[i][1] = a[j][1];
		a[j][1] = swap1;
	}
	
	private static boolean isSorted(double[][] a){
		for (int i=1;i<a.length;i++)
			if (less(a[i][0],a[i-1][0])) return false;
		return true;
	}

	public static void sort(double[][] a){
		int n = a.length;
		for (int i=0;i<n;i++){
			for (int j = i;j>0;j--)
				if (less(a[j][0],a[j-1][0]))
					exch(a,j,j-1);
				else break;
		}
	}
}
