import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class tester {
	
	public static void main(String args[]) throws IOException {
	
	FileReader fr = new FileReader("C:\\Users\\Dasha\\eclipse-workspace\\PR4\\pr4_5_data\\input6.txt");
	Scanner a = new Scanner(fr);
	
	Point[] userPoints = new Point[a.nextInt()];
	
	for(int i = 0; i<userPoints.length; i++) {
		int x = a.nextInt();
		int y = a.nextInt();
		
		userPoints[i] = new Point(x, y);
	}
	
	//BruteForce bf = new BruteForce(userPoints);
	//bf.drawIt();
	
	Fast f = new Fast(userPoints);
	f.drawIt();
	
	fr.close();
	
	}
}
