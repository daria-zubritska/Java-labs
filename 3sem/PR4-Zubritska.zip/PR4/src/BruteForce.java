
public class BruteForce {

	private Point[] myPoints;

	public BruteForce(Point[] userPoints) {
		StdDraw.setXscale(0, 32768);
		StdDraw.setYscale(0, 32768);

		StdDraw.setPenColor(StdDraw.RED);

		myPoints = userPoints;

		sortingThePoints();
	}

	private void sortingThePoints() {
		InsertionSort.sort(myPoints);
	}

	public void drawIt() {

		for (int i = 0; i < myPoints.length; i++) { // i
			myPoints[i].draw();
			for (int j = i + 1; j < myPoints.length; j++) { // j

				for (int k = j + 1; k < myPoints.length; k++) { // k

					for (int l = k + 1; l < myPoints.length; l++) { // l

						if (myPoints[i].SLOPE_ORDER.compare(myPoints[j], myPoints[k]) == 0
								&& myPoints[j].SLOPE_ORDER.compare(myPoints[k], myPoints[l]) == 0
								&& myPoints[i].SLOPE_ORDER.compare(myPoints[j], myPoints[l]) == 0) {
							myPoints[i].drawTo(myPoints[l]);
							System.out.println(myPoints[i] + "--->" + myPoints[j] + "--->" + myPoints[k] + "--->" + myPoints[l]);

						}

					}

				}
			}

		}

	}
}
