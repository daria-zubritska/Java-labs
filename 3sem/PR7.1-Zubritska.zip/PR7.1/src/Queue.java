import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Scanner;

public class Queue {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		int k = in.nextInt();
		PriorityQueue<Long> queue = new PriorityQueue<>();
		ArrayList<Integer> people = new ArrayList<>();
		long answer = 0;

			for (int i = 0; i < n; i++) {
				people.add(in.nextInt());
			}

			if (k < n) {
				long time = 0;
				long notMin = 0;

				for (int i = 0; i < k; i++) {
					queue.add((long)people.get(i));
				}
				for (int i = k; i < n; i++) {
					time = queue.poll();

					answer = answer + time - notMin;
					queue.add(time + people.get(i));
					notMin = time;

				}
				time = 0;
				if (!queue.isEmpty()) {
					while (!queue.isEmpty()) {
						time = queue.poll();
					}
					time -= notMin;
					answer += time;
				}

			} else {
				for (int i = 0; i < people.size(); i++) {
					answer = Math.max(answer, people.get(i));
				}
			}

		System.out.println(answer);

	}

}
