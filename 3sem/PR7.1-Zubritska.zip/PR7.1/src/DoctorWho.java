import java.util.ArrayList;
import java.util.Collections;
import java.util.PriorityQueue;
import java.util.Scanner;

public class DoctorWho {
	
	static PriorityQueue<Integer> pq;

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		pq = new PriorityQueue<Integer>(Collections.reverseOrder());
		
		do {
		
		String[] a = in.nextLine().split(" ");
		for(int i = 0; i<a.length; i++) {
			int n = Integer.parseInt(a[i]);
			pq.add(n);
		}
		System.out.print("\n");
		if(isEveryoneSatisfied()) {
			System.out.println("ok");
		}else {
			System.out.println("fail");
		}
		pq.clear(); 
		}while(in.hasNext());
	}

	private static boolean isEveryoneSatisfied() {
		while (!pq.isEmpty())
		{
			int v = pq.remove();
			ArrayList<Integer> add = new ArrayList<>();
			while (v!=0)
			{
				if (pq.isEmpty()) return false;
				if (pq.peek() != 1) add.add(pq.peek() - 1);
				pq.remove();
				v--;
			}
			while(!add.isEmpty())
			{
				pq.add(add.get(0));
				add.remove(0);
			}
		}
		return true;
	}

}
