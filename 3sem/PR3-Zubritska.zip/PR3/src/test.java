import java.util.Iterator;

public class test {

	public static void main(String[] args) {
		RandomQueue<Integer> r = new RandomQueue<Integer>();
		
		r.enqueue(1);
		r.enqueue(2);
		r.enqueue(3);
		r.enqueue(4);
		
		System.out.println(r.sample());
		System.out.println(r.dequeue());
		
		Iterator<Integer> iterator = r.iterator(); 
		  
        System.out.println("List elements : "); 
  
        while (iterator.hasNext()) 
            System.out.print(iterator.next() + " "); 

	}

}
