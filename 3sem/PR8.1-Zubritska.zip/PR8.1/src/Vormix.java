import java.util.Scanner;

public class Vormix {
	
	static int INF = 1000000000;

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		int N = in.nextInt();
		int K = in.nextInt();
		
		int[][] timeTable = new int[N][K+1];
		
		int a;
		int t;
		
		a = in.nextInt();
		t = in.nextInt();
		
		for(int i = 1; i<=Math.min(a,  K); i++) {
			timeTable[0][i] = t;
		}
		
		for(int i = a+1; i<=K; i++) {
			timeTable[0][i] = INF;
		}
		
		for(int i = 1; i < N; i++) {
			a = in.nextInt();
			t = in.nextInt();
			
			for(int j = 1; j <= K; j++) {
				int thisT = t;
				
				if(j>a) thisT += timeTable[i-1][j-a];
				timeTable[i][j] = Math.min(timeTable[i-1][j], thisT);
				
			}
		}
		
		if(timeTable[N-1][K] == INF) {
			System.out.println(-1);
		}else {
			System.out.println(timeTable[N-1][K]);
		}
		
	}
}