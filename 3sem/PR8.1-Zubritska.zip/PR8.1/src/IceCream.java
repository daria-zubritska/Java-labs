import java.util.Scanner;

public class IceCream {
	
	static int k;
	static int n;
	static int[] m;

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		k = in.nextInt();
		n = in.nextInt(); 
		m = new int[k];
		
		for (int i = 0; i < k; i++) {
			m[i] = in.nextInt();
		}

		int left = 0;
		int right = 1000000000;
		while (left <= right)
		{
			int middle = (left + right)/2;
			if (Check(middle)) {
				left = middle + 1;
			}
			else right = middle - 1;
		}
		System.out.println(left - 1);
		
		in.close();

	}

	private static boolean Check(int Value)
	{
		int i, stall = 1, len = 0;
		for (i = 1; i < k; i++)
		{
			len += m[i] - m[i - 1];
			if (len >= Value) {
				len = 0; 
				stall++;
			}
		}
		return stall >= n;
	}

}
