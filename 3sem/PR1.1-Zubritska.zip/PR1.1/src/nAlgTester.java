
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.*;

public class nAlgTester {
	private final long i = 999500;
	private final long j = 999700;
	//private final long exp = ;
	
	@Test
	public void nAlgDefaultConstructorTester() {
		nAlg tester = new nAlg();
		assertNotNull(tester);
	}
	
	@Test
	public void nAlgConstructorTester() {
		nAlg tester = new nAlg(i, j);
		assertNotNull(tester);
		System.out.println(i + " " + j + " " + tester.getMaxCount());
	}
	
	@Test
	public void getMaxCountTester() {

		    
		nAlg tester = new nAlg(i, j);
		//assertEquals(exp, tester.getMaxCount());
		System.out.println(i + " " + j + " " + tester.getMaxCount());
	}

}
