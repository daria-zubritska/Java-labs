import java.math.BigInteger;

public class nAlg {
	
	private long maxCount = 0;
	
	public nAlg() {}

	public nAlg(long i, long j) {
		if(i<=0 || j<=0 || i>=1000000 || j>=1000000) {
			return;
		}
		else {
			findTheLongest(i, j);
		}
	}

	private void findTheLongest(long i, long j) {
		
		for(long k = i; k<=j; k++) {
			long count = 1;
			long n = k;
			while(n!=1) {
				
				if(n%2 != 0) {
					n = 3*n + 1;
				}else {
					n = n/2;
				}
				count++;
			}
			
			if(maxCount<count) {
				maxCount = count;
			}
			
		}
		
	}
	
	public long getMaxCount() {
		return maxCount;
	}
	
}
