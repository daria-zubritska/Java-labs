import java.util.Random;

public class Labyrinth {

	Random rgen = new Random();
	private int lamp = 0;
	private Graph labyrinth;
	private int start = 0;
	private String path = "";
	DepthFirstPaths dfs;
	BreadthFirstPaths bfs;

	public Labyrinth(int s, Graph G) {
		labyrinth = G;
		start = s;

//		dfs = new DepthFirstPaths(labyrinth, start);
		bfs = new BreadthFirstPaths(labyrinth, start);

		lamp = rgen.nextInt(G.V);
		while (lamp == start) {
			lamp = rgen.nextInt(G.V);
		}

		SearchForPath();
	}

	private void SearchForPath() {
		if (bfs.hasPathTo(lamp)) {
			
			path += "Path from " + start + " to " + lamp + "\n";
			
			for (int x : bfs.pathTo(lamp)) {
				path += "-" + x;
			}
		} else {
			path = "You can`t get to lamp " + lamp;
		}

	}

	public String toString() {
		return path;
	}

	private static String testFile = "testFile.txt";

	public static void main(String[] args) {
		In in = new In(testFile);
		int V = in.readInt();
		int s = in.readInt();
		String[] E = in.readAllLines();
		Graph G = new Graph(V, E);

		Labyrinth l = new Labyrinth(s, G);

		System.out.println(l.toString());
	}

}
