import java.util.ArrayList;

public class Graph {
	
	final int V;
	public ArrayList<Integer>[] adj;
	
	public Graph(int V, String[] edges){
		this.V=V;
		adj = new ArrayList[V];
		
		for (int v=0; v<V; v++) {
			adj[v] = new ArrayList<Integer>();
//			adj[v].clear();
		}
		
		for(int i = 1; i < edges.length; i ++) {
			String[] s = edges[i].split(" ");
			addEdge(Integer.parseInt(s[0]), Integer.parseInt(s[1]));
		}
	}
	
	public void addEdge(int v, int w){
		adj[v].add(w);
		adj[w].add(v);
	}
	
	public int degree(int v){
		int degree = 0;
		for (int w : adj(v))
			degree++;
		return degree;
	}
	
	public Iterable<Integer> adj(int v){
		return adj[v];
	}
}
