import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class PhoneNumbers {

	public static void main(String[] args) {
		try (BufferedReader read = new BufferedReader(new InputStreamReader(System.in))) {

		int t = Integer.parseInt(read.readLine());

		for (int i = 0; i < t; i++) {
			int n = Integer.parseInt(read.readLine());
			String[] nums = new String[n];
			boolean cont = false;

			for (int j = 0; j < n; j++) {
				nums[j] = read.readLine();
			}
			
			if(n == 1) {
				System.out.println("YES");
				continue;
			}

			Arrays.sort(nums);

			for (int j = 1; j < n; j++) {
				if (nums[j].startsWith(nums[j - 1])) {
					cont = true;
					break;
				}
			}

			if (!cont) {
				System.out.println("YES");
			} else {
				System.out.println("NO");
			}

		}

		} catch (IOException IOException) {

		}

	}
}
