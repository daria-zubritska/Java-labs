import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Merge {

	public static void main(String[] args) {
		try (BufferedReader read = new BufferedReader(new InputStreamReader(System.in))) {

			int n = Integer.parseInt(read.readLine());

			RobotNum ns[] = new RobotNum[n];

			for (int i = 0; i < n; i++) {
				String[] a = read.readLine().split(" ");
				ns[i] = new RobotNum(Integer.parseInt(a[0]), Integer.parseInt(a[1]), i);
			}

			Arrays.sort(ns);

			for (RobotNum k : ns) {
				System.out.println(k.i + " " + k.j);
			}

		} catch (IOException IOException) {

		}
	}

	static class RobotNum implements Comparable<RobotNum> {

		int i, j, k;

		RobotNum(int i, int j, int k) {
			this.i = i;
			this.j = j;
			this.k = k;
		}

		@Override
		public int compareTo(RobotNum o) {
			int c = this.i - o.i;
			return c == 0 ? this.k - o.k : c;
		}
	}
}