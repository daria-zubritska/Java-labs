import java.util.ArrayList;
import java.util.HashMap;

public class WordNet {

	private Digraph wordNet;
	private HashMap<String, ArrayList<Integer>> synMap;
	private final HashMap<Integer, String> synSets;
	private final SAP sap;

	// конструктор приймає назви двох файлів
	public WordNet(String synsets, String hypernyms) {
		synMap = new HashMap<String, ArrayList<Integer>>();
		synSets = new HashMap<Integer, String>();

		int count = readSynsets(synsets);
		wordNet = new Digraph(count);

		readHypernyms(hypernyms);

		sap = new SAP(wordNet);
	}

	private int readSynsets(String synsets) {
		if (synsets == null)
			throw new IllegalArgumentException();
		In in = new In(synsets);
		int count = 0;
		while (in.hasNextLine()) {
			count++;
			String line = in.readLine();
			String[] parts = line.split(",");
			int id = Integer.parseInt(parts[0]);
			synSets.put(id, parts[1]);
			String[] nouns = parts[1].split(" ");
			for (String n : nouns) {
				if (synMap.get(n) != null) {
					ArrayList<Integer> bag = synMap.get(n);
					bag.add(id);
				} else {
					ArrayList<Integer> bag = new ArrayList<Integer>();
					bag.add(id);
					synMap.put(n, bag);
				}
			}
		}
		return count;
	}

	private void readHypernyms(String hypernyms) {
		if (hypernyms == null)
			throw new IllegalArgumentException();

		In in = new In(hypernyms);

		while (in.hasNextLine()) {
			String line = in.readLine();
			String[] parts = line.split(",");

			int v = Integer.parseInt(parts[0]);

			for (int i = 1; i < parts.length; i++) {
				int w = Integer.parseInt(parts[i]);
				wordNet.addEdge(v, w);
			}
		}
	}

	// множина іменників, що повертається як ітератор (без дублікатів)
	public Iterable<String> nouns() {
		return synMap.keySet();
	}

	// чи є слово серед WordNet іменників?
	public boolean isNoun(String word) {
		if (word == null)
			throw new IllegalArgumentException();
		return synMap.containsKey(word);
	}

	// відстань між nounA і nounB
	public int distance(String nounA, String nounB) {
		ArrayList<Integer> idsA = synMap.get(nounA);
		ArrayList<Integer> idsB = synMap.get(nounB);

		return sap.length(idsA, idsB);
	}

	// синсет що є спільним предком nounA і nounB
	// в найкоршому шляху до предка
	public String sap(String nounA, String nounB) {
		ArrayList<Integer> idsA = synMap.get(nounA);
		ArrayList<Integer> idsB = synMap.get(nounB);

		int id = sap.ancestor(idsA, idsB);
		return synSets.get(id);
	}

}
