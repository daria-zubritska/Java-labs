import java.util.HashMap;
import java.util.HashSet;

public class SAP {

	private final Digraph digraph;
	private final HashMap<HashSet<Integer>, int[]> cache;

	// конструктор приймає орграф (не обов’язково DAG)
	public SAP(Digraph G) {
		if (G == null) {
			throw new IllegalArgumentException();
		}

		digraph = new Digraph(G);
		cache = new HashMap<>();
	}

	// довжина найкоротшого шляху до спільного батька v та w
	// -1 якщо такого шляху немає
	public int length(int v, int w) {
		sap(v, w);
		HashSet<Integer> key = new HashSet<>();
		key.add(v);
		key.add(w);
		int[] value = cache.get(key);
		return value[0];
	}

	// спільний батько v та w, з найкоротшого шляху
	// -1 якщо такого шляху немає
	public int ancestor(int v, int w) {
		sap(v, w);
		HashSet<Integer> key = new HashSet<>();
		key.add(v);
		key.add(w);
		int[] value = cache.get(key);
		return value[1];
	}

	// довжина найкоротшого шляху між будь-якою вершиною з v та з w;
	// -1 якщо такого шляху немає
	public int length(Iterable<Integer> v, Iterable<Integer> w) {
		return sap(v, w)[0];
	}

	// спільний батько з найкоротшого шляху …;
	// -1 якщо такого шляху немає
	public int ancestor(Iterable<Integer> v, Iterable<Integer> w) {
		return sap(v, w)[1];
	}

	private void sap(int v, int w) {

		HashSet<Integer> key = new HashSet<>();
		key.add(v);
		key.add(w);

		if (cache.containsKey(key))
			return;

		BreadthFirstPaths vPath = new BreadthFirstPaths(digraph, v);
		BreadthFirstPaths wPath = new BreadthFirstPaths(digraph, w);

		int distance = Integer.MAX_VALUE;
		int ancestor = -2;
		for (int vertex = 0; vertex < digraph.V; vertex++) {
			if (vPath.hasPathTo(vertex) && vPath.distTo(vertex) < distance && wPath.hasPathTo(vertex)
					&& wPath.distTo(vertex) < distance) {
				int sum = vPath.distTo(vertex) + wPath.distTo(vertex);
				if (distance > sum) {
					distance = sum;
					ancestor = vertex;
				}
			}
		}

		if (distance == Integer.MAX_VALUE) {
			distance = -1;
			ancestor = -1;
		}

		int[] value = new int[] { distance, ancestor };
		cache.put(key, value);
	}

	private int[] sap(Iterable<Integer> v, Iterable<Integer> w) {

		BreadthFirstPaths vPath = new BreadthFirstPaths(digraph, v);
		BreadthFirstPaths wPath = new BreadthFirstPaths(digraph, w);

		int distance = Integer.MAX_VALUE;
		int ancestor = -2;

		for (int vertex = 0; vertex < digraph.V; vertex++) {
			if (vPath.hasPathTo(vertex) && vPath.distTo(vertex) < distance && wPath.hasPathTo(vertex)
					&& wPath.distTo(vertex) < distance) {
				int sum = vPath.distTo(vertex) + wPath.distTo(vertex);
				if (distance > sum) {
					distance = sum;
					ancestor = vertex;
				}
			}
		}

		if (distance != Integer.MAX_VALUE) {
			return new int[] { distance, ancestor };
		} else {
			return new int[] { -1, -1 };
		}
	}

	public static void main(String[] args) {
		In in = new In("digraph1.txt");
		Digraph G = new Digraph(in);
		SAP sap = new SAP(G);
		
		while (!StdIn.isEmpty()) {
			int v = StdIn.readInt();
			int w = StdIn.readInt();
			
			int length = sap.length(v, w);
			int ancestor = sap.ancestor(v, w);
			
			StdOut.printf("length = %d, ancestor = %d\n", length, ancestor);
		}

	}

}
