import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Stack;

public class Digraph {

	public final int V;
	public int E;
	private ArrayList<Integer>[] adj;
	private int[] indegree;

	public Digraph(int V) {
		if (V < 0)
			throw new IllegalArgumentException();
		this.V = V;
		this.E = 0;
		indegree = new int[V];
		adj = (ArrayList<Integer>[]) new ArrayList[V];
		for (int v = 0; v < V; v++) {
			adj[v] = new ArrayList<Integer>();
		}
	}

	public Digraph(In in) {
		if (in == null)
			throw new IllegalArgumentException();
		try {
			this.V = in.readInt();
			if (V < 0)
				throw new IllegalArgumentException();
			indegree = new int[V];
			adj = (ArrayList<Integer>[]) new ArrayList[V];
			for (int v = 0; v < V; v++) {
				adj[v] = new ArrayList<Integer>();
			}
			int E = in.readInt();
			if (E < 0)
				throw new IllegalArgumentException();
			for (int i = 0; i < E; i++) {
				int v = in.readInt();
				int w = in.readInt();
				addEdge(v, w);
			}
		} catch (NoSuchElementException e) {
			throw new IllegalArgumentException();
		}
	}

	public Digraph(Digraph G) {
		if (G == null)
			throw new IllegalArgumentException();

		this.V = G.V;
		this.E = G.E;
		if (V < 0)
			throw new IllegalArgumentException();

		indegree = new int[V];
		for (int v = 0; v < V; v++)
			this.indegree[v] = G.indegree(v);

		adj = (ArrayList<Integer>[]) new ArrayList[V];
		for (int v = 0; v < V; v++) {
			adj[v] = new ArrayList<Integer>();
		}

		for (int v = 0; v < G.V; v++) {
			Stack<Integer> reverse = new Stack<Integer>();
			for (int w : G.adj[v]) {
				reverse.push(w);
			}
			for (int w : reverse) {
				adj[v].add(w);
			}
		}
	}

	public void addEdge(int v, int w) {
		adj[v].add(w);
		indegree[w]++;
		E++;
	}

	public int degree(int v) {
		int degree = 0;
		for (int w : adj(v))
			degree++;
		return degree;
	}

	public int indegree(int v) {
		return indegree[v];
	}

	public int outdegree(int v) {
		return adj[v].size();
	}

	public Iterable<Integer> adj(int v) {
		return adj[v];
	}

}
