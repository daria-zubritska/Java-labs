import java.util.Arrays;

public class Outcast {

	private final WordNet wordnet;

	public Outcast(WordNet wordnet) {
		this.wordnet = wordnet;
	}

	// маючи масив WordNet іменників, повернути «ізгоя»
	public String outcast(String[] nouns) {
		String outcast = nouns[0];
		int d = dSum(nouns[0], nouns);

		for (int i = 1; i < nouns.length; i++) {
			int tempdist = dSum(nouns[i], nouns);

			if (d < tempdist) {
				d = tempdist;
				outcast = nouns[i];
			}
		}

		return outcast;
	}

	private int dSum(String noun, String[] nouns) {
		int d = 0;
		for (String n : nouns) {
			d += wordnet.distance(noun, n);
		}
		return d;
	}

	public static void main(String[] args) {
		WordNet wordnet = new WordNet("synsets.txt", "hypernyms.txt");
		Outcast outcast = new Outcast(wordnet);

		 In in = new In("testOut.txt"); 
	        String[] strings = in.readLine().split(" "); 
	        System.out.println(outcast.outcast(strings)); 

	}

}
