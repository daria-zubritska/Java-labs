import java.util.LinkedList;
import java.util.Stack;

public class BreadthFirstPaths {
	private boolean[] marked;
	private int[] edgeTo;
	private int[] distTo;
	private int s;

	public BreadthFirstPaths(Digraph G, int s) {
		this.s = s;
		edgeTo = new int[G.V];
		marked = new boolean[G.V];
		distTo = new int[G.V];
		bfs(G, s);
	}
	
	public BreadthFirstPaths(Digraph G, Iterable<Integer> sources) {
        marked = new boolean[G.V];
        distTo = new int[G.V];
        edgeTo = new int[G.V];
        for (int v = 0; v < G.V; v++)
            distTo[v] = Integer.MAX_VALUE;
        bfs(G, sources);
    }
	
	private void bfs(Digraph G, Iterable<Integer> sources) {
		LinkedList<Integer> q = new LinkedList<>();
        for (int s : sources) {
            marked[s] = true;
            distTo[s] = 0;
            q.add(s);
        }
        while (!q.isEmpty()) {
            int v = q.remove();
            for (int w : G.adj(v)) {
                if (!marked[w]) {
                    edgeTo[w] = v;
                    distTo[w] = distTo[v] + 1;
                    marked[w] = true;
                    q.add(w);
                }
            }
        }
    }

	private void bfs(Digraph G, int s) {
		LinkedList<Integer> q = new LinkedList<>();

		q.add(s);
		marked[s] = true;
		distTo[s] = 0;
		while (!q.isEmpty()) {
			int v = q.remove();
			for (int w : G.adj(v)) {
				if (!marked[w]) {
					q.add(w);
					marked[w] = true;
					edgeTo[w] = v;
					distTo[w] = distTo[v] + 1;
				}
			}
		}
	}

	public boolean hasPathTo(int v) {
		return marked[v];
	}
	
	public int distTo(int v) {
        return distTo[v];
    }

	public Iterable<Integer> pathTo(int v) {
		if (!hasPathTo(v))
			return null;
		Stack<Integer> path = new Stack<Integer>();
		for (int x = v; x != s; x = edgeTo[x])
			path.push(x);
		path.push(s);
		return path;
	}

}
