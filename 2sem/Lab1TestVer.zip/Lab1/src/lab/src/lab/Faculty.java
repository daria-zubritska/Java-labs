package lab.src.lab;

public class Faculty {
	static Faculty[] fac = new Faculty[10];
	String nameF;
	int indexF;
	static int counterF;
	int amountOfDep;
	Department[] dep = new Department[10];
	
	public Faculty() {
		//it is here
	}

	public Faculty(String nameF) {
		this.nameF = nameF;
		this.indexF = counterF;
		this.dep = new Department[10];
		this.amountOfDep = 0;
	}

	public void addFac (String nameF) {
		Faculty f = new Faculty(nameF);

		if (fac.length > counterF)
			fac[counterF] = f;
		else {
			Faculty temp[] = new Faculty[counterF + 10];
			temp = fac;
			for (int i = 0; i < fac.length; i++)
				temp[i] = fac[i];
			fac = temp;
			fac[counterF] = f;
		}
		counterF++;
	}

	public Faculty getFac(int i) {
		return fac[i];
	}

	public void setFac(Faculty[] fac) {
		Faculty.fac = fac;
	}

	public String getNameF() {
		return nameF;
	}

	public void setNameF(String nameF) {
		this.nameF = nameF;
	}
	
	public int getCounter() {
		return counterF;
	}
}
