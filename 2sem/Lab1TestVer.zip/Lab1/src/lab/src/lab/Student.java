package lab.src.lab;

public class Student extends Department {
	
	String nameS; 
	String surnameS;
	int ageS; 
	double avgM;
	static int counterS = 0;
	int indexS; 
	String patronimicS;
	String courseS;
	int groupS;
	
	public Student(String nameF, String nameD, int ageS, String nameS, String SurnameS, double avgM, int i, int j, String patronimics, String courses, int groups) {
		super(nameF, nameD, i);
		this.ageS = ageS;
		this.nameS = nameS;
		this.surnameS = SurnameS;
		this.avgM = avgM;
		
		if(fac[i]==null) {
			System.out.println("Sorry, you must creat a faculty at first!");
			return;
		}
		
		if(fac[i].dep[j]==null) {
			System.out.println("Sorry, you must creat a department at first!");
			return;
		}
		
		this.indexS = fac[i].dep[j].amountOfStudents;
		this.patronimicS = patronimics; 
		this.courseS = patronimics;
		this.groupS = groups;
	}
	
	public Student() {
		// it is here
	}

	public void addSt(int i,int j, int ageS, String nameS, String Surname, double avgM, String patronimicS, String courseS, int groupS){
		Student st = new Student(fac[i].getNameF(), dep[j].getNameD(),  ageS, nameS, surnameS, avgM, i, j, patronimicS, courseS, groupS); // Ð²Ñ‹Ð½ÐµÑ�Ð¸ Ð¿ÐµÑ€ÐµÐ´ Ð¼ÐµÑ‚Ð¾Ð´Ð°Ð¼Ð¸ addSt && reSet
	    
		if(fac[i].dep[j].students.length>fac[i].dep[j].amountOfStudents) 
	    	fac[i].dep[j].students[fac[i].dep[j].amountOfStudents] = st;
	    
	    else {
	    	Student temp [] = new Student[fac[i].dep[j].amountOfStudents +10];
	    	temp = students;
	    			for (int k = 0; k < fac[i].dep[j].students.length; k++) 
						temp[k] = fac[i].dep[j].students[k];
	    			fac[i].dep[j].students = temp; 
	    }
	    
	    counterS++;
	   fac[i].dep[j].amountOfStudents++;
	}
	
	public void reSet(int i, int j, int k, int facTochange, int depToChange, int ageS, String nameS, String Surname, double avgM,String patronimicS, String courseS, int groupS) {
		 addSt(facTochange, depToChange, ageS, nameS, surnameS, avgM ,patronimicS , courseS, groupS);
		 
		 if(fac[facTochange]==null) 
			 return;
		 
			 if(fac[facTochange].dep[depToChange]==null)
			   return;
			 
			 else
			 fac[i].dep[j].students[k] = null; 
			 fac[i].dep[j].dep[j].amountOfStudents--;
			 counterS--;
	}
	
	public void delete(int i, int j, int k) {
	fac[i].dep[j].students[k] = null; 
	counterS--;
	}
	
	public Student[]allStudents() {
		int counter = 0;
		Student[] allStudents = new Student[counterS];
	
		for (int i = 0; i < fac.length; i++) {
			
			for (int j = 0; j < fac[i].dep.length; j++) {
				
				for (int j2 = 0; j2 < fac[i].dep[j].students.length; j2++) {
					
					allStudents[counter] = fac[i].dep[j].students[j2];
					counter++;
				}
			}
		}
		
		return allStudents;
	}
	
    public Student [] searchByCourse(String course) {
    	Student [] courseSearch = new Student[counterS]; 
    	
    	for (int i = 0; i < allStudents().length; i++) {
    		
				if(allStudents()[i].getCourseS().equals(course))
				courseSearch [i] = allStudents()[i];  
		}
    	
    	return courseSearch;
    }
    
    public Student [] searchByName(String nameS) {
    	Student [] byName = new Student[counterS]; 
    	
    	for (int i = 0; i < allStudents().length; i++) {
    		
			if(allStudents()[i].getNameS().equals(nameS)) 
			byName[i] = allStudents()[i];
			}
    	
    	return byName;
    }
    
    public Student [] searchBySurname(String surnameS) {
    	Student [] byName = new Student[counterS];
    	
    	for (int i = 0; i < allStudents().length; i++) {
    		
			if(allStudents()[i].getSurnameS().equals(surnameS)) 
			byName[i] = allStudents()[i];
			}
    	
    	return byName;
    }
    
    public Student [] searchByPatronymic(String patronymicS) {
    	Student [] byName = new Student[counterS]; 
    	
    	for (int i = 0; i < allStudents().length; i++) {
    		
			if(allStudents()[i].getPatronimicS().equals(patronymicS)) 
			byName[i] = allStudents()[i];
			}
    	
    	return byName;
    }
    
    public Student [] searchByNameSurnamePatronymic(String nameS, String surname, String patronymicS) {
     	Student [] byName = new Student[counterS]; 
     	
    	for (int i = 0; i < allStudents().length; i++) {
    		
			if(allStudents()[i].getNameS().equals(patronymicS)&&allStudents()[i].getSurnameS().equals(surname)&&allStudents()[i].getPatronimicS().equals(patronymicS)) 
			byName[i] = allStudents()[i];
			}
    	
    	return byName;
    }
    
    public Student [] searchByGroup(int i) {
    	Student [] byName = new Student[counterS]; 
    	
    	for (int j = 0; j < allStudents().length; j++) {
    		if(allStudents()[j].getGroupS()==i)
			byName[j] = allStudents()[j];
		}
    	
    	return byName;
    }
    
	public String getCourseS() {
		return courseS;
	}
	
	public void setCourseS(String courseS) {
		this.courseS = courseS;
	}
	
	public String getNameS() {
		return nameS;
	}
	
	public void setNameS(String nameS) {
		this.nameS = nameS;
	}
	
	public String getSurnameS() {
		return surnameS;
	}
	
	public void setSurnameS(String surnameS) {
		this.surnameS = surnameS;
	}
	
	public String getPatronimicS() {
		return patronimicS;
	}
	
	public void setPatronimicS(String patronimicS) {
		this.patronimicS = patronimicS;
	}
	
	public int getGroupS() {
		return groupS;
	}
	
	public void setGroupS(int groupS) {
		this.groupS = groupS;
	}
	
	@Override
	public String toString() {
		return "Student [nameS=" + nameS + ", surnameS=" + surnameS + ", ageS=" + ageS + ", avgM=" + avgM + ", indexS="
				+ indexS + ", patronimicS=" + patronimicS + ", courseS=" + courseS + ", groupS=" + groupS + "]";
	}
	
	public int getAgeS() {
		return ageS;
	}
	
	public void setAgeS(int ageS) {
		this.ageS = ageS;
	}
	
	public double getAvgM() {
		return avgM;
	}
	
	public void setAvgM(double avgM) {
		this.avgM = avgM;
	}
	
	public static int getCounter(int i, int j) {
		return fac[i].dep[j].amountOfStudents;
	}
	
	public static void setCounterS(int counterS) {
		Student.counterS = counterS;
	}
	
	public int getIndexS() {
		return indexS;
	}
	
	public void setIndexS(int indexS) {
		this.indexS = indexS;
	}
	
	public Student getStudent(int i, int j, int k) {
		return fac[i].dep[j].students[k];
	}
    
}

