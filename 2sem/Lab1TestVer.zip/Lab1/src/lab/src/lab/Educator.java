package lab.src.lab;

public class Educator extends Department {
	Educator[] ed = new Educator[10];
	String nameE;
	String SurnameE;
	int ageE;
	static int counterE;
	String patronimicE;
	String courseE;
	int groupE;
	int j;
	int indexE;

	public Educator(String nameF, String nameD, int i, int j, String nameE, String SurnameE,
			int ageE, String patronimicE, String courseE, int groupE) {
		super(nameF, nameD, i);
		this.j = j;
		this.nameE = nameE;
		this.SurnameE = SurnameE;
		this.ageE = ageE;
		this.patronimicE = patronimicE;
		if (fac[i] == null) {
			System.out.println("Sorry, you must creat a faculty at first!");
			return;
		}
		if (fac[i].dep[j] == null) {
			System.out.println("Sorry, you must creat a department at first!");
			return;
		}
		this.indexE = fac[i].dep[j].amountOfEducators;
		this.courseE = courseE;
		this.groupE = groupE;
	}

	public Educator() {
		// it is here
	}

	public void addSt(int i, int j, String nameE, String SurnameE, int ageE, String patronimicE, String courseE,
			int groupE) {
		Educator ed = new Educator(fac[i].getNameF(), fac[i].dep[j].nameD, i, j,
				nameE, SurnameE, ageE, patronimicE, courseE, groupE); 
		
		if (fac[i].dep[j].educators.length > fac[i].dep[j].amountOfEducators)
			fac[i].dep[j].educators[fac[i].dep[j].amountOfEducators] = ed;
		else {
			Educator temp[] = new Educator[fac[i].dep[j].amountOfEducators + 10];
			temp = fac[i].dep[j].educators;
			for (int k = 0; k < fac[i].dep[j].educators.length; k++)
				temp[k] = fac[i].dep[j].educators[k];
			fac[i].dep[j].educators = temp;
		}
		counterE++;
		fac[i].dep[j].amountOfEducators++;
	}

	public void reSet(int i, int j, int k, int facTochange, int depToChange, String nameE, String SurnameE, int ageE,
			String patronimicE, String courseE, int groupE) {
		addSt(facTochange, depToChange, nameE, SurnameE, ageE, patronimicE, courseE, groupE);
		if (fac[facTochange] == null)
			return;
		if (fac[facTochange].dep[depToChange] == null)
			return;
		else
			fac[i].dep[j].students[k] = null;
		fac[i].dep[j].dep[j].amountOfStudents--;
		counterE--;
	}

	public void delete(int i, int j, int k) {
		fac[i].dep[j].students[k] = null;
		counterE--;
	}

	public Educator[] allEducators() {
		int counter = 0;
		Educator[] allEducators = new Educator[counterE];
		for (int i = 0; i < fac.length; i++) {
			for (int j = 0; j < fac[i].dep.length; j++) {
				for (int j2 = 0; j2 < fac[i].dep[j].educators.length; j2++) {
					allEducators[counter] = fac[i].dep[j].educators[j2];
					counter++;
				}
			}
		}
		return allEducators;
	}

	public Educator[] searchByCourse(String course) {
		Educator[] courseSearch = new Educator[counterE];
		for (int i = 0; i < allEducators().length; i++) {
			if (allEducators()[i].getCourseE().equals(course))
				courseSearch[i] = allEducators()[i];
		}
		return courseSearch;
	}

	public Educator[] searchByName(String nameS) {
		Educator[] byName = new Educator[counterE];
		for (int i = 0; i < allEducators().length; i++) {
			if (allEducators()[i].getNameE().equals(nameS))
				byName[i] = allEducators()[i];
		}
		return byName;
	}

	public Educator[] searchBySurname(String surnameS) {
		Educator[] byName = new Educator[counterE];
		for (int i = 0; i < allEducators().length; i++) {
			if (allEducators()[i].getSurnameE().equals(surnameS))
				byName[i] = allEducators()[i];
		}
		return byName;
	}

	public Educator[] searchByPatronymic(String patronymicS) {
		Educator[] byName = new Educator[counterE];
		for (int i = 0; i < allEducators().length; i++) {
			if (allEducators()[i].getPatronimicE().equals(patronymicS))
				byName[i] = allEducators()[i];
		}
		return byName;
	}

	public Educator[] searchByNameSurnamePatronymic(String nameS, String surname, String patronymicS) {
		Educator[] byName = new Educator[counterE];
		for (int i = 0; i < allEducators().length; i++) {
			if (allEducators()[i].getNameE().equals(patronymicS) && allEducators()[i].getSurnameE().equals(surname)
					&& allEducators()[i].getPatronimicE().equals(patronymicS))
				byName[i] = allEducators()[i];
		}
		return byName;
	}

	public Educator[] searchByGroup(int i) {
		Educator[] byName = new Educator[counterE];
		for (int j = 0; j < allEducators().length; j++) {
			if (allEducators()[j].getGroupE() == i)
				byName[j] = allEducators()[j];
		}
		return byName;
	}

	public Educator[] getEd() {
		return ed;
	}

	public void setEd(Educator[] ed) {
		this.ed = ed;
	}

	public String getNameE() {
		return nameE;
	}

	public void setNameE(String nameE) {
		this.nameE = nameE;
	}

	public String getSurnameE() {
		return SurnameE;
	}

	public void setSurnameE(String surnameE) {
		SurnameE = surnameE;
	}

	public int getAgeE() {
		return ageE;
	}

	public void setAgeE(int ageE) {
		this.ageE = ageE;
	}

	public static int getCounterE() {
		return counterE;
	}

	public static void setCounterE(int counterE) {
		Educator.counterE = counterE;
	}

	public String getPatronimicE() {
		return patronimicE;
	}

	public void setPatronimicE(String patronimicE) {
		this.patronimicE = patronimicE;
	}

	public String getCourseE() {
		return courseE;
	}

	public void setCourseE(String courseE) {
		this.courseE = courseE;
	}

	public int getGroupE() {
		return groupE;
	}

	public void setGroupE(int groupE) {
		this.groupE = groupE;
	}

	public int getJ() {
		return j;
	}

	public void setJ(int j) {
		this.j = j;
	}

	public int getIndexE() {
		return indexE;
	}

	public void setIndexE(int indexE) {
		this.indexE = indexE;
	}

}
