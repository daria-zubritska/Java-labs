package project;

/*Написати програму, що буде формувати список студентів та викладачів університету НаУКМА.

Відповідно мають бути реалізовані такі можливості роботи, як:

Створити/видалити/редагувати факультет.
Створити/видалити/редагувати кафедру факультета.
Додати/видалити/редагувати студента/викладача до кафедри.
Знайти студента/викладача за ПІБ, курсом або групою.
Вивести всіх студентів впорядкованих за курсами.
Вивести всіх студентів/викладачів факультета впорядкованих за алфавітом.
Вивести всіх студентів кафедри впорядкованих за курсами.
Вивести всіх студентів/викладачів кафедри впорядкованих за алфавітом.
Вивести всіх студентів кафедри вказаного курсу.
Вивести всіх студентів кафедри вказаного курсу впорядкованих за алфавітом.
 * */

import utils.*;

import java.io.IOException;

import lab.src.lab.*;

public class menuLab1 {
	static int n;

	static Faculty adminFac = new Faculty();
	static Department adminDep = new Department();
	static Student adminStud = new Student();
	static Educator adminEd = new Educator();

	
	//перший інтерфейс
	public static void main(String[] arg) throws IOException {

		while (true) {

			System.out.println("0. Завершити виконання програми.\r\n" + "1. Створити/видалити/редагувати факультет.\r\n"
					+ "2. Створити/видалити/редагувати кафедру факультета.\r\n"
					+ "3. Додати/видалити/редагувати студента/викладача до кафедри.\r\n"
					+ "4. Знайти студента/викладача за ПІБ, курсом або групою.\r\n"
					+ "5. Вивести всіх студентів впорядкованих за курсами.\r\n"
					+ "6. Вивести всіх студентів/викладачів факультета впорядкованих за алфавітом.\r\n"
					+ "7. Вивести всіх студентів кафедри впорядкованих за курсами.\r\n"
					+ "8. Вивести всіх студентів/викладачів кафедри впорядкованих за алфавітом.\r\n"
					+ "9. Вивести всіх студентів кафедри вказаного курсу.\r\n"
					+ "10. Вивести всіх студентів кафедри вказаного курсу впорядкованих за алфавітом.");

			n = DataInput.getInt("Введіть номер, що відповідає потрібній команді: ");

			while (n < 0 || n > 10) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Роботу завершено.");
				break;
			}

			menu();

		}

	}

	//перехід між функціями головного меню
	private static void menu() throws IOException {

		switch (n) {

		case (1): {

			createDeleteRedFaculty();

			break;
		}

		case (2): {

			createDeleteRedDepartment();

			break;
		}

		case (3): {

			createDeleteRedStudentOrTeacher();

			break;
		}

		case (4): {

			findSomeone();

			break;
		}

		case (5): {

			studentsList();

			break;
		}

		case (6): {

			studentsOrTeachersAlphabetList();

			break;
		}

		case (7): {

			studentsListByCoursesDep();

			break;
		}

		case (8): {

			studentsOrTeachersListAlphabetDepartment();

			break;
		}

		case (9): {

			studentsListDepartmentCourse();

			break;
		}

		case (10): {

			studentsListDepCourAlphabet();

			break;
		}

		}
	}

	//Вивести всіх студентів кафедри вказаного курсу впорядкованих за алфавітом.
	private static void studentsListDepCourAlphabet() {
		while (true) {

			System.out.println(
					"(1)Вивести всіх студентів кафедри вказаного курсу впорядкованих за алфавітом. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 1) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}

			// вивести всіх студентів кафедри вказаного курсу впорядкованих за алфавітом
			break;

		}

	}

	//Вивести всіх студентів кафедри вказаного курсу.
	private static void studentsListDepartmentCourse() {
		while (true) {

			System.out.println("(1)Вивести всіх студентів кафедри вказаного курсу. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 1) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}

			// вивести всіх студентів кафедри певного курсу
			break;

		}

	}

	//Вивести всіх студентів/викладачів кафедри впорядкованих за алфавітом.
	private static void studentsOrTeachersListAlphabetDepartment() {
		while (true) {

			System.out.println(
					"Вивести всіх (1)студентів/(2)викладачів кафедри впорядкованих за алфавітом. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 2) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}

			switch (n) {
			case (1): {
				// вивести за алфавітом всіх студентів КАФЕДРИ впорядкованих за алфавітом
				break;
			}
			case (2): {
				// вивести за алфавітом всіх викладачів КАФЕДРИ впорядкованих за алфавітом
				break;
			}

			}
		}

	}

	//Вивести всіх студентів кафедри впорядкованих за курсами.
	private static void studentsListByCoursesDep() {
		while (true) {

			System.out.println("(1)Вивести всіх студентів кафедри впорядкованих за курсами. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 1) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}

			// вивести всіх студентів КАФЕДРИ впорядкованих за курсами
			break;
		}

	}

	//Вивести всіх студентів/викладачів факультета впорядкованих за алфавітом
	private static void studentsOrTeachersAlphabetList() {
		while (true) {

			System.out.println(
					"Вивести всіх (1)студентів/(2)викладачів факультета впорядкованих за алфавітом. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 2) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}

			switch (n) {
			case (1): {
				// вивести студентів факультету впорядкованних за алфавітом
				break;
			}
			case (2): {
				// вивести викладачів факультету впорядкованних за алфавітом
				break;
			}

			}
		}

	}

	//Вивести всіх студентів впорядкованих за курсами.
	private static void studentsList() {

		while (true) {

			System.out.println("(1)Вивести всіх студентів впорядкованих за курсами. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 1) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}

			// вивести ВСІХ студентів впорядкованних за курсами
			break;
		}

	}

	//Знайти студента/викладача за ПІБ, курсом або групою.
	private static void findSomeone() {
		while (true) {

			System.out
					.println("Знайти студента/викладача за (1)ПІБ, (2)курсом або (3)групою. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 3) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}

			switch (n) {
			case (1): {
				// ПІБ
				System.out.println("Знайти (1)студента/(2)викладача за ПІБ. 0 - вийти в попереднє меню.");

				n = DataInput.getInt("Введіть номер команди: ");

				while (n < 0 || n > 2) {
					n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
				}

				if (n == 0) {
					System.out.println("Повертаюсь до попереднього меню.");
					break;
				}

				switch (n) {
				case (1): {
					// знайти студента за піб
					break;
				}
				case (2): {
					// знайти викладача за піб
					break;
				}
				}
			}
			case (2): {
				// курс
				System.out.println("Знайти (1)студента/(2)викладача за курсом. 0 - вийти в попереднє меню.");

				n = DataInput.getInt("Введіть номер команди: ");

				while (n < 0 || n > 2) {
					n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
				}

				if (n == 0) {
					System.out.println("Повертаюсь до попереднього меню.");
					break;
				}

				switch (n) {
				case (1): {
					// знайти студента за курсом
					break;
				}
				case (2): {
					// знайти викладача за курсом
					break;
				}
				}
			}
			case (3): {
				// група
				System.out.println("Знайти (1)студента/(2)викладача за групою. 0 - вийти в попереднє меню.");

				n = DataInput.getInt("Введіть номер команди: ");

				while (n < 0 || n > 2) {
					n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
				}

				if (n == 0) {
					System.out.println("Повертаюсь до попереднього меню.");
					break;
				}

				switch (n) {
				case (1): {
					// знайти студента за групою
					break;
				}
				case (2): {
					// знайти викладача за групою
					break;
				}
				}
			}
			}
		}

	}

	//Додати/видалити/редагувати студента/викладача до кафедри.
	private static void createDeleteRedStudentOrTeacher() throws IOException {
		while (true) {

			System.out.println(
					"(1)Додати/(2)видалити/(3)редагувати студента/викладача до кафедри. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 3) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}

			switch (n) {
			case (1): {
				// додати студента\викладача
				System.out.println("Додати (1)студента/(2)викладача до кафедри. 0 - вийти в попереднє меню.");
				
				n = DataInput.getInt("Введіть номер команди: ");

				while (n < 0 || n > 2) {
					n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
				}

				if (n == 0) {
					System.out.println("Повертаюсь до попереднього меню.");
					break;
				}

				switch (n) {
				case (1): {
					// додати студента до кафедри
					int i = realFaculty();
					int j = realDepartment(i);
					
					System.out.println("Введіть ім'я студента: ");
					String nameS = DataInput.getString();
					
					System.out.println("Введіть прізвище студента: ");
					String Surname = DataInput.getString();
					
					System.out.println("Введіть ім'я по батькові студента: ");
					String patronymicS = DataInput.getString();
					
					int ageS = DataInput.getInt("Введіть вік студента: ");
					
					System.out.println("Введіть середню оцінку студента: ");
					double avgM = DataInput.getDouble();
					
					System.out.println("Введіть курс студента: ");
					String courseS = DataInput.getString();
					
					int groupS = DataInput.getInt("Введіть групу студента: ");
					
					adminStud.addSt(i, j, ageS, nameS, Surname, avgM, patronymicS, courseS, groupS);
					break;

				}
				case (2): {
					// додати викладача до кафедри
					int i = realFaculty();
					int j = realDepartment(i);
					
					System.out.println("Введіть ім'я викладача: ");
					String nameE = DataInput.getString();
					
					System.out.println("Введіть прізвище викладача: ");
					String Surname = DataInput.getString();
					
					System.out.println("Введіть ім'я по батькові викладача: ");
					String patronymicE = DataInput.getString();
					
					int ageE = DataInput.getInt("Введіть вік викладача: ");
					
					System.out.println("Введіть курс викладача: ");
					String courseE = DataInput.getString();
					
					int groupE = DataInput.getInt("Введіть групу викладача: ");
					
					adminEd.addSt(i, j, nameE, Surname, ageE, patronymicE, courseE, groupE);
					break;
				}
				}
			}
			case (2): {
				// видалити студента\викладача
				System.out.println("Видалити (1)студента/(2)викладача з кафедри. 0 - вийти в попереднє меню.");

				n = DataInput.getInt("Введіть номер команди: ");

				while (n < 0 || n > 2) {
					n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
				}

				if (n == 0) {
					System.out.println("Повертаюсь до попереднього меню.");
					break;
				}

				switch (n) {
				case (1): {
					// видалити студента
					int i = realFaculty();
					int j = realDepartment(i);
					int k = realStudent(i, j);
					
					adminStud.delete(i, j, k);
					break;
				}
				case (2): {
					// видалити викладача
					break;
				}
				}
			}
			case (3): {
				// редагувати студента\викладача
				System.out.println("Редагувати (1)студента/(2)викладача кафедри. 0 - вийти в попереднє меню.");

				n = DataInput.getInt("Введіть номер команди: ");

				while (n < 0 || n > 2) {
					n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
				}

				if (n == 0) {
					System.out.println("Повертаюсь до попереднього меню.");
					break;
				}

				switch (n) {
				case (1): {
					// редагувати студента
					break;
				}
				case (2): {
					// редагувати викладача
					break;
				}
				}
			}

			}
		}

	}

	private static int realStudent(int i, int j) {
	
		int k=0;

		for (int n = 0; n < Student.getCounter(i, j); n++) {

			Student timeObj = adminStud.getStudent(i, j, n);

			System.out.println(n + ". " + timeObj.toString());
			
			k=j;
		}
		
		int n = DataInput.getInt("Введіть номер студента: ");
		
		while(n<0||n>k) {
			n = DataInput.getInt("Введіть існуючий номер студента: ");
		}
		
		return n;
	}

	
	//Створити/видалити/редагувати кафедру факультета.
	private static void createDeleteRedDepartment() throws IOException {
		while (true) {

			System.out.println("(1)Створити/(2)видалити/(3)редагувати кафедру факультета. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 3) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}

			switch (n) {
			case (1): {
				
				int i = realFaculty();

				System.out.println("Введіть назву нової кафедри: ");
				
				String userStr1 = DataInput.getString();
				
				adminDep.addDepartemnt(userStr1, i);
				
				break;
			}
			case (2): {
				// видалити кафедру факультету
				break;
			}
			case (3): {
				// редагувати кафедру факультету
				int i = realFaculty();
				int j = realDepartment(i);
				
				System.out.println("Введіть нову назву кафедри: ");
				String nameD = DataInput.getString();
				
				//adminDep.reSet(i, j, facTochange, nameD);
				break;
			}

			}
		}

	}

	
	//Створити/видалити/редагувати факультет.
	private static void createDeleteRedFaculty() throws IOException {

		while (true) {

			System.out.println("(1)Створити/(2)видалити/(3)редагувати факультет. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 3) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}

			switch (n) {
			case (1): {
				System.out.println("Введіть назву факультету: ");

				String userStr1 = DataInput.getString();

				adminFac.addFac(userStr1);
				break;

			}
			case (2): {
				// видалити факультет
				break;

			}
			case (3): {
				// редагувати факультет
				break;

			}

			}
		}

	}

	private static int realFaculty() {
		
		int k=0;

		for (int i = 0; i < adminFac.getCounter(); i++) {

			Faculty timeObj = adminFac.getFac(i);

			System.out.println(i + ". " + timeObj.getNameF());
			
			k=i;
		}

		int i = DataInput.getInt("Введіть номер факультету: ");
		
		while(i<0||i>k) {
			i = DataInput.getInt("Введіть існуючий номер факультету: ");
		}
		
		return i;
	}

	private static int realDepartment(int i) {
		
		int k=0;

		for (int j = 0; j < adminDep.getCounter(i); j++) {

			Department timeObj = adminDep.getDepartment(i, j);

			System.out.println(j + ". " + timeObj.getNameD());
			
			k=j;
		}
		
		int j = DataInput.getInt("Введіть номер кафедри: ");
		
		while(j<0||j>k) {
			j = DataInput.getInt("Введіть існуючий номер кафедри: ");
		}
		
		return j;
	}
}
