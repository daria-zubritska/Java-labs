package project;

public class RectangleTest {

	public static void main(String[] arg) {
		
		Rectangle a = new Rectangle(5, 30, 20, 5);
		Rectangle b = new Rectangle(10, 30, 30, 15);
		
		System.out.println("Прямокутник а: " + a.toString());
		System.out.println("Прямокутник b: " + b.toString());
		
		if(a.pointIsInside(15, 15)) {
			System.out.println("точка належить прямокутнику а");
		}
		
		if(a.pointIsInside(40, 40)) {
			System.out.println("точка належить прямокутнику а");
		}
		else {
			System.out.println("точка не належить прямокутнику а");
		}
		
		System.out.println("Об'єднання прямокутників: " + a.merge(b));
		
		System.out.println("Перетин прямокутників: " + a.intersection(b));
		
		a.moveRight(10);
		System.out.println("Зміщення а вправо: " + a.toString());
		
		a.moveLeft(10);
		System.out.println("Зміщення а вліво: " + a.toString());
		
		b.moveUp(10);
		System.out.println("Зміщення b вгору: " + b.toString());
		
		b.moveDown(10);
		System.out.println("Зміщення b униз: " + b.toString());
	}
	
}
