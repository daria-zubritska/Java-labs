package project;

public class Rectangle {
	
	int x1, y1,x2,y2;
	
	/**
	 * @param user_x1 - Верхній лівий куток
	 * @param user_y1 - Верхній лівий куток
	 * @param user_x2 - Нижній правий куток
	 * @param user_y2 - Нижній правий куток
	 * */
	Rectangle(int user_x1, int user_y1, int user_x2, int user_y2){
		this.x1 = user_x1;
		this.y1 = user_y1;
		this.x2 = user_x2;
		this.y2 = user_y2;
		
	}
	
	public void moveRight(int move) {
		this.x1 = this.x1+move;
		this.x2 = this.x2+move;
	}

	public void moveLeft(int move) {
		this.x1 = this.x1-move;
		this.x2 = this.x2-move;
	}
	
	public void moveUp(int move) {
		this.y1 = this.y1+move;
		this.y2 = this.y2+move;
	}
	
	public void moveDown(int move) {
		this.y1 = this.y1-move;
		this.y2 = this.y2-move;
	}
	
	public boolean pointIsInside(int x, int y) {
		
		if(x>this.x1 && x<this.x2 && y>this.y2 && y<this.y1) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
	public String merge(Rectangle rec2) {
		int mergeX1 = this.x1;
		int mergeY1 = this.y1;
		int mergeX2 = this.x2;
		int mergeY2 = this.y2;
		
		if(mergeX1 > rec2.x1) {
			mergeX1 = rec2.x1;
		}
		if(mergeY1 < rec2.y1) {
			mergeY1 = rec2.y1;
		}
		if(mergeX2 < rec2.x2) {
			mergeX2 = rec2.x2;
		}
		if(mergeY2 > rec2.y2) {
			mergeY2 = rec2.y2;
		}
		
		Rectangle merged = new Rectangle(mergeX1, mergeY1, mergeX2, mergeY2);
		
		return merged.toString();
	}
	
	public String intersection(Rectangle rec2) {
		
		int interX1 = this.x1;
		int interY1 = this.y1;
		int interX2 = this.x2;
		int interY2 = this.y2;
		
			
		if(interY1 > rec2.y1) {
			interY1 = rec2.y1;
				
			if(interY2 > rec2.y2 && interY2 < rec2.y1) {
					//return
			}
			else if(interY2 <= rec2.y2) {
				interY2 = rec2.y2;
					//return
			}
			else if(interY2 > rec2.y1) {
				return "Нема перетину";
			}	
		}
		else if(interY1 <= rec2.y2) {
			return "Нема перетину";
		}
		else if(interY1 <= rec2.y1 && interY1 > rec2.y2) {
				
			if(interY2 <= rec2.y2) {
				interY2 = rec2.y2;
					//return
			}
			else if(interY2 > rec2.y2 && interY2 < rec2.y1) {
					//return
			}
		}
			
		if(interX1 < rec2.x1) {
			interX1 = rec2.x1;
			
			if(interX2 < rec2.x2 && interX2 > rec2.x1) {
				//return
			}
			else if(interX2 >= rec2.x2) {
				interX2 = rec2.x2;
				//return
			}
			else if(interX2 < rec2.x1) {
				return "Нема перетину";
			}	
		}
		else if(interX1 >= rec2.x2) {
			return "Нема перетину";
		}
		else if(interX1 >= rec2.x1 && interX1 < rec2.x2) {
			
			if(interX2 >= rec2.x2) {
				interX2 = rec2.x2;
				//return
			}
			else if(interX2 < rec2.x2 && interX2 > rec2.x1) {
				//return
			}
		}
		
		Rectangle intersection = new Rectangle(interX1, interY1, interX2, interY2);
		
		return intersection.toString();
	}
	
	public String toString() {
		
		String str = "Координати прямокутника: (x1 = " + Integer.toString(this.x1) + "; y1 = " + Integer.toString(this.y1) + "; x2 = " + Integer.toString(this.x2) + "; y2 = " + Integer.toString(this.y2) + ")";
		
		
		return str;
	}
	
}
