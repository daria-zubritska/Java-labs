/*Написати програму, що по заданій колекції текстових файлів будує словник термінів і до кожного терміну ставить у відповідність інвертований список документів з частотою терміна в документі.

Текстові файли подаються на вхід в будь-якому текстовому форматі.
Розмір текстових файлів не менше 150 К.
Кількість текстових файлів не менше 10.
Словник термінів зберегти на диск.
Оцінити розмір колекції, загальну кількість слів в колекції та розмір словника.

File:tester.java
Author:Zubritska*/
public class tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Dictionary d = new Dictionary();
		d.addFile("1.txt");
		d.addFile("2.bak");
		d.addFile("3.txt");
		d.addFile("4.txt");
		d.addFile("5.bak");
		d.addFile("6.txt");
		d.addFile("7.txt");
		d.addFile("8.bak");
		d.addFile("9.txt");
		d.addFile("10.txt");
		d.toFile();
		
	}
//аа
}
