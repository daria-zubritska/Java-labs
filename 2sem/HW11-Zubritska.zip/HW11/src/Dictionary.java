import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Dictionary {

	private ArrayList<String> files;
	
	Dictionary(){
		files = new ArrayList<String>();
	}

	public void addFile(String name) {
		files.add(name);
	}

	public ArrayList readSpecialWordsFromFiles() {
		
		ArrayList<String> specWords = new ArrayList<String>();
		String[] sWords = new String[200];

		int i = 0;
		for (String file : files) {

			ReadSpecialWords rw = new ReadSpecialWords(file);
			rw.getSpecialWords();
			
			for(String s : rw.special) {
				if(i<200) {
					sWords[i] = s;
				}else {
					String[] time = sWords;
					sWords = new String[i+1];
					
					for(int j = 0; j<time.length; j++) {
						sWords[j] = time[j];
					}
					
					sWords[i] = s;
				}
				i++;
			}
		}
		
		ReadSpecialWords rw = new ReadSpecialWords(sWords);
		rw.getSpecialWords();
		
		for(String s : rw.getSpecialByAlphabet()) {
			specWords.add(s);
		}
		
		return specWords;
	}
	
	public void toFile() {
		
		ArrayList<String> a = new ArrayList<String>(readSpecialWordsFromFiles());
		
		try(FileWriter writer = new FileWriter("dictionary.txt", false))
        {
			for(String aa : a) {
				if(aa == null) continue;
				String text = aa;
				writer.write(text);
				writer.write("\n");
				
			}
			writer.flush();
        }
        catch(IOException ex){
             
            System.out.println(ex.getMessage());
        } 
	}
}
