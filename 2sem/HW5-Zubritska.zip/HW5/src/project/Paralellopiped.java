package project;

public class Paralellopiped extends Quadrangle {

	Quadrangle q1;
	Quadrangle q2;
	double height;
	double c;
	
	Paralellopiped(){
		vertices2 = new Point[4];
		vertices2[0] = new Point(0, 0, 0);
		vertices2[1] = new Point(0, 1, 0);
		vertices2[2] = new Point(1, 1, 0);
		vertices2[3] = new Point(1, 0, 0);
		
		c= 1;
		
		vertices = new Point[4];
		vertices[0] = new Point(0, 0, 1);
		vertices[1] = new Point(0, 1, 1);
		vertices[2] = new Point(1, 1, 1);
		vertices[3] = new Point(1, 0, 1);
		
		q1 = new Quadrangle(vertices2[0], vertices2[1], vertices2[2], vertices2[3], 90, 90, 90, 90);
		q2 = new Quadrangle(vertices[0], vertices[1], vertices[2], vertices[3], 90, 90, 90, 90);
		height = 1;
	}
	
	Paralellopiped(Point ver1, Point ver2, Point ver3, Point ver4, double ang1, double ang2, double ang3, double ang4, double angShift, int z){
		vertices2 = new Point[4];
		vertices2[0] = new Point(ver1.coordinates[0], ver1.coordinates[1], 0);
		vertices2[1] = new Point(ver2.coordinates[0], ver2.coordinates[1], 0);
		vertices2[2] = new Point(ver3.coordinates[0], ver3.coordinates[1], 0);
		vertices2[3] = new Point(ver4.coordinates[0], ver4.coordinates[1], 0);
		
		double tAng = ang1/2;
		
		c= z/Math.asin(angShift);
		
		double b = Math.sqrt(Math.pow(c, 2)-Math.pow(z, 2));
		
		double xShift = b*Math.cos(tAng);
		double yShift = b*Math.sin(tAng);
		
		
		
		vertices = new Point[4];
		vertices[0] = new Point(ver1.coordinates[0]+(int) xShift, ver1.coordinates[1] + (int) yShift, z);
		vertices[1] = new Point(ver2.coordinates[0]+(int) xShift, ver2.coordinates[1] + (int) yShift, z);
		vertices[2] = new Point(ver3.coordinates[0]+(int) xShift, ver3.coordinates[1] + (int) yShift, z);
		vertices[3] = new Point(ver4.coordinates[0]+(int) xShift, ver4.coordinates[1] + (int) yShift, z);
		
		q1 = new Quadrangle(vertices2[0], vertices2[1], vertices2[2], vertices2[3], ang1, ang2, ang3, ang4);
		q2 = new Quadrangle(vertices[0], vertices[1], vertices[2], vertices[3], ang1, ang2, ang3, ang4);
		height = z;
	}
	
	public double calculateSquareOsn() {
		return q1.calculateSquare();
	}
	
	public double getHeight() {
		return height;
	}
	
	public double V() {
		
		double So = q1.calculateSquare();
		double Vp = So*c;
		return Vp;
	}
	
	public String toString() {
		
		return calculateSquareOsn() +" "+ getHeight()+" " + V();
	}
}
