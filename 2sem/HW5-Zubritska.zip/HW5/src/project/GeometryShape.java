package project;

public abstract class GeometryShape {

	protected Point[] vertices;
	protected Point[] vertices2;
	protected double[] sides;
	protected double[] angles;
	
	public abstract double calculatePerimeter();
	
	public abstract double calculateSquare();
	
	public abstract String toString();
}

class Point {
	public int[] coordinates;
	
	Point(){
		coordinates = new int[3];
		
		coordinates[0] = 0;
		coordinates[1] = 0;
		coordinates[2] = 0;
	}
	
	Point(int x, int y, int z){
		coordinates = new int[3];
		
		coordinates[0] = x;
		coordinates[1] = y;
		coordinates[2] = z;
	}
}
