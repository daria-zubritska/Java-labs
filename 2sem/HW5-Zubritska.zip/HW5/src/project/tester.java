package project;

public class tester {

	public static void main(String[] args) {
		
		Paralellopiped p = new Paralellopiped();
		System.out.println(p.toString());

	}

}
