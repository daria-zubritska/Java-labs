package lab.src.lab;

public class Student extends Department {

	String nameS;
	String surnameS;
	int ageS;
	double avgM;
	static int counterS = 0;
	int indexS;
	String patronimicS;
	String courseS;
	int groupS;

	public Student(String nameF, String nameD, int ageS, String nameS, String SurnameS, double avgM, int i, int j,
			String patronimics, String courses, int groups) {
		super(nameF, nameD, i);
		this.ageS = ageS;
		this.nameS = nameS;
		this.surnameS = SurnameS;
		this.avgM = avgM;

		if (fac[i] == null) {
			System.out.println("Sorry, you must creat a faculty at first!");
			return;
		}

		if (fac[i].dep[j] == null) {
			System.out.println("Sorry, you must creat a department at first!");
			return;
		}

		this.indexS = fac[i].dep[j].amountOfStudents;
		this.patronimicS = patronimics;
		this.courseS = courses;
		this.groupS = groups;
	}

	public Student() {
		//порожній конструктор для виклика методів у коді
	}

	public void addSt(int i, int j, int ageS, String nameS, String Surname, double avgM, String patronimicS,
			String courseS, int groupS) {
		Student st = new Student(fac[i].getNameF(), fac[i].dep[j].getNameD(), ageS, nameS, Surname, avgM, i, j,
				patronimicS, courseS, groupS); // Ð²Ñ‹Ð½ÐµÑ�Ð¸ Ð¿ÐµÑ€ÐµÐ´ Ð¼ÐµÑ‚Ð¾Ð´Ð°Ð¼Ð¸ addSt && reSet

		if (fac[i].dep[j].students.length > fac[i].dep[j].amountOfStudents)
			fac[i].dep[j].students[fac[i].dep[j].amountOfStudents] = st;

		else {
			Student temp[] = new Student[fac[i].dep[j].amountOfStudents + 10];
			temp = students;
			for (int k = 0; k < fac[i].dep[j].students.length; k++)
				temp[k] = fac[i].dep[j].students[k];
			fac[i].dep[j].students = temp;
		}

		counterS++;
		fac[i].dep[j].amountOfStudents++;
	}

	public void reSet(int i, int j, int k, int facTochange, int depToChange, int ageS, String nameS, String Surname,
			double avgM, String patronimicS, String courseS, int groupS) {

		if (fac[facTochange] == null)
			return;

		if (fac[facTochange].dep[depToChange] == null)
			return;

		else if (fac[i].dep[j].students[k] == fac[facTochange].dep[depToChange].students[k]) {
			fac[i].dep[j].students[k] = new Student(fac[i].getNameF(), fac[i].dep[j].getNameD(), ageS, nameS, Surname,
					avgM, i, j, patronimicS, courseS, groupS);
		} else {
			delete(i, j, k);
			fac[facTochange].dep[depToChange].students[getCounter(facTochange, depToChange)] = new Student(
					fac[facTochange].getNameF(), fac[facTochange].dep[depToChange].getNameD(), ageS, nameS, Surname,
					avgM, facTochange, depToChange, patronimicS, courseS, groupS);

			fac[facTochange].dep[depToChange].amountOfStudents++;
			counterS++;
		}
	}

	public void delete(int i, int j, int k) {
		fac[i].dep[j].students[k] = null;

		fac[i].dep[j].students[k] = fac[i].dep[j].students[getCounter(i, j)];
		fac[i].dep[j].amountOfStudents--;
		counterS--;
	}

	public Student[] searchByCourse(String course) {
		Student[] courseSearch = new Student[counterS];

		for (int i = 0; i < allStudents().length; i++) {

			if (allStudents()[i].getCourseS().equals(course))
				courseSearch[i] = allStudents()[i];
		}

		return courseSearch;
	}

	public Student[] searchByName(String nameS) {
		Student[] byName = new Student[counterS];

		for (int i = 0; i < allStudents().length; i++) {

			if (allStudents()[i].getNameS().equals(nameS))
				byName[i] = allStudents()[i];
		}

		return byName;
	}

	public Student[] searchBySurname(String surnameS) {
		Student[] byName = new Student[counterS];

		for (int i = 0; i < allStudents().length; i++) {

			if (allStudents()[i].getSurnameS().equals(surnameS))
				byName[i] = allStudents()[i];
		}

		return byName;
	}

	public Student[] searchByPatronymic(String patronymicS) {
		Student[] byName = new Student[counterS];

		for (int i = 0; i < allStudents().length; i++) {

			if (allStudents()[i].getPatronimicS().equals(patronymicS))
				byName[i] = allStudents()[i];
		}

		return byName;
	}

	static String inputToStreamline(String input) {
		input = input.replaceAll(" ", "");
		input = input.toLowerCase();
		return input;
	}

	public String getCourseS() {
		return courseS;
	}

	public void setCourseS(String courseS) {
		this.courseS = courseS;
	}

	public String getNameS() {
		return nameS;
	}

	public void setNameS(String nameS) {
		this.nameS = nameS;
	}

	public String getSurnameS() {
		return surnameS;
	}

	public void setSurnameS(String surnameS) {
		this.surnameS = surnameS;
	}

	public String getPatronimicS() {
		return patronimicS;
	}

	public void setPatronimicS(String patronimicS) {
		this.patronimicS = patronimicS;
	}

	public int getGroupS() {
		return groupS;
	}

	public void setGroupS(int groupS) {
		this.groupS = groupS;
	}

	@Override
	public String toString() {
		return  nameS +" "+ patronimicS +" "+ surnameS + " age= " + ageS + ", average mark = " + avgM  + " course= " + courseS + " group = " + groupS;
	}

	public int getAgeS() {
		return ageS;
	}

	public void setAgeS(int ageS) {
		this.ageS = ageS;
	}

	public double getAvgM() {
		return avgM;
	}

	public void setAvgM(double avgM) {
		this.avgM = avgM;
	}

	public static int getCounter(int i, int j) {
		return fac[i].dep[j].amountOfStudents;
	}

	public static void setCounterS(int counterS) {
		Student.counterS = counterS;
	}

	public int getIndexS() {
		return indexS;
	}

	public void setIndexS(int indexS) {
		this.indexS = indexS;
	}

	public Student getStudent(int i, int j, int k) {
		return fac[i].dep[j].students[k];
	}

	public Student[] searchByNameSurnamePatronymic(String nameS, String surnameS, String patronymicS) {
		Student[] byName = new Student[counterS];
		String str = nameS + surnameS + patronymicS;
		Student.inputToStreamline(str);
		String str1;
		for (int i = 0; i < allStudents().length; i++) {
			str1 = allStudents()[i].getNameS() + allStudents()[i].getSurnameS() + allStudents()[i].getPatronimicS();
			Student.inputToStreamline(str1);
			if(i!=0 && byName[i-1] == null) {
				if(str.equals(str1)) {
					byName[i-1] = allStudents()[i];
				}
			}
			else if (str.equals(str1))
				byName[i] = allStudents()[i];
		}
		return byName;
	}

	public Student[] allStudents() {
		int counter = 0;
		Student[] allStudents = new Student[counterS];
		for (int i = 0; i < Faculty.counterF; i++) {
			for (int j = 0; j < fac[i].amountOfDep; j++) {
				int a = fac[i].dep[j].amountOfStudents;
				for (int j2 = 0; j2 < fac[i].dep[j].amountOfStudents; j2++) {
					allStudents[counter] = fac[i].dep[j].students[j2];
					counter++;
				}
			}
		}
		return allStudents;
	}

	public Student[] searchByGroup(int i) {
		Student[] byName = new Student[counterS];
		for (int j = 0; j < allStudents().length; j++) {
			if(j!=0 && byName[j-1] == null) {
				if (allStudents()[j].getGroupS() == i)
				byName[j-1] = allStudents()[j];
			}
			else if (allStudents()[j].getGroupS() == i)
				byName[j] = allStudents()[j];
		}
		return byName;
	}

	public Student[] searchByCourse(int i) {
		Student[] byName = new Student[counterS];
		for (int j = 0; j < allStudents().length; j++) {
			if(j!=0 && byName[j-1] == null) {
				if (Integer.parseInt(allStudents()[j].getCourseS()) == i)
				byName[j-1] = allStudents()[j];
			}
			else if (Integer.parseInt(allStudents()[j].getCourseS()) == i)
				byName[j] = allStudents()[j];
		}
		return byName;
	}

	public Student[] allStudentsFromAllCourse() {
		Student[] st = allStudents();
		int[] mas = new int[allStudents().length];
		for (int j = 0; j < mas.length; j++)
			mas[j] = Integer.parseInt(allStudents()[j].getCourseS());
		boolean isSorted = false;
		Student buf;
		int mmas;
		while (!isSorted) {
			isSorted = true;
			for (int i = 0; i < mas.length - 1; i++) {
				if (mas[i] - (mas[i + 1]) > 0) {
					mmas = mas[i];
					mas[i] = mas[i+1];
					mas[i+1] = mmas;
					isSorted = false;
					buf = st[i];
					st[i] = st[i + 1];
					st[i + 1] = buf;
				}
			}
		}
		return st;
	}

	public Student[] allStudentsByAlphabet(int i) {
		Student[] st = allStudents();
		String[] mas = new String[allStudents().length];
		for (int j = 0; j < mas.length; j++) {
			mas[j] = (allStudents()[j].getNameS() + allStudents()[j].getSurnameS() + allStudents()[j].getPatronimicS());
			mas[j] = inputToStreamline(mas[j]);
		}
		boolean isSorted = false;
		Student buf;
		String mmas;
		while (!isSorted) {
			isSorted = true;
			for (int i1 = 0; i1 < mas.length - 1; i1++) {
				if (mas[i1].compareTo(mas[i1 + 1]) >= 0) {
					mmas = mas[i1];
					mas[i1] = mas[i1+1];
					mas[i1+1] = mmas;
					isSorted = false;
					buf = st[i1];
					st[i1] = st[i1 + 1];
					st[i1 + 1] = buf;
				}
			}
		}
		return st;
	}

	public Student[] allStudentsFromDepFromAllCourses(int i, int j) {
		Student[] st = Faculty.fac[i].dep[j].students;
		int[] mas = new int[fac[i].dep[j].amountOfStudents];
		for (int j1 = 0; j1 < mas.length; j1++)
			mas[j1] = Integer.parseInt(allStudents()[j1].getCourseS());
		boolean isSorted = false;
		Student buf;
		int mmas;
		while (!isSorted) {
			isSorted = true;
			for (int i1 = 0; i1 < mas.length - 1; i1++) {
				if (mas[i1] - (mas[i1 + 1]) > 0) {
					mmas = mas[i1];
					mas[i1] = mas[i1+1];
					mas[i1+1] = mmas;
					isSorted = false;
					buf = st[i1];
					st[i1] = st[i1 + 1];
					st[i1 + 1] = buf;
				}
			}
		}
		return st;
	}

	public Student[] allStudentsByAlphabetFromDepartment(int i, int j) {
		Student[] st = Faculty.fac[i].dep[j].students;
		String[] mas = new String[Faculty.fac[i].dep[j].amountOfStudents];
		for (int j1 = 0; j1 < mas.length; j1++) {
			mas[j1] = (allStudents()[j1].getNameS() + allStudents()[j1].getSurnameS()
					+ allStudents()[j1].getPatronimicS());
			mas[j1] = inputToStreamline(mas[j1]);
		}
		boolean isSorted = false;
		Student buf;
		String mmas;
		while (!isSorted) {
			isSorted = true;
			for (int i1 = 0; i1 < mas.length - 1; i1++) {
				if (mas[i1].compareTo(mas[i1 + 1]) > 0) {
					mmas = mas[i1];
					mas[i1] = mas[i1+1];
					mas[i1+1] = mmas;
					isSorted = false;
					buf = st[i1];
					st[i1] = st[i1 + 1];
					st[i1 + 1] = buf;
				}
			}
		}
		return st;
	}

	public Student[] getStudentsFromDepartment(int i, int j) {
		return Faculty.fac[i].dep[j].students; 
	}

	public Student[] allStudentsByAlphabetFromDepartmentByCourse(int i, int j, int course) {//
		Student[] st1 = Faculty.fac[i].dep[j].students;
		Student[] st = new Student[Faculty.fac[i].dep[j].amountOfStudents];
		int timeCount = Faculty.fac[i].dep[j].amountOfStudents;
		for (int k = 0; k < st.length; k++) {
			if(k!=0 && st[k-1] == null) {
				if (Integer.parseInt(st1[k].getCourseS()) == course)
				st[k-1] = st1[k];
				timeCount--;
			}
			else if (Integer.parseInt(st1[k].getCourseS()) == course)
				st[k] = st1[k];
		}
		String[] mas = new String[timeCount];
		for (int j1 = 0; j1 < mas.length; j1++) {
			mas[j1] = (allStudents()[j1].getNameS() + allStudents()[j1].getSurnameS()
					+ allStudents()[j1].getPatronimicS());
			mas[j1] = inputToStreamline(mas[j1]);

		}
		boolean isSorted = false;
		Student buf;
		String mmas;
		while (!isSorted) {
			isSorted = true;
			for (int i1 = 0; i1 < mas.length - 1; i1++) {
				if (mas[i1].compareTo(mas[i1 + 1]) > 0) {
					mmas = mas[i1];
					mas[i1] = mas[i1+1];
					mas[i1+1] = mmas;
					isSorted = false;
					buf = st[i1];
					st[i1] = st[i1 + 1];
					st[i1 + 1] = buf;
				}
			}
		}
		return st;
	}
	
	public Student [] allStudentsFromDepFromCourse(int i, int j, int k) {
		Student[] st1 = Faculty.fac[i].dep[j].students;
		Student[] st = new Student[Faculty.fac[i].dep[j].amountOfStudents];
		for (int n = 0; n < st.length; n++) {
			if(n!=0 && st[n-1] == null) {
				if (Integer.parseInt(st1[n].getCourseS()) == k)
				st[n-1] = st1[n];
			}
			else if (Integer.parseInt(st1[n].getCourseS()) == k)
				st[n] = st1[n];
		}
	        return st;
	  }

	public Student[]allStudentsFromFaculty(int i) {
	    int counter = 0;
	  Student[] allStudents = new Student[counterS];
	      for (int j = 0; j < fac[i].amountOfDep; j++) {
	        for (int j2 = 0; j2 < fac[i].dep[j].amountOfStudents; j2++) {
	    allStudents[counter] = fac[i].dep[j].students[j2];
	    counter++;
	        }
	  }
	    return allStudents;
	  }

	public Student [] allStudentsByAlphabetFromFaculty(int i) {
	      Student[] st = allStudentsFromFaculty(i);
	      String [] mas = new String[allStudentsFromFaculty(i).length];
	      for (int j = 0; j < mas.length; j++) {
	    	if(allStudentsFromFaculty(i)[j]==null) break;
	        mas[j] =(allStudentsFromFaculty(i)[j].getNameS()+allStudentsFromFaculty(i)[j].getSurnameS()+allStudentsFromFaculty(i)[j].getPatronimicS());
	        mas[j] = inputToStreamline(mas[j]);
	      }
	        boolean isSorted = false;
	        Student buf;
	        String mmas;
	        while(!isSorted) {
	            isSorted = true;
	            for (int k = 0; k < mas.length-1; k++) {
	            	if(mas[k+1] == null) break;
	                if(mas[k].compareTo(mas[k+1])>0){
	                	mmas = mas[k];
	                	mas[k] = mas[k+1];
	                	mas[k+1] = mmas;
	                    isSorted = false;
	                    buf = st[k];
	                    st[k] = st[k+1];
	                    st[k+1] = buf;
	                }
	            }
	        }
	        return st;
	  }
}
