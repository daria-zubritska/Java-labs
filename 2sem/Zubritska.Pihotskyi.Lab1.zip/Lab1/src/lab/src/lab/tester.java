package lab.src.lab;

public class tester {

	static Faculty adminFac = new Faculty();
	static Department adminDep = new Department();
	static Student adminStud = new Student();
	static Educator adminEd = new Educator();
	
	public static void main(String[] args) {
		adminFac.addFac("fac0");
		adminFac.addFac("fac1");
		adminDep.addDepartemnt("dep0", 0);
		adminDep.addDepartemnt("dep0", 1);
		adminDep.addDepartemnt("dep1", 0);
		
		adminEd.addSt(0, 0, "name", "Surname", 34, "patronimic", "1", 3);
		adminEd.addSt(1, 0, "aame", "Surname", 34, "patronimic", "3", 1);
		adminEd.addSt(0, 1, "name", "Surname", 34, "patronimic", "1", 2);
		adminEd.addSt(0, 0, "bame", "Surname", 34, "patronimic", "2", 1);
		adminEd.addSt(1, 0, "abme", "Surname", 34, "patronimic", "1", 2);
		adminEd.addSt(0, 0, "name", "Surname", 34, "patronimic", "4", 3);
		
		adminStud.addSt(0, 0, 19, "aame", "Surname", 99, "patronimic", "1", 1);
		adminStud.addSt(0, 0, 19, "name", "Surname", 99, "patronimic", "2", 3);
		adminStud.addSt(1, 0, 19, "bame", "Surname", 99, "patronimic", "4", 1);
		adminStud.addSt(0, 0, 19, "bbme", "Surname", 99, "patronimic", "1", 1);
		adminStud.addSt(0, 1, 19, "name", "Surname", 99, "patronimic", "2", 5);
		
		int k = 0;

		for (int n = 0; n < Educator.getCounterE(0, 0); n++) {

			Educator timeObj = adminEd.getEducator(0, 0, n);

			System.out.println(n + ". " + timeObj.toString());


		}
	}
}

