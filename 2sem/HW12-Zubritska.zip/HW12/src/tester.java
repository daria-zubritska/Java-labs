/*Виправити домашню роботу 11, так щоб всі виняткові ситуації оброблювалися коректно.
 * File:tester.java
 * Author: Zubritska*/
public class tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Dictionary d = new Dictionary();
		d.addFile("1.txt");
		d.addFile("2.bak");
		d.addFile("3.txt");
		d.addFile("4.txt");
		d.addFile("5.bak");
		d.addFile("6.txt");
		d.addFile("7.txt");
		d.addFile("8.bak");
		d.addFile("9.txt");
		d.addFile("10.txt");
		d.toFile();
		
	}
//аа
}
