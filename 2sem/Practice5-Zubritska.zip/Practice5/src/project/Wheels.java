package project;

public class Wheels {

	public boolean isInflated = false;
	
	public void inflate() {
		isInflated = true;
	}
	
	public void deflate() {
		isInflated = false;
	}
	
	public String toString() {
		if(isInflated) {
			return "Wheel is inflated";
		}
		
		return "Wheel is deflated";
	}
}
