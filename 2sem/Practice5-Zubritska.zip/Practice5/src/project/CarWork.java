package project;

/*Створити ієрархію класів, що описує машину використовуючи наслідування і композицію.

Ступінь деталізації власний. Мають бути присутні обидва компоненти.

File: CarWork.java
Author: Zubritska
 * */

import utils.*;

public class CarWork {

	Lights[] lg;
	Wheels[] wh;
	Doors[] dr;
	Engine en = new Engine();
	
	CarWork() {

		lg = new Lights[4];

		for (int i = 0; i < 4; i++) {
			lg[i] = new Lights();
		}

		wh = new Wheels[4];

		for (int i = 0; i < 4; i++) {
			wh[i] = new Wheels();
		}
		dr = new Doors[4];

		for (int i = 0; i < 4; i++) {
			dr[i] = new Doors();
		}
		
	}

	public void startEngine() {
		if (!en.isOn) {
			en.turnOn();
		}
	}

	public void closeDoors() {
		for (Doors d : dr) {
			if (!d.isClosed) {
				d.close();
			}
		}
	}

	public void turnOnLights() {
		for (Lights l : lg) {
			if (!l.isLightedUp) {
				l.lightUp();
			}
		}
	}

	public void inflateWheel() {
		for (Wheels w : wh) {
			if (!w.isInflated) {
				w.inflate();
			}
		}
	}

	public String toString() {
		String str = "";

		str += en.toString() + ". ";

		for (Doors d : dr) {
			str += d.toString() + ". ";
		}

		for (Lights l : lg) {
			str += l.toString() + ". ";
		}

		for (Wheels w : wh) {
			str += w.toString() + ". ";
		}

		return str;
	}

	public static void main(String[] args) {
		CarWork c = new CarWork();
		System.out.println(c.toString());
		
		c.inflateWheel();
		c.closeDoors();
		c.turnOnLights();
		c.startEngine();
		
		System.out.println(c.toString());
		
	}

}
