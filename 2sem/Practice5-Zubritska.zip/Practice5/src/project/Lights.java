package project;

public class Lights {

	public boolean isLightedUp = false;
	
	public void lightUp() {
		isLightedUp = true;
	}
	
	public void lightDown() {
		isLightedUp = false;
	}
	
	public String toString() {
		if(isLightedUp) {
			return "Light is on";
		}
		
		return "Light is off";
	}
}
