
public class Student {
	
	protected String sName;
	protected int sGrade;
	
	Student(){
		this.sName = "name";
		this.sGrade = 0;
	}
	
	Student(String name, int grade){
		setName(name);
		setGrade(grade);
	}
	
	public String getName() {
		return this.sName;
	}
	
	public int getGrade() {
		return this.sGrade;
	}

	public void setName(String name) {
		this.sName = name;
	}
	
	public void setGrade(int grade) {
		this.sGrade = grade;
	}
	
	public Student getStudent() {
		return this;
	}
	
	public void setStudent(Student s) {
		this.sName = s.sName;
		this.sGrade = s.sGrade;
	}
	
	public String toString() {
		return this.sName + " " + this.sGrade;
	}
}
