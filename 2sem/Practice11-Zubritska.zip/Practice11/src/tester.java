/*Написати програму, що формує групу студентів і корисні методи.

Використовуючи колекції.
File: tester.java
Author: Zubritska
*/
public class tester {

	public static void main(String[] args) {
		StudGroup sg = new StudGroup();

		sg.add("1", new Student());
		sg.add("2", new Student("Jake", 80));
		sg.add("3", new Student());
		sg.add("4", new Student("Emma", 47));
		
		System.out.println(sg.toString());
		
		sg.redSt("3", "Lev", 60);
		sg.redSt("1", "Lena", 63);
		
		System.out.println(sg.toString());
		
		sg.delStudent("4");
		
		System.out.println(sg.toString());
		
		sg.deleteByGrade(60);
		
		System.out.println(sg.toString());
	}

}
