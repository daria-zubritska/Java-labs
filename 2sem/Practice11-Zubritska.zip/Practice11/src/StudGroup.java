import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class StudGroup {

	private Map<String, Student> students;

	StudGroup() {
		students = new HashMap<>();
	}

	public void add(String ID, String name, int grade) {
		students.put(ID, new Student(name, grade));
	}

	public void add(String ID, Student s) {
		students.put(ID, s);
	}

	public void redSt(String ID, Student s) {
		students.get(ID).setStudent(s);
	}

	public void redSt(String ID, String name, int grade) {
		students.get(ID).setStudent(new Student(name, grade));
	}

	public void delStudent(String ID) {
		students.remove(ID);
	}

	public String toString() {
		return students.toString();
	}
	
	public void deleteByGrade(int grade) {
		ArrayList<String> IDToDelete = new ArrayList<String>();
		
		for(Map.Entry<String, Student> entry : students.entrySet()) {
			if(entry.getValue().getGrade() <= grade) {
				IDToDelete.add(entry.getKey());
			}
		}
		
		for(String IDsToDelete : IDToDelete) {
			students.remove(IDsToDelete);
		}
	}

}
