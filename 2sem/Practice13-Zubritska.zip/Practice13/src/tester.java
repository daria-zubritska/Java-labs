/*Написати власний типізований клас, що буде реалізовувати зв'язний список.
 * File: tester.java
 * Author: Zubritska
 * */
public class tester {

	public static void main(String[] args) {
		List<Integer> l = new List<Integer>();
		
		l.add(12);
		l.add(43);
		l.add(6654);
		
		l.add(32, 1);
		
		System.out.println(l.toString());
	}

}
