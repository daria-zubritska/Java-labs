
public class List<T> {
	
	private class Node<U>{
		Node<U> prev;
		T data;
		Node<U> next;
		
		Node(){
			prev = null;
			data = null;
			next = null;
		}
		
		Node(T input){
			prev = null;
			data = input;
			next = null;
		}
		
		Node(T input, Node current_position){
			prev = current_position;
			data = input;
			
			if(current_position != null) {
				next = current_position.next;
				current_position.next = this;
				
				if(next != null) next.prev = this;
				
				
			}
		}
	}
	
	public Node<T> head;
	public Node<T> tail;
	private int count = 0;
	
	List(){
		head = null;
		tail = null;
		count = 0;
	}
	
	public boolean isEmpty() {
		return (tail == null);
	}
	
	public Node<T> getNode(int pos){
		if(isEmpty()) return null;
		
		if(pos < 0) throw new IllegalArgumentException("Position can`t be negative!");
		
		if(pos>= count-1) return tail;
		
		if(pos==0) return head;
		
		Node<T> p = head;
		for(int i = 0; i< pos; i++) {
			p = p.next;
		}
		
		return p;
	}
	
	public T getData(int pos) {
		if(isEmpty()) throw new NullPointerException("Is Empty");
		
		return getNode(pos).data;
	}
	
	public void add(T input) {
		if(input == null) throw new NullPointerException();
		
		if(isEmpty()) {
			head = new Node<T>(input);
			tail = head;
			count++;
			return;
		}
		
		tail = new Node<T>(input, tail);
		count++;
	}
	
	public void add(T input, int pos) {
		if(input == null) throw new NullPointerException();
		
		if(pos < 0) throw new IllegalArgumentException("Position can`t be negative!");
		
		if(pos >= count) {
			add(input);
			count++;
			return;
		}
		
		if(pos == 0) {
			Node<T> p = new Node<T>(input);
			head.prev = p;
			p.next = head;
			head = p;
			count ++;
			return;
		}
		
		Node<T> p = getNode(pos-1);
		p = new Node<T>(input, p);
		count++;
		
	}
	
	
	public String toString() {
		String res = "";
		
		Node<T> p = head;
		while(p != null) {
			res+= p.data.toString()+" ";
			p = p.next;
		}
		
		return res;
	}

}
