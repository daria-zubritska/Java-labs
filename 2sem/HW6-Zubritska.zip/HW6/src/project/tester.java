package project;

public class tester {

	public static void main(String[] args) {
		Ford f = new Ford();
		
		System.out.println(f.toString());
		
		f.inflateWheel();
		f.closeDoors();
		f.turnOnLights();
		f.startEngine();
		
		System.out.println(f.toString());
		
		Truck t = new Truck();
		
		System.out.println(t.toString());
		
		t.inflateWheel();
		t.closeDoors();
		t.turnOnLights();
		t.startEngine();
		
		System.out.println(t.toString());
		
		Motorbike m = new Motorbike();
		
		System.out.println(m.toString());
		
		m.inflateWheel();
		m.closeDoors();
		m.turnOnLights();
		m.startEngine();
		
		System.out.println(m.toString());
	}
}
