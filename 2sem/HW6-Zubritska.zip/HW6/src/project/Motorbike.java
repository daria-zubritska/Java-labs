package project;

public class Motorbike extends CarWork {

	Motorbike() {
		en = new Engine();
		wh = new Wheels[2];
		
		for(int i = 0; i<2; i++) {
			wh[i] = new Wheels();
		}
		
		lg = new Lights[3];
		
		for(int i = 0; i<3; i++) {
			lg[i] = new Lights();
		}
		
		dr = new Doors[1];
	}

	@Override
	public void startEngine() {
		if (!en.isOn) {
			en.turnOn();
		}
	}


	@Override
	public void turnOnLights() {
		for (Lights l : lg) {
			if (!l.isLightedUp) {
				l.lightUp();
			}
		}
	}

	@Override
	public void inflateWheel() {
		for (Wheels w : wh) {
			if (!w.isInflated) {
				w.inflate();
			}
		}
	}

	@Override
	public String toString() {
		String str = "Motorbike. ";
		
		str += super.toString();
		
		return str;
	}

}
