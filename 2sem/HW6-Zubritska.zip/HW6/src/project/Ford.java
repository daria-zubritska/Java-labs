package project;

public class Ford extends CarWork {

	Ford() {
		en = new Engine();
		wh = new Wheels[4];
		
		for(int i = 0; i<4; i++) {
			wh[i] = new Wheels();
		}
		
		lg = new Lights[4];
		
		for(int i = 0; i<4; i++) {
			lg[i] = new Lights();
		}
		
		dr = new Doors[4];
		
		for(int i = 0; i<4; i++) {
			dr[i] = new Doors();
		}
		
	}

	@Override
	public void startEngine() {
		if (!en.isOn) {
			en.turnOn();
		}
	}

	@Override
	public void closeDoors() {
		for (Doors d : dr) {
			if (!d.isClosed) {
				d.close();
			}
		}
	}

	@Override
	public void turnOnLights() {
		for (Lights l : lg) {
			if (!l.isLightedUp) {
				l.lightUp();
			}
		}
	}

	@Override
	public void inflateWheel() {
		for (Wheels w : wh) {
			if (!w.isInflated) {
				w.inflate();
			}
		}
	}

	@Override
	public String toString() {
		String str = "Ford. ";
		
		str += super.toString();
		
		return str;
	}

}
