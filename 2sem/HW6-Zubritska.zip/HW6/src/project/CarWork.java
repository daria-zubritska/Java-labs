package project;

/*
Переробити ієрархію класів car з попереднього практичного так, щоб показати потужність поліморфізму.

Написати клас тестер.

File: CarWork.java
Author: Zubritska
 * */

import utils.*;

public class CarWork {

	protected Lights[] lg;
	protected Wheels[] wh;
	protected Doors[] dr;
	protected Engine en;

	public void startEngine() {

	}

	public void closeDoors() {

	}

	public void turnOnLights() {

	}

	public void inflateWheel() {

	}

	public String toString() {
		String str = "";

		str += en.toString() + ". ";

		if (dr[0] != null) {
			for (Doors d : dr) {
				str += d.toString() + ". ";
			}
		}

		for (Lights l : lg) {
			str += l.toString() + ". ";
		}

		for (Wheels w : wh) {
			str += w.toString() + ". ";
		}

		return str;
	}

}
