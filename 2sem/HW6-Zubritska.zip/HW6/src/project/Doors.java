package project;

public class Doors {

	public boolean isClosed = false;
	
	public void close() {
		isClosed = true;
	}
	
	public void open() {
		isClosed = false;
	}
	
	public String toString() {
		if(isClosed) {
			return "Door is closed";
		}
		
		return "Door is opened";
	}
}
