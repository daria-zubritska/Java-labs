/*Написати окремий клас Student, що буде володіти двома полями: ім'я та середній бал.
 * 
 * File: Student.java
 * Author: Zubritska
*/

public class Student {
	
	private String[][] student;
	
	Student(int studNum){
		student = new String[studNum][2];
	}
	
	public void addStudent(int i, String name, String grade) {
		
		for(int j = 0; j<2; j++) {
			
			if(j%2==0) {
				student[i][j] = name;
			}
			else if(j%2!=0) {
				student[i][j] = grade;
			}
				
		}
	}
	
	public String[][] getStudent(){
		return student;
	}

}