/*Написати клас, що вміє

заповнювати масив Student'ів

вміє сортувати студентів за зростанням або спаданням за ім'ям або середнім балом (алгоритм сортування не має значення).
вміє виводити інформацію про студентів на екран (з використанням методу toString() класу Student)

File: StudentUse.java
Author: Zubritska
 */

import java.io.IOException;
import java.util.Arrays;//

public class StudentUse {
	
	public static void main(String[] args) throws IOException {
		
		int numStud = DataInput.getInt("Введіть кількість студентів: ");
		
		Student list = new Student(numStud);
		
		for(int i = 0; i < numStud; i++) {
			
			System.out.println("Введіть ім'я студента: ");
			String name = DataInput.readLine();
			
			System.out.println("Введіть оцінку студента: ");
			String grade = DataInput.readLine();
			
			list.addStudent(i, name, grade);
		}
		
		String[][] students = list.getStudent();
		
		sortByGrade(students);
		
		sortByName(students);
	}
	
	private static void sortByGrade(String[][] students) {
		String[][] list = students;
		
		for(int i = 0; i<students.length; i++) {
			String min = list[i][1];
	        int min_i = i; 
	        
	        int minGrade = Integer.parseInt(min);
	        
	        for (int j = i+1; j < students.length; j++) {
	            
	        	String tGr = list[j][1];
	        	int tGrade = Integer.parseInt(tGr);
	        	
	            if (tGrade < minGrade) {
	                min = list[j][1];
	                min_i = j;
	            }
	        }
	        
	        if (i != min_i) {
	            String tmp = list[i][1];
	            String tmp2 = list[i][0];
	            list[i][1] = list[min_i][1];
	            list[i][0] = list[min_i][0];
	            list[min_i][1] = tmp;
	            list[min_i][0] = tmp2;
	        }
		}
		
		System.out.println("За зростанням: ");
		for(int i = 0; i<list.length; i++) {
			
			for(int j = 0; j<2; j++) {
				System.out.println(list[i][j]);
			}
		}
		
		
		for(int i = 0; i<students.length; i++) {
			String max = list[i][1];
	        int max_i = i; 
	        
	        int maxGrade = Integer.parseInt(max);
	        
	        for (int j = i+1; j < students.length; j++) {
	            
	        	String tGr = list[j][1];
	        	int tGrade = Integer.parseInt(tGr);
	        	
	            if (tGrade > maxGrade) {
	                max = list[j][1];
	                max_i = j;
	            }
	        }
	        
	        if (i != max_i) {
	            String tmp = list[i][1];
	            String tmp2 = list[i][0];
	            list[i][1] = list[max_i][1];
	            list[i][0] = list[max_i][0];
	            list[max_i][1] = tmp;
	            list[max_i][0] = tmp2;
	        }
		}
		
		System.out.println("За спаданням: ");
		
		for(int i = 0; i<list.length; i++) {
			
			for(int j = 0; j<2; j++) {
				System.out.println(list[i][j]);
			}
		}
		
		
		
	}
	
	private static void sortByName(String[][] students) {//?
		
		String[] list1 = new String[students.length];
		
		String[][] sorted = new String[students.length][2];
		
		for(int i = 0; i<students.length; i++) {
			list1[i] = students[i][0];
		}
		
		Arrays.sort(list1);
		
		for(int i = 0; i< students.length; i++) {
			
			String sortName = list1[i];
			
			for(int k = 0; k<students.length; k++) {
				
				String actualName = students[k][0];
				
				if(sortName.equals(actualName)) {//??
					
					sorted[i][0] = students[k][0];
					sorted[i][1] = students[k][1];
					
				}
			}
		}
		
		System.out.println("За іменами: ");
		
		for(int i = 0; i<list1.length; i++) {
			
			for(int j = 0; j<2; j++) {
				System.out.println(sorted[i][j]);
			}
		}
		
	}
}