package project;

public class Student {
	private String name;
	private int grade;
	private String adress;
	
	Student(){
		this.name = "";
		this.grade = 0;
		this.adress = "";
	}
	
	Student(String uname, int ugrade, String uadress){
		this.name = "";
		this.name = this.name.concat(uname);
		this.adress = "";
		this.adress = adress.concat(uadress);
		this.grade = ugrade;
	}
	
	public int getGrade() {
		return this.grade;
	}
	
	public String toString() {
		return "Name: " + this.name + " Adress: " + this.adress + " Grade: " + this.grade;
	}
}
