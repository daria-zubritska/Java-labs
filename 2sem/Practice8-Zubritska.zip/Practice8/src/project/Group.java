package project;

public class Group {
	
	private int num = 0;
	private Student[] students;

	Group(){
		this.students = new Student[10];
	}
	
	Group(int size) {
		this.students = new Student[size];
	}
	
	public void TryAdd(Student st) {
		
		if(num < students.length) {
			students[num] = st;
			num++;
		}
		
	}
	
	public Student[] getStudents() {
		return this.students;
	}
	
	public Student getMaxGradeStud() {
			
			int max=0;
			Student maxSt = new Student();
			
			for(int i=0; i<this.students.length; i++) {
				if(this.students[i].getGrade()>max) {
					max = this.students[i].getGrade();
					maxSt = this.students[i];
				}
			}
			
			return maxSt;
	}
	
	public Student getMinGradeStud() {
		int min=100;
		Student minSt = new Student();
		
		for(int i=0; i<this.students.length; i++) {
			if(this.students[i].getGrade()<min) {
				min = this.students[i].getGrade();
				minSt = this.students[i];
			}
		}
		
		return minSt;
	}
}
