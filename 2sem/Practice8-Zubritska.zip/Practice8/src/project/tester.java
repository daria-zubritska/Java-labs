package project;

public class tester {

	public static void main(String[] args) {
		int quantity = 4;
		
		Group g = new Group(quantity);
		ReadStudent sr = new ReadStudent();
		
		for(int i = 0; i< quantity; i++) {
			g.TryAdd(sr.readStudent());
		}
		
		for(int i = 0; i<g.getStudents().length; i++) {
			System.out.println(g.getStudents()[i].toString());
		}
		
		System.out.println("max "+g.getMaxGradeStud().toString());
		System.out.println("min "+g.getMinGradeStud().toString());
	}
}
