package project;

import java.util.Scanner;

public final class ReadStudent {

	public Scanner sc;
	
	ReadStudent(){
		sc = new Scanner(System.in);
	}
	
	public Student readStudent() {
		
		String stName;
		String stAdress;
		int stGrade;
		
		System.out.println("Enter student...");
		System.out.println("Name: ");
		stName = sc.next();
		System.out.println("Adress: ");
		stAdress = sc.next();
		System.out.println("Grade: ");
		stGrade = sc.nextInt();
		
		return new Student(stName, stGrade, stAdress);
	}
	
}
