package project;

public class GetCorrectWasherFactory implements getWasher {

	@Override
	public CarWash getWasher(Car car) {
		
		if(car.getClass().getSuperclass().equals(project.HeavyCar.class)) {
			return new BigWasher();
		}
		else{
			return new SmallWasher();
		}
	}

}
