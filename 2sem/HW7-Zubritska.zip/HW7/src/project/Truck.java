package project;

public class Truck extends HeavyCar{
	
	Truck(String color){
		setColor(color);
		this.maxWeight = 1000;
	}
	
	public void setColor(String color) {
		this.carColor = color;
	}
	
	public void loadPackages(int pack) {
		this.packages = pack;
	}
	
	public String toString() {
		String str = "";
		
		str = this.carColor + " " +  "Truck ";
		
		if(isFull) {
			str += "заправлений і готовий для поїздки. Його максимальна вантажопідйомність " + this.maxWeight + "\n";
		}
		else {
			str += "стоїть з порожнім баком.\n";
		}
		
		if(this.packages>0) {
			str += " Завантажено " + this.packages + " пакунків.\n";
		}
		
		return str;
	}

}
