package project;

public class BigWasher implements CarWash {

	@Override
	public String getCarWashed(Car car) {
		return car.toString() + " - Помито на великій автомийці";
	}

}
