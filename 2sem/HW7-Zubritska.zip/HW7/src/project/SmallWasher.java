package project;

public class SmallWasher implements CarWash {

	@Override
	public String getCarWashed(Car car) {
		return car.toString() + " - Помито на маленькій автомийці";
	}

}
