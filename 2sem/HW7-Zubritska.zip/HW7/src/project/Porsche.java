package project;

public class Porsche extends SportCar {

	Porsche(String color){
		setColor(color);
		this.maxSpeed = 100;
	}
	
	public void setColor(String color) {
		this.carColor = color;
	}
	
	public String toString() {
		String str = "";
		
		str = this.carColor + " " +  "Porsche ";
		
		if(isFull) {
			str += "заправлена і готова для поїздки. Її максимальна швидкість " + this.maxSpeed;
		}
		else {
			str += "стоїть з порожнім баком.";
		}
		
		return str;
	}
}
