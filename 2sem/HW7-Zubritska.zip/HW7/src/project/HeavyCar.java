package project;

public abstract class HeavyCar implements Car {
	
	public String carColor;
	public int maxWeight;
	public int packages;
	public boolean isFull = false;

	public void setColor(String color) {}
	
	public void fuelCar() {
		if(!isFull)
			this.isFull = true;
	}
	
	public int getMaxWeight() {
		return this.maxWeight;
	}
	
	public void loadPackages() {}
	
	public String toString() {
		String str = "";
		
		return str;
	}
}
