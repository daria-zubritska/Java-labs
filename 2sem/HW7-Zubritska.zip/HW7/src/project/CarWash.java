package project;

public interface CarWash {
	
	public String getCarWashed(Car car);
}
