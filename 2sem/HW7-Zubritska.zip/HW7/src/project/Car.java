package project;

public interface Car {

	public void setColor(String color);
	
	public void fuelCar();
}
