package project;

public class tester {
	
	public static void main(String[] arg) {
		
		GetCorrectWasherFactory cw = new GetCorrectWasherFactory();
		
		Ferrari f = new Ferrari("Червона");
		f.fuelCar();
		System.out.println(f.toString());
		System.out.println(cw.getWasher(f).getCarWashed(f));
		
		Porsche p = new Porsche("Синя");
		System.out.println(p.toString());
		System.out.println(cw.getWasher(p).getCarWashed(p));
		p.fuelCar();
		System.out.println(p.toString());
		System.out.println(cw.getWasher(p).getCarWashed(p));
		
		Truck t1 = new Truck("Білий");
		t1.fuelCar();
		System.out.println(t1.toString());
		System.out.println(cw.getWasher(t1).getCarWashed(t1));
		t1.loadPackages(20);
		System.out.println(t1.toString());
		System.out.println(cw.getWasher(t1).getCarWashed(t1));
		
		MiniVan m = new MiniVan("Сірий");
		System.out.println(m.toString());
		m.fuelCar();
		System.out.println(m.toString());
		System.out.println(cw.getWasher(m).getCarWashed(m));
	}

}
