package project;

public interface getWasher {

	public CarWash getWasher(Car car);
	
}
