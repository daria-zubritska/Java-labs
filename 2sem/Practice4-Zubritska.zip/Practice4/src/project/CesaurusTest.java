package project;

import java.io.IOException;

import utils.*;

public class CesaurusTest {
	
	public static void main(String[] arg) throws IOException {
		
		System.out.println("Введіть текст англійською: ");
		
		String text = DataInput.readLine();
		
		Cesaurus str = new Cesaurus(text);
		
		int num = DataInput.getInt("Введіть здвиг: ");
		
		System.out.println(str.getCipheredText(1));
	}

}
