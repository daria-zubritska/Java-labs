package project;

/*Написати клас який на вхід отримує стрічку символів і зберігає її. 
 * На запит користувача повертається закодована стрічка. В якості 
 * кодування стрічки можна взяти шифр Цезаря.
 * 
 * File: Cesaurus.java
 * Author: Zubritska
 * */

public class Cesaurus {
	
	private static final String ALPHABET_ENG = "abcdefghijklmnopqrstuvwxyz";

	String text;

	public Cesaurus(String userText){
		this.text = userText;
	}
	
	public String getCipheredText(int shift) {
		
		return cipher(this.text, shift);
	}
	
	private String cipher(String text, int shift) {
		String plainText = text.toLowerCase();
        String cipherText = "";
        
		for (int i = 0; i < plainText.length(); i++){
			
			if(plainText.charAt(i) == ' '||plainText.charAt(i) == ','||plainText.charAt(i) == '.') {
				cipherText += plainText.charAt(i);
				continue;
			}
			
            int charPosition = ALPHABET_ENG.indexOf(plainText.charAt(i));
            int keyVal = (shift + charPosition) % 26;
            char replaceVal = ALPHABET_ENG.charAt(keyVal);
            cipherText += replaceVal;
            
        }
        return cipherText;
	}
}
