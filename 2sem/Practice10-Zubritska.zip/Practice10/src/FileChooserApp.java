import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;

public class FileChooserApp extends JFrame implements ActionListener {

	JPanel panel1;
	JButton openFileButton;
	JTextArea textArea;
	JFileChooser fileChooser;

	FileChooserApp() {
		super("FileChooserApp");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		initPanel1();
		add(panel1);
		pack();
		setVisible(true);
	}

	private void initPanel1() {
		panel1 = new JPanel(new BorderLayout());

		textArea = new JTextArea(20, 20);
		textArea.setEditable(false);
		JScrollPane scroll = new JScrollPane(textArea);

		fileChooser = new JFileChooser();
		FileFilter filter = new FileFilter() {

			@Override
			public boolean accept(File f) {
				String path = f.getAbsolutePath().toLowerCase();
				
				if (path.endsWith(".txt"))
					return true;
				else
					return false;
			}

			@Override
			public String getDescription() {

				return "Text files";
			}

		};

		fileChooser.setFileFilter(filter);

		openFileButton = new JButton("Open");
		openFileButton.addActionListener(this);

		panel1.add(openFileButton, BorderLayout.SOUTH);
		panel1.add(scroll, BorderLayout.CENTER);

	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == openFileButton) {
			int returnValue = fileChooser.showOpenDialog(fileChooser);

			if (returnValue == JFileChooser.APPROVE_OPTION) {
				File file = fileChooser.getSelectedFile();
				textArea.setCaretPosition(textArea.getDocument().getLength());
				
				FileReader fin;
				BufferedReader br = null;
				try {
					fin = new FileReader(file);
					br = new BufferedReader(fin);
				} catch (FileNotFoundException e3) {
					// TODO Auto-generated catch block
					e3.printStackTrace();
				}

				try {
					String eachLine = br.readLine();
					while(eachLine != null) {
						try {
							textArea.append(eachLine);
							textArea.append("\n");
							eachLine = br.readLine();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				} catch (IOException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				
			}
		}
	}

}
