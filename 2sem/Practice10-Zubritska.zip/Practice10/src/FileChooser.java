
import javax.swing.SwingUtilities;

/*Написати графічну програму, що використовуючи JFileChooser дозволяє обрати файл і виводить його зміст.
 * 
 * File: FileChooser.java
 * Author: Zubritska*/

public class FileChooser {

	public static void main(String[] args) {
		
		Runnable FileChooserThread = new Runnable() {
			public void run() {
				new FileChooserApp();
			}
		};
		
		SwingUtilities.invokeLater(FileChooserThread);
	}

}
