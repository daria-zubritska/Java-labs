/*Написати тестувальник який демонтрує роботу написаних вище класів.
 * 
 * File: UseForFactorial.java
 * Author: Zubritska
 * */

import utils.*;

public class UseForFactorial {
	
	public static void main(String[] arg) {
		
		int n = DataInput.getInt("Введіть число: ");
		
		while(true) {
		
		Factorial f = new Factorial(n);
		
		System.out.println("" + f.factorial());
		
		n = DataInput.getInt("Введіть число: ");
		}
		
	}

}
