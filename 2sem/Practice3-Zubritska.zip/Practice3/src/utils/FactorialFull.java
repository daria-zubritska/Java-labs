package utils;

/*Створити клас з методом, що буде обраховувати факторіал додатнього цілого числа. Працювати з BigInteger (в цьому класі немає методу main він буде в подальшому використовуватися в інших програмах).
 * 
 *File: FactorialFull.java
 *Author: Zubritska 
 * */

public class FactorialFull {

	public static long factorialFull(long fact, int n, int k) {
		
		for(int i = k; i<n; i++) {
			fact = fact*(i+1);
		}
		return fact;
		
	}

}
