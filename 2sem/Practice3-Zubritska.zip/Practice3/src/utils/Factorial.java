package utils;
import java.math.BigInteger;

/*Створити клас з методом, що буде обраховувати факторіал від 0 до 20
 *  використовуючи кешовані результати обчислення факторіалів. 
 *  Тобто якщо клас до цього порахував факторіал 5, 
 *  то для обрахування факторіала 6 ми можемо скористуватися вже отриманим попереднім результатом. 
 *  Для цього в класі реалізувати статичний масив значень факторіала від 0 до 20, і статичну змінну, 
 *  що буде вказувати на кількість вже обрахованних факторіалів. 
 *  При спробі обрахувати факторіал більше 20 або менше 0 видавати помилку. 
 *  (в цьому класі немає методу main він буде в подальшому використовуватися в інших програмах).
 * 
 * File: Factorial.java
 * Author: Zubritska
 * */
public class Factorial {
	
	int number;
	static long[] factorialArray = new long[21];
	
	
	public Factorial(int n){
		this.number = n;
		
	}
	
	public String factorial() {
		
		
		if(this.number>20||this.number<0) {
			String error = "Помилка. Число може бути лише у проміжку 0 - 20.";
			
			return error;
		}
		
		BigInteger factorial = findTheFactorial(this.number);
		
		String fct = factorial.toString();
		
		return fct;
	}

	private BigInteger findTheFactorial(int num) {
		
		if(num == 0) {
			return BigInteger.valueOf(1);
		}
		
		long fact = 1;
		int k = num;
		
		if(factorialArray[num] != 0) {
			return BigInteger.valueOf(factorialArray[num]);
		}
		
		for(int i = num; k>0; i--) {
			if(factorialArray[i] == 0) k--;
			else if(k == num) break;
			else {
				fact = factorialArray[k];
				break;
			}
		}
		
		long factFull = FactorialFull.factorialFull(fact, num, k);
		
		factorialArray[num] = factFull;
		
		return BigInteger.valueOf(factFull);
	}
}
