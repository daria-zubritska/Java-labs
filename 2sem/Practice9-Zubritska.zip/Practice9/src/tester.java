/*Створити форму для зчитування логіна і пароля, в разі вірно введених даних виводити секретну інформацію, в іншому випадку видавати помилку (і те, і те - в нових вікнах-повідомленнях).
 * 
 *File: tester.java
 *Author: Zubritska
 * */
public class tester {

	public static void main(String[] args) {
		Users us = new Users();
		User u = new User("admin", "admin");
		us.addUser(u);
		UserForm uf = new UserForm(us);
		uf.start();

	}

}
