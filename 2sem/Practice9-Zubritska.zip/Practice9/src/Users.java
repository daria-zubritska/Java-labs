import java.awt.GridLayout;

import javax.swing.*;


public class Users extends JFrame {
	
	private User[] users;
	private int usersNum = 0;

	Users(){
		this(10);
	}
	
	Users(Users _u){
		this.users = new User[_u.users.length];
		for(int i = 0; i<_u.usersNum; i++) {
			if(_u.users[i] == null) break;
			this.addUser(_u.users[i]);
		}
	}
	
	Users(int q){
		this.users = new User[q];
	}
	
	public void addUser(User u) {
		users[usersNum++] = new User(u);
	}
	
	public boolean checkUser(User _u) {
		if(usersNum>0)
		for(int i = 0; i<usersNum; i++) {
			if((this.users[i].getLogin().compareTo(_u.getLogin()) == 0) && (this.users[i].getPassword().compareTo(_u.getPassword()) == 0)) {
				return true;
			}
		}
		
		return false;
	}

}

class User{
	private String login = "";
	private String password = "";
	
	User(String loginU, String passwordU){
		this.login = this.login.concat(loginU);
		this.password = this.password.concat(passwordU);
	}
	
	User(User u){
		this.login = this.login.concat(u.login);
		this.password = this.password.concat(u.password);
	}
	
	public String getLogin() {
		return this.login;
	}
	
	public String getPassword() {
		return this.password;
	}
}
