import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;


public class UserForm extends JFrame{
	
	private Users users;
	
	private JPanel mainMenu;
	private JPanel secretPanel;
	
	private JTextField loginField;
	private JPasswordField passwordField;
	
	private JButton logInButton;
	
	UserForm(Users _u){
		this.users = new Users(_u);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setSize(300, 200);
		
	}
	

	private void init() {
		mainMenu = new JPanel(new GridLayout(3,2));
		
		mainMenu.add(new JLabel("Login: "));
		loginField = new JTextField();
		loginField.setSize(100, 20);
		mainMenu.add(loginField);
		
		mainMenu.add(new JLabel("Password: "));
		passwordField = new JPasswordField();
		passwordField.setSize(100, 20);
		mainMenu.add(passwordField);
		
		logInButton = new JButton("Log In");
		logInButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				User atempt = new User(loginField.getText(), passwordField.getText());
				if(users.checkUser(atempt)) {
					initSecret();
				}
				else {
					JOptionPane.showMessageDialog(null, "Wrong password or login", "Error", JOptionPane.ERROR_MESSAGE);
				}
				
			}});
		mainMenu.add(logInButton);
	}
	
	protected void initSecret() {
		JOptionPane.showMessageDialog(null, "THIS IS TOP SECRET INFORMATION", "SECRET", JOptionPane.PLAIN_MESSAGE);
	}
	
	public void start() {
		this.setVisible(true);
		init();
		add(mainMenu);
		pack();
		
	}

}
