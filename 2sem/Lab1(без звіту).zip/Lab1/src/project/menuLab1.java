package project;

/*Написати програму, що буде формувати список студентів та викладачів університету НаУКМА.

Відповідно мають бути реалізовані такі можливості роботи, як:

Створити/видалити/редагувати факультет.
Створити/видалити/редагувати кафедру факультета.
Додати/видалити/редагувати студента/викладача до кафедри.
Знайти студента/викладача за ПІБ, курсом або групою.
Вивести всіх студентів впорядкованих за курсами.
Вивести всіх студентів/викладачів факультета впорядкованих за алфавітом.
Вивести всіх студентів кафедри впорядкованих за курсами.
Вивести всіх студентів/викладачів кафедри впорядкованих за алфавітом.
Вивести всіх студентів кафедри вказаного курсу.
Вивести всіх студентів кафедри вказаного курсу впорядкованих за алфавітом.

File: menuLab1.java
Authors: Zubritska, Pihotskyic
 * */

import utils.*;

import java.io.IOException;

import lab.src.lab.*;

public class menuLab1 {

	static int n;
	static int student = 0;
	static int educator = 0;
	static int faculty = 0;
	static int department = 0;

	static Faculty adminFac = new Faculty();
	static Department adminDep = new Department();
	static Student adminStud = new Student();
	static Educator adminEd = new Educator();

	// перший інтерфейс
	public static void main(String[] arg) throws IOException {

		while (true) {

			System.out.println("0. Завершити виконання програми.\r\n" + "1. Створити/видалити/редагувати факультет.\r\n"
					+ "2. Створити/видалити/редагувати кафедру факультета.\r\n"
					+ "3. Додати/видалити/редагувати студента/викладача до кафедри.\r\n"
					+ "4. Знайти студента/викладача за ПІБ, курсом або групою.\r\n"
					+ "5. Вивести всіх студентів впорядкованих за курсами.\r\n"
					+ "6. Вивести всіх студентів/викладачів факультета впорядкованих за алфавітом.\r\n"
					+ "7. Вивести всіх студентів кафедри впорядкованих за курсами.\r\n"
					+ "8. Вивести всіх студентів/викладачів кафедри впорядкованих за алфавітом.\r\n"
					+ "9. Вивести всіх студентів кафедри вказаного курсу.\r\n"
					+ "10. Вивести всіх студентів кафедри вказаного курсу впорядкованих за алфавітом.");

			n = DataInput.getInt("Введіть номер, що відповідає потрібній команді: ");

			while (n < 0 || n > 10) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Роботу завершено.");
				break;
			}

			menu();

		}

	}

	// перехід між функціями головного меню
	private static void menu() throws IOException {

		switch (n) {

		case (1): {

			createDeleteRedFaculty();

			break;
		}

		case (2): {

			createDeleteRedDepartment();

			break;
		}

		case (3): {

			createDeleteRedStudentOrTeacher();

			break;
		}

		case (4): {

			findSomeone();

			break;
		}

		case (5): {

			studentsList();

			break;
		}

		case (6): {

			studentsOrTeachersAlphabetList();

			break;
		}

		case (7): {

			studentsListByCoursesDep();

			break;
		}

		case (8): {

			studentsOrTeachersListAlphabetDepartment();

			break;
		}

		case (9): {

			studentsListDepartmentCourse();

			break;
		}

		case (10): {

			studentsListDepCourAlphabet();

			break;
		}

		}
	}

	// вивести всіх студентів кафедри вказаного курсу впорядкованих за алфавітом. ready
	// Вивести всіх студентів кафедри вказаного курсу впорядкованих за
	// алфавітом.ready
	private static void studentsListDepCourAlphabet() {
		while (true) {

			System.out.println(
					"(1)Вивести всіх студентів кафедри вказаного курсу впорядкованих за алфавітом. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 1) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}

			if (faculty == 0) {
				System.out.println("Ви не створили жодного факультету.");
				break;
			} else if (department == 0) {
				System.out.println("Ви не створили жодної кафедри.");
				break;
			} else if (student == 0) {
				System.out.println("Ви не створили жодного студента.");
				break;
			}

			int i = realFaculty();
			int j = realDepartment(i);

			int course = realCourse();

			// вивести всіх студентів кафедри вказаного курсу впорядкованих за алфавітом

			for (int k = 0; k < adminStud.allStudentsByAlphabetFromDepartmentByCourse(i, j, course).length; k++) {

				if (adminStud.allStudentsByAlphabetFromDepartmentByCourse(0, 0, 1)[k] == null)
					break;
				System.out.println(
						k + ". " + adminStud.allStudentsByAlphabetFromDepartmentByCourse(i, j, course)[k].toString());

			}

			break;

		}

	}

	private static int realCourse() {

		n = DataInput.getInt("Введіть курс: ");

		while (n < 1 || n > 4) {
			n = DataInput.getInt("Будь ласка оберіть курс 1-4: ");
		}

		return n;
	}

	// вивести всіх студентів кафедри певного курсу. ready
	// Вивести всіх студентів кафедри вказаного курсу.ready
	private static void studentsListDepartmentCourse() {
		while (true) {

			System.out.println("(1)Вивести всіх студентів кафедри вказаного курсу. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 1) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}
			
			if (faculty == 0) {
				System.out.println("Ви не створили жодного факультету.");
				break;
			} else if (department == 0) {
				System.out.println("Ви не створили жодної кафедри.");
				break;
			} else if (student == 0) {
				System.out.println("Ви не створили жодного студента.");
				break;
			}

			int i = realFaculty();
			int j = realDepartment(i);
			int c = realCourse();

			// вивести всіх студентів кафедри певного курсу
			for (int k = 0; k < adminStud.allStudentsFromDepFromCourse(i, j, c).length; k++) {

				if (adminStud.allStudentsFromDepFromCourse(i, j, c)[k] == null)
					break;
				System.out.println(k + ". " + adminStud.allStudentsFromDepFromCourse(i, j, c)[k].toString());

			}
			break;

		}

	}

	// Вивести всіх студентів/викладачів кафедри впорядкованих за алфавітом.ready
	private static void studentsOrTeachersListAlphabetDepartment() {
		while (true) {

			System.out.println(
					"Вивести всіх (1)студентів/(2)викладачів кафедри впорядкованих за алфавітом. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 2) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}
			
			if (faculty == 0) {
				System.out.println("Ви не створили жодного факультету.");
				break;
			} else if (department == 0) {
				System.out.println("Ви не створили жодної кафедри.");
				break;
			}

			switch (n) {
			case (1): {
				
				if(student == 0) {
					System.out.println("Ви не створили жодного студента."); 
					break; 
					}

				int i = realFaculty();
				int j = realDepartment(i);

				// вивести за алфавітом всіх студентів КАФЕДРИ впорядкованих за алфавітом

				for (int k = 0; k < adminStud.allStudentsByAlphabetFromDepartment(i, j).length; k++) {

					if (adminStud.allStudentsByAlphabetFromDepartment(i, j)[k] == null)
						break;
					System.out.println(k + ". " + adminStud.allStudentsByAlphabetFromDepartment(i, j)[k].toString());

				}

				break;
			}
			case (2): {
				
				if(educator == 0) { System.out.println("Ви не створили жодного викладача.");
				  break; }

				int i = realFaculty();
				int j = realDepartment(i);

				// вивести за алфавітом всіх викладачів КАФЕДРИ впорядкованих за алфавітом
				for (int k = 0; k < adminEd.allEducatorsByAlphabetFromDepartment(i, j).length; k++) {

					if (adminEd.allEducatorsByAlphabetFromDepartment(i, j)[k] == null)
						break;
					System.out.println(k + ". " + adminEd.allEducatorsByAlphabetFromDepartment(i, j)[k].toString());

				}

				break;
			}

			}
		}

	}

	// Вивести всіх студентів кафедри впорядкованих за курсами. ready
	private static void studentsListByCoursesDep() {
		while (true) {

			System.out.println("(1)Вивести всіх студентів кафедри впорядкованих за курсами. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 1) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}
			
			if (faculty == 0) {
				System.out.println("Ви не створили жодного факультету.");
				break;
			} else if (department == 0) {
				System.out.println("Ви не створили жодної кафедри.");
				break;
			} else if (student == 0) {
				System.out.println("Ви не створили жодного студента.");
				break;
			}

			int i = realFaculty();
			int j = realDepartment(i);

			// вивести всіх студентів КАФЕДРИ впорядкованих за курсами

			for (int k = 0; k < adminStud.allStudentsFromDepFromAllCourses(i, j).length; k++) {

				if (adminStud.allStudentsFromDepFromAllCourses(i, j)[k] == null)
					break;
				System.out.println(k + ". " + adminStud.allStudentsFromDepFromAllCourses(i, j)[k].toString());
			}

			break;
		}

	}

	// Вивести всіх студентів/викладачів факультета впорядкованих за алфавітом ready
	private static void studentsOrTeachersAlphabetList() {
		while (true) {

			System.out.println(
					"Вивести всіх (1)студентів/(2)викладачів факультета впорядкованих за алфавітом. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 2) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}
			
			if (faculty == 0) {
				System.out.println("Ви не створили жодного факультету.");
				break;
			} else if (department == 0) {
				System.out.println("Ви не створили жодної кафедри.");
				break;
			}

			switch (n) {
			case (1): {
				
				if (student == 0) {
					System.out.println("Ви не створили жодного студента.");
					break;
				}
				
				int i = realFaculty();
				// вивести студентів факультету впорядкованних за алфавітом
				for (int j = 0; j < adminStud.allStudentsByAlphabetFromFaculty(i).length; j++) {

					if (adminStud.allStudentsByAlphabetFromFaculty(i)[j] == null)
						break;

					System.out.println(j + ". " + adminStud.allStudentsByAlphabetFromFaculty(i)[j].toString());
				}
			}
			case (2): {
				
				if (educator == 0) {
					System.out.println("Ви не створили жодного викладача.");
					break;
				}
				
				int i = realFaculty();

				// вивести викладачів факультету впорядкованних за алфавітом
				for (int k = 0; k < adminEd.allEducatorsByAlphabetFromFaculty(i).length; k++) {
					if (adminEd.allEducatorsByAlphabetFromFaculty(i)[k] == null)
						break;

					System.out.println(k + ". " + adminEd.allEducatorsByAlphabetFromFaculty(i)[k].toString());
				}
				break;
			}

			}
		}

	}
	
	// вивести ВСІХ студентів впорядкованних за курсами

	// Вивести всіх студентів впорядкованих за курсами. ready
	private static void studentsList() {

		while (true) {

			System.out.println("(1)Вивести всіх студентів впорядкованих за курсами. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 1) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}
			
			if (faculty == 0) {
				System.out.println("Ви не створили жодного факультету.");
				break;
			} else if (department == 0) {
				System.out.println("Ви не створили жодної кафедри.");
				break;
			} else if (student == 0) {
				System.out.println("Ви не створили жодного студента.");
				break;
			}

			// вивести ВСІХ студентів впорядкованних за курсами

			for (int i = 0; i < adminStud.allStudentsFromAllCourse().length; i++) {

				System.out.println(i + ". " + adminStud.allStudentsFromAllCourse()[i].toString());
			}

			break;
		}

	}
	
	//Знайти студента/викладача за (1)ПІБ, (2)курсом або (3)групою.

	// Знайти студента/викладача за ПІБ, курсом або групою. ready
	private static void findSomeone() throws IOException {
		while (true) {

			System.out
					.println("Знайти студента/викладача за (1)ПІБ, (2)курсом або (3)групою. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 3) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}

			switch (n) {
			case (1): {
				if (faculty == 0) {
					System.out.println("Ви не створили жодного факультету.");
					break;
				} else if (department == 0) {
					System.out.println("Ви не створили жодної кафедри.");
					break;
				}
				// ПІБ
				System.out.println("Знайти (1)студента/(2)викладача за ПІБ. 0 - вийти в попереднє меню.");

				n = DataInput.getInt("Введіть номер команди: ");

				while (n < 0 || n > 2) {
					n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
				}

				if (n == 0) {
					System.out.println("Повертаюсь до попереднього меню.");
					break;
				}

				switch (n) {
				case (1): {
					if (student == 0) {
						System.out.println("Ви не створили жодного студента.");
						break;
					}
					// знайти студента за піб
					System.out.println("Введіть ім'я студента: ");
					String nameS = DataInput.getString();

					System.out.println("Введіть прізвище студента: ");
					String surnameS = DataInput.getString();

					System.out.println("Введіть ім'я по батькові студента: ");
					String patronymicS = DataInput.getString();

					int a = 0;
					for (int i = 0; i < adminStud.searchByNameSurnamePatronymic(nameS, surnameS,
							patronymicS).length; i++) {

						if (adminStud.searchByNameSurnamePatronymic(nameS, surnameS, patronymicS)[i] == null) {
							continue;
						}

						System.out.println(a + ". "
								+ adminStud.searchByNameSurnamePatronymic(nameS, surnameS, patronymicS)[i].toString());
						a++;
					}
					break;
				}
				case (2): {
					if (educator == 0) {
						System.out.println("Ви не створили жодного викладача.");
						break;
					}
					// знайти викладача за піб
					System.out.println("Введіть ім'я викладача: ");
					String nameS = DataInput.getString();

					System.out.println("Введіть прізвище викладача: ");
					String surnameS = DataInput.getString();

					System.out.println("Введіть ім'я по батькові викладача: ");
					String patronymicS = DataInput.getString();

					int a = 0;
					for (int i = 0; i < adminEd.searchByNameSurnamePatronymic(nameS, surnameS,
							patronymicS).length; i++) {

						if (adminEd.searchByNameSurnamePatronymic(nameS, surnameS, patronymicS)[i] == null) {
							continue;
						}

						System.out.println(a + ". "
								+ adminEd.searchByNameSurnamePatronymic(nameS, surnameS, patronymicS)[i].toString());
						a++;
					}
					break;
				}
				}
			}
			case (2): {
				if (faculty == 0) {
					System.out.println("Ви не створили жодного факультету.");
					break;
				} else if (department == 0) {
					System.out.println("Ви не створили жодної кафедри.");
					break;
				}
				// курс
				System.out.println("Знайти (1)студента/(2)викладача за курсом. 0 - вийти в попереднє меню.");

				n = DataInput.getInt("Введіть номер команди: ");

				while (n < 0 || n > 2) {
					n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
				}

				if (n == 0) {
					System.out.println("Повертаюсь до попереднього меню.");
					break;
				}

				switch (n) {
				case (1): {
					if (student == 0) {
						System.out.println("Ви не створили жодного студента.");
						break;
					}
					// знайти студента за курсом
					int i = realCourse();

					int a = 0;
					for (int k = 0; k < adminStud.searchByCourse(i).length; k++) {

						if (adminStud.searchByCourse(i)[k] == null) {
							continue;
						}

						System.out.println(a + ". " + adminStud.searchByCourse(i)[k].toString());
						a++;
					}
					break;
				}
				case (2): {
					if (educator == 0) {
						System.out.println("Ви не створили жодного викладача.");
						break;
					}
					// знайти викладача за курсом
					int i = realCourse();

					int a = 0;
					for (int k = 0; k < adminEd.searchByCourse(i).length; k++) {

						if (adminEd.searchByCourse(i)[k] == null) {
							continue;
						}

						System.out.println(a + ". " + adminEd.searchByCourse(i)[k].toString());
						a++;
					}

					break;
				}
				}
			}
			case (3): {
				if (faculty == 0) {
					System.out.println("Ви не створили жодного факультету.");
					break;
				} else if (department == 0) {
					System.out.println("Ви не створили жодної кафедри.");
					break;
				}
				// група
				System.out.println("Знайти (1)студента/(2)викладача за групою. 0 - вийти в попереднє меню.");

				n = DataInput.getInt("Введіть номер команди: ");

				while (n < 0 || n > 2) {
					n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
				}

				if (n == 0) {
					System.out.println("Повертаюсь до попереднього меню.");
					break;
				}

				switch (n) {
				case (1): {
					if (student == 0) {
						System.out.println("Ви не створили жодного студента.");
						break;
					}
					int i = DataInput.getInt("Введіть номер групи: ");

					while (i < 1) {
						i = DataInput.getInt("Номер групи не може бути від'ємним: ");
					}
					// знайти студента за групою

					int a = 0;
					for (int k = 0; k < adminStud.searchByGroup(i).length; k++) {
						if (adminStud.searchByGroup(i)[k] == null) {
							continue;
						}
						System.out.println(a + ". " + adminStud.searchByGroup(i)[k].toString());
						a++;
					}
					break;
				}
				case (2): {
					if (educator == 0) {
						System.out.println("Ви не створили жодного викладача.");
						break;
					}
					// знайти викладача за групою
					int i = DataInput.getInt("Введіть номер групи: ");

					while (i < 1) {
						i = DataInput.getInt("Номер групи не може бути від'ємним: ");
					}

					int a = 0;
					for (int k = 0; k < adminEd.searchByGroup(i).length; k++) {
						if (adminEd.searchByGroup(i)[k] == null) {
							continue;
						}
						System.out.println(a + ". " + adminEd.searchByGroup(i)[k].toString());
						a++;
					}
					break;
				}
				}
			}
			}
		}

	}

	// Додати/видалити/редагувати студента/викладача до кафедри. ready
	
	//(1)Додати/(2)видалити/(3)редагувати студента/викладача до кафедри
	private static void createDeleteRedStudentOrTeacher() throws IOException {
		while (true) {

			System.out.println(
					"(1)Додати/(2)видалити/(3)редагувати студента/викладача до кафедри. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 3) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}

			switch (n) {
			case (1): {
				if (faculty == 0) {
					System.out.println("Ви не створили жодного факультету.");
					break;
				} else if (department == 0) {
					System.out.println("Ви не створили жодної кафедри.");
					break;
				}
				// додати студента\викладача
				System.out.println("Додати (1)студента/(2)викладача до кафедри. 0 - вийти в попереднє меню.");

				n = DataInput.getInt("Введіть номер команди: ");

				while (n < 0 || n > 2) {
					n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
				}

				if (n == 0) {
					System.out.println("Повертаюсь до попереднього меню.");
					break;
				}

				switch (n) {
				case (1): {

					// додати студента до кафедри
					int i = realFaculty();
					int j = realDepartment(i);

					System.out.println("Введіть ім'я студента: ");
					String nameS = DataInput.getString();

					while (!isItName(nameS)) {
						System.out.println("Введіть ім'я студента без цифр: ");
						nameS = DataInput.getString();
					}

					System.out.println("Введіть прізвище студента: ");
					String Surname = DataInput.getString();

					while (!isItName(Surname)) {
						System.out.println("Введіть прізвище студента без цифр: ");
						Surname = DataInput.getString();
					}

					System.out.println("Введіть ім'я по батькові студента: ");
					String patronymicS = DataInput.getString();

					while (!isItName(patronymicS)) {
						System.out.println("Введіть ім'я по батькові студента без цифр: ");
						patronymicS = DataInput.getString();
					}

					int ageS = DataInput.getInt("Введіть вік студента: ");

					double avgM = realMark();

					int course = realCourse();
					String courseS = Integer.toString(course);

					int groupS = DataInput.getInt("Введіть групу студента: ");

					adminStud.addSt(i, j, ageS, nameS, Surname, avgM, patronymicS, courseS, groupS);
					student++;
					break;

				}
				case (2): {

					// додати викладача до кафедри
					int i = realFaculty();
					int j = realDepartment(i);

					System.out.println("Введіть ім'я викладача: ");
					String nameE = DataInput.getString();

					while (!isItName(nameE)) {
						System.out.println("Введіть ім'я викладача без цифр: ");
						nameE = DataInput.getString();
					}

					System.out.println("Введіть прізвище викладача: ");
					String Surname = DataInput.getString();

					while (!isItName(Surname)) {
						System.out.println("Введіть прізвище викладача без цифр: ");
						Surname = DataInput.getString();
					}

					System.out.println("Введіть ім'я по батькові викладача: ");
					String patronymicE = DataInput.getString();

					while (!isItName(patronymicE)) {
						System.out.println("Введіть ім'я по батькові викладача без цифр: ");
						patronymicE = DataInput.getString();
					}

					int ageE = DataInput.getInt("Введіть вік викладача: ");

					int course = realCourse();
					String courseE = Integer.toString(course);

					int groupE = DataInput.getInt("Введіть групу викладача: ");

					adminEd.addSt(i, j, nameE, Surname, ageE, patronymicE, courseE, groupE);
					educator++;
					break;
				}
				}
				break;
			}
			case (2): {
				if (faculty == 0) {
					System.out.println("Ви не створили жодного факультету.");
					break;
				} else if (department == 0) {
					System.out.println("Ви не створили жодної кафедри.");
					break;
				}
				// видалити студента\викладача
				System.out.println("Видалити (1)студента/(2)викладача з кафедри. 0 - вийти в попереднє меню.");

				n = DataInput.getInt("Введіть номер команди: ");

				while (n < 0 || n > 2) {
					n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
				}

				if (n == 0) {
					System.out.println("Повертаюсь до попереднього меню.");
					break;
				}

				switch (n) {
				case (1): {
					if (student == 0) {
						System.out.println("Ви не створили жодного студента.");
					}
					// видалити студента
					int i = realFaculty();
					int j = realDepartment(i);
					int k = realStudent(i, j);

					adminStud.delete(i, j, k);
					student--;
					break;
				}
				case (2): {
					if (educator == 0) {
						System.out.println("Ви не створили жодного викладача.");
					}
					// видалити викладача
					int i = realFaculty();
					int j = realDepartment(i);
					int k = realEducator(i, j);

					adminEd.delete(i, j, k);
					educator--;
					break;
				}
				}
				break;
			}
			case (3): {
				if (faculty == 0) {
					System.out.println("Ви не створили жодного факультету.");
					break;
				} else if (department == 0) {
					System.out.println("Ви не створили жодної кафедри.");
					break;
				}
				// редагувати студента\викладача
				System.out.println("Редагувати (1)студента/(2)викладача кафедри. 0 - вийти в попереднє меню.");

				n = DataInput.getInt("Введіть номер команди: ");

				while (n < 0 || n > 2) {
					n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
				}

				if (n == 0) {
					System.out.println("Повертаюсь до попереднього меню.");
					break;
				}

				switch (n) {
				case (1): {
					if (student == 0) {
						System.out.println("Ви не створили жодного студента.");
					}
					// редагувати студента
					int i = realFaculty();
					int j = realDepartment(i);
					int k = realStudent(i, j);

					System.out.println("Введіть ім'я студента: ");
					String nameS = DataInput.getString();

					while (!isItName(nameS)) {
						System.out.println("Введіть ім'я студента без цифр: ");
						nameS = DataInput.getString();
					}

					System.out.println("Введіть прізвище студента: ");
					String Surname = DataInput.getString();

					while (!isItName(Surname)) {
						System.out.println("Введіть прізвище студента без цифр: ");
						Surname = DataInput.getString();
					}

					System.out.println("Введіть ім'я по батькові студента: ");
					String patronymicS = DataInput.getString();

					while (!isItName(patronymicS)) {
						System.out.println("Введіть ім'я по батькові студента без цифр: ");
						patronymicS = DataInput.getString();
					}

					int ageS = DataInput.getInt("Введіть вік студента: ");

					double avgM = realMark();

					int course = realCourse();
					String courseS = Integer.toString(course);

					int groupS = DataInput.getInt("Введіть групу студента: ");

					System.out.println("Введіть номер факультету на який хочете перемістити студента. ");
					int facToChange = realFaculty();

					System.out.println("Введіть номер кафедри на яку хочете перемістити студента. ");
					int depToChange = realDepartment(facToChange);

					adminStud.reSet(i, j, k, facToChange, depToChange, ageS, nameS, Surname, avgM, patronymicS, courseS,
							groupS);

					break;
				}
				case (2): {
					if (student == 0) {
						System.out.println("Ви не створили жодного викладача.");
					}
					// редагувати викладача
					int i = realFaculty();
					int j = realDepartment(i);
					int k = realEducator(i, j);

					System.out.println("Введіть ім'я викладача: ");
					String nameE = DataInput.getString();

					while (!isItName(nameE)) {
						System.out.println("Введіть ім'я викладача без цифр: ");
						nameE = DataInput.getString();
					}

					System.out.println("Введіть прізвище викладача: ");
					String SurnameE = DataInput.getString();

					while (!isItName(SurnameE)) {
						System.out.println("Введіть прізвище викладача без цифр: ");
						SurnameE = DataInput.getString();
					}

					System.out.println("Введіть ім'я по батькові викладача: ");
					String patronymicE = DataInput.getString();

					while (!isItName(patronymicE)) {
						System.out.println("Введіть ім'я по батькові викладача: ");
						patronymicE = DataInput.getString();
					}

					int ageE = DataInput.getInt("Введіть вік викладача: ");

					int course = realCourse();
					String courseE = Integer.toString(course);

					int groupE = DataInput.getInt("Введіть групу викладача: ");

					System.out.println("Введіть номер факультету на який хочете перемістити викладача. ");
					int facToChange = realFaculty();

					System.out.println("Введіть номер кафедри на яку хочете перемістити викладача. ");
					int depToChange = realDepartment(facToChange);

					adminEd.reSet(i, j, k, facToChange, depToChange, nameE, SurnameE, ageE, patronymicE, courseE,
							groupE);
					break;
				}
				}
				break;
			}

			}
		}

	}


	private static double realMark() {
		System.out.println("Введіть середню оцінку студента: ");
		double i = DataInput.getDouble();

		while (i < 0 || i > 100) {
			System.out.println("Введіть середню оцінку студента 0 - 100: ");
			i = DataInput.getDouble();
		}

		return 0;
	}

	
	private static boolean isItName(String str) {

		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if (Character.isDigit(ch)) {
				return false;
			}
		}

		return true;
	}

	
	private static int realEducator(int i, int j) {

		int k = 0;

		for (int n = 0; n < Educator.getCounterE(i, j); n++) {

			Educator timeObj = adminEd.getEducator(i, j, n);

			System.out.println(n + ". " + timeObj.toString());

			k = j;
		}

		int n = DataInput.getInt("Введіть номер викладача: ");

		while (n < 0 || n > k) {
			n = DataInput.getInt("Введіть існуючий номер викладача: ");
		}

		return n;
	}

	
	private static int realStudent(int i, int j) {

		int k = 0;

		for (int n = 0; n < Student.getCounter(i, j); n++) {

			Student timeObj = adminStud.getStudent(i, j, n);

			System.out.println(n + ". " + timeObj.toString());

			k = j;
		}

		int n = DataInput.getInt("Введіть номер студента: ");

		while (n < 0 || n > k) {
			n = DataInput.getInt("Введіть існуючий номер студента: ");
		}

		return n;
	}
	
	//(1)Створити/(2)видалити/(3)редагувати кафедру факультета.

	// Створити/видалити/редагувати кафедру факультета. ready
	private static void createDeleteRedDepartment() throws IOException {
		while (true) {

			System.out.println("(1)Створити/(2)видалити/(3)редагувати кафедру факультета. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 3) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}

			switch (n) {
			case (1): {

				if (faculty == 0) {
					System.out.println("Ви не створили жодного факультету.");
					break;
				}

				int i = realFaculty();

				System.out.println("Введіть назву нової кафедри: ");

				String userStr1 = DataInput.getString();

				adminDep.addDepartemnt(userStr1, i);
				department++;
				break;
			}
			case (2): {
				if (faculty == 0) {
					System.out.println("Ви не створили жодного факультету.");
					break;
				} else if (department == 0) {
					System.out.println("Ви не створили жодної кафедри.");
					break;
				}

				// видалити кафедру факультету
				int i = realFaculty();
				int j = realDepartment(i);

				adminDep.delete(i, j);
				;
				department--;
				break;
			}
			case (3): {
				if (faculty == 0) {
					System.out.println("Ви не створили жодного факультету.");
					break;
				} else if (department == 0) {
					System.out.println("Ви не створили жодної кафедри.");
					break;
				}

				// редагувати кафедру факультету
				int i = realFaculty();
				int j = realDepartment(i);

				System.out.println("Введіть нову назву кафедри: ");
				String nameD = DataInput.getString();

				System.out.println("Введіть номер факультету на який хочете перемістити кафедру. ");
				int facToChange = realFaculty();

				adminDep.reSet(i, j, facToChange, nameD);

				break;
			}

			}
		}

	}

	// Створити/видалити/редагувати факультет. ready
	
	//(1)Створити/(2)видалити/(3)редагувати факультет.
	private static void createDeleteRedFaculty() throws IOException {

		while (true) {

			System.out.println("(1)Створити/(2)видалити/(3)редагувати факультет. 0 - вийти в голове меню.");

			n = DataInput.getInt("Введіть номер команди: ");

			while (n < 0 || n > 3) {
				n = DataInput.getInt("Будь ласка оберіть існуючу команду: ");
			}

			if (n == 0) {
				System.out.println("Повертаюсь до головного меню.");
				break;
			}

			switch (n) {
			case (1): {
				System.out.println("Введіть назву факультету: ");

				String userStr1 = DataInput.getString();

				adminFac.addFac(userStr1);
				faculty++;
				break;

			}
			case (2): {
				if (faculty == 0) {
					System.out.println("Ви не створили жодного факультету.");
					break;
				}

				int i = realFaculty();
				// видалити факультет
				adminFac.delete(i);
				faculty--;
				break;

			}
			case (3): {
				// редагувати факультет

				if (faculty == 0) {
					System.out.println("Ви не створили жодного факультету.");
					break;
				}

				int j = realFaculty();

				System.out.println("Введіть нову назву кафедри: ");
				String nameF = DataInput.getString();

				adminFac.reSet(j, nameF);

				break;

			}

			}
		}

	}

	
	private static int realFaculty() {

		int k = 0;

		for (int i = 0; i < adminFac.getCounter(); i++) {

			Faculty timeObj = adminFac.getFac(i);

			System.out.println(i + ". " + timeObj.getNameF());

			k = i;
		}

		int i = DataInput.getInt("Введіть номер факультету: ");

		while (i < 0 || i > k) {
			i = DataInput.getInt("Введіть існуючий номер факультету: ");
		}

		return i;
	}


	private static int realDepartment(int i) {

		int k = 0;

		for (int j = 0; j < adminDep.getCounter(i); j++) {

			Department timeObj = adminDep.getDepartment(i, j);

			System.out.println(j + ". " + timeObj.getNameD());

			k = j;
		}

		int j = DataInput.getInt("Введіть номер кафедри: ");

		while (j < 0 || j > k) {
			j = DataInput.getInt("Введіть існуючий номер кафедри: ");
		}

		return j;
	}
}
