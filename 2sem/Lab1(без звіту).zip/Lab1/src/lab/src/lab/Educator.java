package lab.src.lab;

public class Educator extends Department {
	
	String nameE;
	String SurnameE;
	int ageE;
	static int counterE;
	String patronimicE;
	String courseE;
	int groupE;
	int j;
	int indexE;

	public Educator(String nameF, String nameD, int i, int j, String nameE, String SurnameE, int ageE,
			String patronimicE, String courseE, int groupE) {
		super(nameF, nameD, i);
		this.j = j;
		this.nameE = nameE;
		this.SurnameE = SurnameE;
		this.ageE = ageE;
		this.patronimicE = patronimicE;
		if (fac[i] == null) {
			System.out.println("Sorry, you must creat a faculty at first!");
			return;
		}
		if (fac[i].dep[j] == null) {
			System.out.println("Sorry, you must creat a department at first!");
			return;
		}
		this.indexE = fac[i].dep[j].amountOfEducators;
		this.courseE = courseE;
		this.groupE = groupE;
	}

	public Educator() {
		//порожній конструктор для виклика методів у коді
	}

	public void addSt(int i, int j, String nameE, String SurnameE, int ageE, String patronimicE, String courseE,
			int groupE) {
		Educator ed = new Educator(fac[i].getNameF(), fac[i].dep[j].nameD, i, j, nameE, SurnameE, ageE, patronimicE,
				courseE, groupE);

		if (fac[i].dep[j].educators.length > fac[i].dep[j].amountOfEducators)
			fac[i].dep[j].educators[fac[i].dep[j].amountOfEducators] = ed;
		else {
			Educator temp[] = new Educator[fac[i].dep[j].amountOfEducators + 10];
			temp = educators;
			for (int k = 0; k < fac[i].dep[j].educators.length; k++)
				temp[k] = fac[i].dep[j].educators[k];
			fac[i].dep[j].educators = temp;
		}
		counterE++;
		fac[i].dep[j].amountOfEducators++;
		
	}

	public void reSet(int i, int j, int k, int facTochange, int depToChange, String nameE, String SurnameE, int ageE,
			String patronimicE, String courseE, int groupE) {
		if (fac[facTochange] == null)
			return;

		if (fac[facTochange].dep[depToChange] == null)
			return;

		else if (fac[i].dep[j].students[k] == fac[facTochange].dep[depToChange].students[k]) {
			fac[i].dep[j].educators[k] = new Educator(fac[i].getNameF(), fac[i].dep[j].nameD, i, j, nameE, SurnameE,
					ageE, patronimicE, courseE, groupE);
		} else {
			delete(i, j, k);
			fac[facTochange].dep[depToChange].educators[getCounterE(facTochange, depToChange)] = new Educator(
					fac[facTochange].getNameF(), fac[facTochange].dep[depToChange].nameD, i, j, nameE, SurnameE, ageE,
					patronimicE, courseE, groupE);

			fac[facTochange].dep[depToChange].amountOfEducators++;
			counterE++;
		}
	}

	public void delete(int i, int j, int k) {
		fac[i].dep[j].educators[k] = null;

		fac[i].dep[j].educators[k] = fac[i].dep[j].educators[getCounterE(i, j)];
		fac[i].dep[j].amountOfEducators--;
		counterE--;
	}

	public Educator[] allEducators() {
		int counter = 0;
		Educator[] allEducators = new Educator[counterE];
		for (int i = 0; i < Faculty.counterF; i++) {
			for (int j = 0; j < fac[i].amountOfDep; j++) {
				for (int j2 = 0; j2 < fac[i].dep[j].amountOfEducators; j2++) {
					allEducators[counter] = fac[i].dep[j].educators[j2];
					counter++;
				}
			}
		}
		return allEducators;
	}

	public Educator[] searchByName(String nameS) {
		Educator[] byName = new Educator[counterE];
		for (int i = 0; i < allEducators().length; i++) {
			if (allEducators()[i].getNameE().equals(nameS))
				byName[i] = allEducators()[i];
		}
		return byName;
	}

	public Educator[] searchBySurname(String surnameS) {
		Educator[] byName = new Educator[counterE];
		for (int i = 0; i < allEducators().length; i++) {
			if (allEducators()[i].getSurnameE().equals(surnameS))
				byName[i] = allEducators()[i];
		}
		return byName;
	}

	public Educator[] searchByPatronymic(String patronymicS) {
		Educator[] byName = new Educator[counterE];
		for (int i = 0; i < allEducators().length; i++) {
			if (allEducators()[i].getPatronimicE().equals(patronymicS))
				byName[i] = allEducators()[i];
		}
		return byName;
	}

	public Educator[] searchByGroup(int i) {
		Educator[] byName = new Educator[counterE];
		for (int j = 0; j < allEducators().length; j++) {
			if (j != 0 && byName[j - 1] == null) {
				if (allEducators()[j].getGroupE() == i)
					byName[j - 1] = allEducators()[j];
			}
			else if (allEducators()[j].getGroupE() == i)
				byName[j] = allEducators()[j];
		}
		return byName;
	}

	public Educator[] getEd(int i, int j) {
		return fac[i].dep[j].educators;
	}

	public String getNameE() {
		return nameE;
	}

	public void setNameE(String nameE) {
		this.nameE = nameE;
	}

	public String getSurnameE() {
		return SurnameE;
	}

	public void setSurnameE(String surnameE) {
		SurnameE = surnameE;
	}

	public int getAgeE() {
		return ageE;
	}

	public void setAgeE(int ageE) {
		this.ageE = ageE;
	}

	public static int getCounterE(int i, int j) {
		return fac[i].dep[j].amountOfEducators;
	}

	public static void setCounterE(int counterE) {
		Educator.counterE = counterE;
	}

	public String getPatronimicE() {
		return patronimicE;
	}

	public void setPatronimicE(String patronimicE) {
		this.patronimicE = patronimicE;
	}

	public String getCourseE() {
		return courseE;
	}

	public void setCourseE(String courseE) {
		this.courseE = courseE;
	}

	public int getGroupE() {
		return groupE;
	}

	public void setGroupE(int groupE) {
		this.groupE = groupE;
	}

	public int getJ() {
		return j;
	}

	public void setJ(int j) {
		this.j = j;
	}

	public int getIndexE() {
		return indexE;
	}

	public void setIndexE(int indexE) {
		this.indexE = indexE;
	}

	public Educator getEducator(int i, int j, int k) {
		return fac[i].dep[j].educators[k];
	}

	private static String inputToStreamline(String input) {
		input = input.replaceAll(" ", "");
		input = input.toLowerCase();
		return input;
	}

	public Educator[] allEducatorsByAlphabetFromDepartment(int i, int j) {
		Educator[] st = Faculty.fac[i].dep[j].educators;
		String[] mas = new String[Faculty.fac[i].dep[j].amountOfEducators];
		for (int j1 = 0; j1 < mas.length; j1++) {
			mas[j1] = (allEducators()[j1].getNameE() + allEducators()[j1].getSurnameE()
					+ allEducators()[j1].getPatronimicE());
			mas[j1] = inputToStreamline(mas[j1]);
		}
		boolean isSorted = false;
		Educator buf;
		String mmas;
		while (!isSorted) {
			isSorted = true;
			for (int i1 = 0; i1 < mas.length - 1; i1++) {
				if (mas[i1].compareTo(mas[i1 + 1]) > 0) {
					mmas = mas[i1];
					mas[i1] = mas[i1 + 1];
					mas[i1 + 1] = mmas;
					isSorted = false;
					buf = st[i1];
					st[i1] = st[i1 + 1];
					st[i1 + 1] = buf;
				}
			}
		}
		return st;
	}

	public Educator[] searchByNameSurnamePatronymic(String nameS, String surnameS, String patronymicS) {
		Educator[] byName = new Educator[counterE];
		String str = nameS + surnameS + patronymicS;
		Student.inputToStreamline(str);
		String str1;
		for (int i = 0; i < allEducators().length; i++) {
			str1 = allEducators()[i].getNameE() + allEducators()[i].getSurnameE() + allEducators()[i].getPatronimicE();
			Educator.inputToStreamline(str1);
			if (i != 0 && byName[i - 1] == null) {
				if (str.equals(str1)) {
					byName[i - 1] = allEducators()[i];
				}
			}
			else if (str.equals(str1))
				byName[i] = allEducators()[i];
		}
		return byName;
	}

	public Educator[] searchByCourse(int i) {
		Educator[] byName = new Educator[counterE];
		for (int j = 0; j < allEducators().length; j++) {
			if (j != 0 && byName[j - 1] == null) {
				if (Integer.parseInt(allEducators()[j].getCourseE()) == i)
					byName[j - 1] = allEducators()[j];
			}
			else if (Integer.parseInt(allEducators()[j].getCourseE()) == i)
				byName[j] = allEducators()[j];
		}
		return byName;
		
	}

	public String toString() {
		return nameE + " " + patronimicE + " " + SurnameE + " age= " + ageE + " course= " + courseE + " group = "
				+ groupE;
	}

	public Educator[] allEducatorsFromFaculty(int i) {
		int counter = 0;
		Educator[] allEducators = new Educator[counterE];
		for (int j = 0; j < fac[i].amountOfDep; j++) {
			for (int j2 = 0; j2 < fac[i].dep[j].amountOfEducators; j2++) {
				allEducators[counter] = fac[i].dep[j].educators[j2];
				counter++;
			}
		}
		return allEducators;
	}

	public Educator[] allEducatorsByAlphabetFromFaculty(int i) {
		Educator[] st = allEducatorsFromFaculty(i);
		String[] mas = new String[allEducatorsFromFaculty(i).length];
		for (int j = 0; j < mas.length; j++) {
			if (allEducatorsFromFaculty(i)[j] == null)
				break;
			mas[j] = (allEducatorsFromFaculty(i)[j].getNameE() + allEducatorsFromFaculty(i)[j].getSurnameE()
					+ allEducatorsFromFaculty(i)[j].getPatronimicE());
			mas[j] = inputToStreamline(mas[j]);
		}
		boolean isSorted = false;
		Educator buf;
		String mmas;
		while (!isSorted) {
			isSorted = true;
			for (int k = 0; k < mas.length - 1; k++) {
				if (mas[k + 1] == null)
					break;
				if (mas[k].compareTo(mas[k + 1]) > 0) {
					mmas = mas[k];
					mas[k] = mas[k + 1];
					mas[k + 1] = mmas;
					isSorted = false;
					buf = st[k];
					st[k] = st[k + 1];
					st[k + 1] = buf;
				}
			}
		}
		return st;
	}
}
