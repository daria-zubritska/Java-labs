package project;

public class Rectangle extends Quadrangle {
	Rectangle() {
		vertices = new Point[4];
		vertices[0] = new Point(0,0);
		vertices[1] = new Point(0, 1);
		vertices[2] = new Point(1, 1);
		vertices[2] = new Point(1, 0);

		sides = new double[4];
		sides[0] = 1.0;
		sides[1] = 1.0;
		sides[2] = 1.0;
		sides[3] = 1.0;

		angles = new double[4];
		angles[0] = 90.0;
		angles[1] = 90.0;
		angles[2] = 90.0;
		angles[3] = 90.0;
	}

	Rectangle(Point ver1, Point ver3) {
		vertices = new Point[4];
		vertices[0] = new Point(ver1.coordinates[0], ver1.coordinates[1]);
		vertices[1] = new Point(ver1.coordinates[0], ver3.coordinates[1]);
		vertices[2] = new Point(ver3.coordinates[0], ver3.coordinates[1]);
		vertices[3] = new Point(ver3.coordinates[0], ver1.coordinates[1]);

		sides = new double[4];
		sides[0] = ver3.coordinates[1] - ver1.coordinates[1];
		sides[1] = ver3.coordinates[0] - ver1.coordinates[0];
		sides[2] = sides[0];
		sides[3] = sides[1];
		;

		angles = new double[4];
		angles[0] = 90.0;
		angles[1] = 90.0;
		angles[2] = 90.0;
		angles[3] = 90.0;
	}

	@Override
	public double calculatePerimeter() {
		return sides[0] + sides[1] + sides[2] + sides[3];
	}

	@Override
	public double calculateSquare() {
		
		return sides[0]*sides[1];
	}

	@Override
	public String toString() {
		return "" + calculatePerimeter() + " " + calculateSquare();
	}
}
