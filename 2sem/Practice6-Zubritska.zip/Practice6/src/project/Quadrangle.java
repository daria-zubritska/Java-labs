package project;

public class Quadrangle extends GeometryShape {

	Quadrangle() {
		vertices = new Point[4];
		vertices[0] = new Point(0,0);
		vertices[1] = new Point(0, 1);
		vertices[2] = new Point(1, 1);
		vertices[3] = new Point(1, 0);

		sides = new double[4];
		sides[0] = 1.0;
		sides[1] = 1.0;
		sides[2] = 1.0;
		sides[3] = 1.0;

		angles = new double[4];
		angles[0] = 90.0;
		angles[1] = 90.0;
		angles[2] = 90.0;
		angles[3] = 90.0;
	}

	Quadrangle(Point ver1, Point ver2, Point ver3, Point ver4, double ang1, double ang2, double ang3, double ang4) {
		vertices = new Point[4];
		vertices[0] = new Point(ver1.coordinates[0], ver1.coordinates[1]);
		vertices[1] = new Point(ver2.coordinates[0], ver2.coordinates[1]);
		vertices[2] = new Point(ver3.coordinates[0], ver3.coordinates[1]);
		vertices[3] = new Point(ver4.coordinates[0], ver4.coordinates[1]);

		sides = new double[4];
		sides[0] = Math.sqrt(Math.pow(ver2.coordinates[0] - ver1.coordinates[0], 2)
				+ Math.pow(ver2.coordinates[1] - ver1.coordinates[1], 2));
		sides[1] = Math.sqrt(Math.pow(ver3.coordinates[0] - ver2.coordinates[0], 2)
				+ Math.pow(ver3.coordinates[1] - ver2.coordinates[1], 2));
		sides[2] = Math.sqrt(Math.pow(ver4.coordinates[0] - ver3.coordinates[0], 2)
				+ Math.pow(ver4.coordinates[1] - ver3.coordinates[1], 2));
		sides[3] = Math.sqrt(Math.pow(ver1.coordinates[0] - ver4.coordinates[0], 2)
				+ Math.pow(ver1.coordinates[1] - ver4.coordinates[1], 2));
		;

		angles = new double[4];
		angles[0] = ang1;
		angles[1] = ang2;
		angles[2] = ang3;
		angles[3] = ang4;
	}

	@Override
	public double calculatePerimeter() {
		return sides[0] + sides[1] + sides[2] + sides[3];
	}

	@Override
	public double calculateSquare() {
		double p = calculatePerimeter() / 2;
		// S = √(p - a)(p - b)(p - c)(p - d) - abcd cos2θ
		double a = (angles[0] + angles[2]) / 2;
		return Math.sqrt(((p - sides[0]) * (p - sides[1]) * (p - sides[2]) * (p - sides[3])
				- sides[0] * sides[1] * sides[2] * sides[3] * Math.cos(a * 2)));
	}

	@Override
	public String toString() {
		return "" + calculatePerimeter() + " " + calculateSquare();
	}

}
