package project;

public class Circle extends GeometryShape {

	Circle() {
		vertices = new Point[1];
		vertices[0] = new Point();

		sides = new double[1];
		sides[0] = 1.0;

		angles = new double[1];
		angles[0] = 360.0;
	}
	
	Circle(Point centre){
		vertices = new Point[1];
		vertices[0] = new Point(centre.coordinates[0], centre.coordinates[1]);

		sides = new double[1];
		sides[0] = 1.0;

		angles = new double[1];
		angles[0] = 360.0;
	}
	
	Circle(double radius){
		vertices = new Point[1];
		vertices[0] = new Point();

		sides = new double[1];
		sides[0] = radius;

		angles = new double[1];
		angles[0] = 360.0;
	}
	
	Circle(Point centre, double radius){
		vertices = new Point[1];
		vertices[0] = new Point(centre.coordinates[0], centre.coordinates[1]); 

		sides = new double[1];
		sides[0] = radius;

		angles = new double[1];
		angles[0] = 360.0;
	}

	@Override
	public double calculatePerimeter() {

		return 2*Math.PI*sides[0];
	}

	@Override
	public double calculateSquare() {

		return Math.PI*Math.pow(sides[0], 2);
	}

	@Override
	public String toString() {
		
		return "" + calculatePerimeter() + " " + calculateSquare();
	}

}
