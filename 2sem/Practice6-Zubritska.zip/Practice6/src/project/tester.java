package project;

public class tester {

	public static void main(String[] args) {
		
		Circle c= new Circle();
		System.out.println(c.toString());
		
		Triangle t = new Triangle();
		System.out.println(t.toString());
		
		Quadrangle q = new Quadrangle();
		System.out.println(q.toString());
		
		Rectangle r = new Rectangle();
		System.out.println(r.toString());
	}

}
