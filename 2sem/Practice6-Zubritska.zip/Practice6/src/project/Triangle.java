package project;

public class Triangle extends GeometryShape {
	
	Triangle(){
		vertices = new Point[3];
		vertices[0] = new Point();
		vertices[1] = new Point(0, 1);
		vertices[2] = new Point(1, 0);

		sides = new double[3];
		sides[0] = 1.0;
		sides[1] = Math.sqrt(2.0);
		sides[2] = 1.0;

		angles = new double[3];
		angles[0] = 90.0;
		angles[1] = 45.0;
		angles[2] = 45.0;
	}
	
	Triangle(Point ver1, Point ver2, Point ver3){
		vertices = new Point[3];
		vertices[0] = new Point(ver1.coordinates[0], ver1.coordinates[1]);
		vertices[1] = new Point(ver2.coordinates[0], ver2.coordinates[1]);
		vertices[2] = new Point(ver3.coordinates[0], ver3.coordinates[1]);

		sides = new double[3];
		sides[0] = Math.sqrt(Math.pow(ver2.coordinates[0] - ver1.coordinates[0], 2)+Math.pow(ver2.coordinates[1] - ver1.coordinates[1], 2));
		sides[1] = Math.sqrt(Math.pow(ver3.coordinates[0] - ver2.coordinates[0], 2)+Math.pow(ver3.coordinates[1] - ver2.coordinates[1], 2));
		sides[2] = Math.sqrt(Math.pow(ver1.coordinates[0] - ver3.coordinates[0], 2)+Math.pow(ver1.coordinates[1] - ver3.coordinates[1], 2));

		angles = new double[3];
		angles[0] = (Math.pow(sides[0], 2) + Math.pow(sides[1], 2) - Math.pow(sides[3], 2))/(2*sides[0]*sides[1]);
		angles[1] = (Math.pow(sides[1], 2) + Math.pow(sides[2], 2) - Math.pow(sides[0], 2))/(2*sides[1]*sides[2]);
		angles[2] = 180.0 - angles[0] - angles[1];
	}
	

	@Override
	public double calculatePerimeter() {
		// TODO Auto-generated method stub
		return sides[0]+sides[1]+sides[2];
	}

	@Override
	public double calculateSquare() {
		// TODO Auto-generated method stub
		return (1/4)*Math.sqrt((sides[0]+sides[1]+sides[2])*(sides[1]+sides[2]-sides[0])*(sides[0]+sides[2]-sides[1])*(sides[0]+sides[1]-sides[2]));
	}

	@Override
	public String toString() {
		return "" + calculatePerimeter() + " " + calculateSquare();
	}
	
}
