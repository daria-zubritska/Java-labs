package project;

public abstract class GeometryShape {

	protected Point[] vertices;
	protected double[] sides;
	protected double[] angles;
	
	public abstract double calculatePerimeter();
	
	public abstract double calculateSquare();
	
	public abstract String toString();
}

class Point {
	public int[] coordinates;
	
	Point(){
		coordinates = new int[2];
		
		coordinates[0] = 0;
		coordinates[1] = 0;
	}
	
	Point(int x, int y){
		coordinates = new int[2];
		
		coordinates[0] = x;
		coordinates[1] = y;
	}
}
