package methods;

import java.io.FileNotFoundException;

public class tester {

	public static void main(String[] args) throws FileNotFoundException {

		new Group("k0");
		new Group("k1");
		new Group("k2");
		new Group("k3");
		
		new Good("k0", "g00", "product 0 in 0", "admin", 3, 50.22);
		new Good("k2", "g01", "product 1 in 0", "admin", 2, 2);
		new Good("k2", "g02", "product 2 in 0", "admin", 1, 10);

		Group.resetGroup("k2", "kEdit");
	}

}
