package methods;

/*Автоматизоване робоче місце.

Необхідно автоматизувати роботу невеликого підприємства по роботі з складом.

Існує декілька груп товарів (наприклад: Продовольчі, непродовольчі...). В кожній групі товарів існують конкретні товари (наприклад: борошно, гречка ...). У кожного товару є наступні властивості - назва, опис, виробник, кількість на складі, ціна за одиницю. Група товарів містить наступні властивості - назва, опис.

Реалізувати:

Реалізувати графічний інтерфейс користувача
Збереження даних в файл/файли. Один з варіантів: Існує файл в якому знаходяться назви всіх груп товарів. Товари з кожної групи товарів знаходяться в окремому файлі.
Назва товару - унікальна (не може зустрічатися більше в жодній групі товарів).
Назва групи товарів - унікальна.
Реалізувати додавання/редагування/видалення групи товарів - при видаленні групи товарів, видаляти і всі товари.
Реалізувати додавання/редагування/видалення товару в групу товарів (мається на увазі назва, опис, виробник, ціна за одиницю).
Реалізувати інтерфейс додавання товару (прийшло на склад крупи гречаної - 10 штук), інтерфейс списання товару (продали крупи гречаної - 5 шт.)
Пошук товару.
Вивід статистичних даних: вивід всіх товарів з інформацією по складу, вивід усіх товарів по групі товарів з інформацією, загальна вартість товару на складі (кількість * на ціну), загальна вартість товарів в групі товарів.
До роботи додати звіт про виконання роботи з описом розподілу ролей.

File: Store.java
Authors: Zubritska, Pihotskyi, Kyryniachenko*/

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.RowSpec;

public class Store extends JFrame {

	private JPanel contentPane;
	private JTextField searchTextField;
	private JPasswordField passwordField;
	private JButton enterButton;
	private JLabel statisticLabel;
	private JButton loginButton;
	private JLabel securityLabel;
	private JComboBox comboBox;

	/**
	 * Launch the application.
	 * 
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException {
		new Group("k0");
		new Group("k1");
		new Group("k2");
		new Group("k3");
		
		new Good("k0", "g00", "product 0 in 0", "admin", 3, 50.22);
		new Good("k2", "g01", "product 1 in 0", "admin", 2, 2);
		new Good("k2", "g02", "product 2 in 0", "admin", 1, 10);
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Store frame = new Store();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Store() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1600, 900);
		init();
	}

	private void init() {
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new FormLayout(
				new ColumnSpec[] { ColumnSpec.decode("max(119px;default)"), ColumnSpec.decode("139px"),
						ColumnSpec.decode("max(57dlu;default)"), ColumnSpec.decode("max(190dlu;default)"),
						ColumnSpec.decode("max(61dlu;default)"), ColumnSpec.decode("max(190dlu;default)"),
						ColumnSpec.decode("18px"), ColumnSpec.decode("max(57dlu;default)"),
						ColumnSpec.decode("max(53dlu;default)"), ColumnSpec.decode("max(116px;pref)"), },
				new RowSpec[] { RowSpec.decode("130px"), RowSpec.decode("125px"), RowSpec.decode("130px"),
						RowSpec.decode("50px"), RowSpec.decode("79px"), RowSpec.decode("69px"), RowSpec.decode("56px"),
						RowSpec.decode("50px"), RowSpec.decode("25px"), RowSpec.decode("50px"), }));

		JLabel welcomeLabel = new JLabel("Welcome to our store!");
		welcomeLabel.setFont(new Font("Dialog", Font.BOLD, 76));
		welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(welcomeLabel, "2, 2, 9, 1, fill, fill");

		JButton searchButton = new JButton("Search");
		searchButton.setToolTipText("Search the product you are looking for");
		searchButton.setFont(new Font("Dialog", Font.BOLD, 20));
		searchButton.setMnemonic('S');
		searchButton.setBackground(new Color(255, 255, 255));
		searchButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, Good.getGoodByName(searchTextField.getText()), "Product Search",
						JOptionPane.INFORMATION_MESSAGE);
			}
		});

		searchTextField = new JTextField();
		searchTextField.setToolTipText("Enter the name of the product you are looking for");
		contentPane.add(searchTextField, "2, 4, 8, 1, fill, fill");
		searchTextField.setColumns(10);
		contentPane.add(searchButton, "10, 4, fill, fill");

		JButton statisticButton = new JButton("Show statistics");
		statisticButton.setToolTipText("Displays storage statistics");
		statisticButton.setMnemonic('D');
		statisticButton.setFont(new Font("Dialog", Font.BOLD, 28));
		statisticButton.setBackground(new Color(255, 255, 255));
		statisticButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loginButton.setVisible(false);
				securityLabel.setVisible(false);
				passwordField.setVisible(false);
				enterButton.setVisible(true);
				statisticLabel.setVisible(true);
				comboBox.setVisible(true);
			}
		});
		contentPane.add(statisticButton, "4, 6, center, fill");

		JButton workButton = new JButton("Work with storage");
		workButton.setToolTipText("For wokers only! You must enter the special code to get access");
		workButton.setMnemonic('F');
		workButton.setBackground(new Color(255, 255, 255));
		workButton.setFont(new Font("Dialog", Font.BOLD, 28));
		workButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				enterButton.setVisible(false);
				statisticLabel.setVisible(false);
				comboBox.setVisible(false);
				loginButton.setVisible(true);
				securityLabel.setVisible(true);
				passwordField.setVisible(true);
			}
		});
		contentPane.add(workButton, "6, 6, center, fill");

		comboBox = new JComboBox();
		comboBox.setToolTipText("Choose type of statistics");
		comboBox.setVisible(false);
		comboBox.setForeground(new Color(102, 102, 102));
		comboBox.setFont(new Font("Dialog", Font.BOLD, 20));
		comboBox.setMaximumRowCount(4);
		comboBox.setModel(new DefaultComboBoxModel(new String[] { "Output of all products with information",
				"Output of all products by group of products with information", "The total cost of products in stock",
				"The total cost of products in the group of products" }));
		comboBox.setBackground(new Color(255, 255, 255));
		contentPane.add(comboBox, "3, 10, 5, 1, fill, fill");
		enterButton = new JButton("Enter");
		enterButton.setVisible(false);
		enterButton.setFont(new Font("Dialog", Font.BOLD, 20));
		enterButton.setBackground(new Color(255, 255, 255));
		enterButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (comboBox.getSelectedItem().equals("Output of all products with information")) {
					JFrame info = new JFrame("Info");
					JPanel infoPanel = new JPanel(new BorderLayout());
					JTextArea infotext = new JTextArea(Good.getAllInfo());
					if(Good.getAllInfo() == null) {
						JOptionPane.showMessageDialog(null, "No groups exist", "Error", JOptionPane.ERROR_MESSAGE);
						return;
					}
					info.add(infoPanel);
					infoPanel.add(new JScrollPane(infotext), new BorderLayout().CENTER);
					info.setVisible(true);
					info.pack();
				}
				if (comboBox.getSelectedItem().equals("Output of all products by group of products with information")) {
					JFrame info = new JFrame("Info");
					JPanel infoPanel = new JPanel(new BorderLayout());
					JTextField infoText = new JTextField();

					JButton group = new JButton("Enter");
					infoPanel.add(infoText, new BorderLayout().NORTH);
					info.add(infoPanel);
					group.addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							String nameG = infoText.getText();
							if(Good.getGroupInfo(nameG) == null) {
								JOptionPane.showMessageDialog(null, "No such group exist", "Error", JOptionPane.ERROR_MESSAGE);
								return;
							}
							JTextArea infotext = new JTextArea(Good.getGroupInfo(nameG));
							infoPanel.add(new JScrollPane(infotext), new BorderLayout().CENTER);
							info.add(infoPanel);
							info.pack();
						}

					});
					info.add(group, new BorderLayout().PAGE_START);
					info.setVisible(true);
					info.pack();
				}
				if (comboBox.getSelectedItem().equals("The total cost of products in stock")) {
					JFrame info = new JFrame("Info");
					JPanel infoPanel = new JPanel(new BorderLayout());
					JLabel infotext = new JLabel("Value of all products: " + String.valueOf(Good.getAllValue()));
					if(Good.getAllValue() == -1) {
						JOptionPane.showMessageDialog(null, "No groups exist", "Error", JOptionPane.ERROR_MESSAGE);
						return;
					}
					info.add(infoPanel);
					infoPanel.add(new JScrollPane(infotext), new BorderLayout().CENTER);
					info.setVisible(true);
					info.pack();
				}
				if (comboBox.getSelectedItem().equals("The total cost of products in the group of products")) {
					JFrame info = new JFrame("Info");
					JPanel infoPanel = new JPanel(new BorderLayout());
					JTextField infoText = new JTextField();

					JButton group = new JButton("Enter");
					infoPanel.add(infoText, new BorderLayout().NORTH);
					info.add(infoPanel);
					group.addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							String nameG = infoText.getText();
							if(Good.getGroupValue(nameG) == -1) {
								JOptionPane.showMessageDialog(null, "No such group exist", "Error", JOptionPane.ERROR_MESSAGE);
								return;
							}
							JLabel infotext = new JLabel(
									"Value of all products in group: " + String.valueOf(Good.getGroupValue(nameG)));
							infoPanel.add(new JScrollPane(infotext), new BorderLayout().CENTER);
							info.add(infoPanel);
							info.pack();
						}

					});
					info.add(group, new BorderLayout().PAGE_START);
					info.setVisible(true);
					info.pack();
				}
			}
		});
		contentPane.add(enterButton, "8, 10, fill, fill");
		statisticLabel = new JLabel("Choose type of statistics");
		statisticLabel.setVisible(false);
		statisticLabel.setFont(new Font("Dialog", Font.BOLD, 28));
		statisticLabel.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(statisticLabel, "3, 8, 6, 1, center, fill");
		securityLabel = new JLabel("Enter security code for working with storage");
		securityLabel.setVisible(false);
		securityLabel.setFont(new Font("Dialog", Font.BOLD, 28));
		securityLabel.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(securityLabel, "3, 8, 6, 1, center, fill");

		passwordField = new JPasswordField();
		passwordField.setVisible(false);
		contentPane.add(passwordField, "3, 10, 5, 1, fill, fill");

		loginButton = new JButton("Enter");
		loginButton.setVisible(false);
		loginButton.setFont(new Font("Dialog", Font.BOLD, 20));
		loginButton.setBackground(new Color(255, 255, 255));
		loginButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				char ch[] = passwordField.getPassword();
				String p = "";
				for (int i = 0; i < ch.length; i++) {
					p += ch[i];
				}

				if (p.equals("1111")) {
					EventQueue.invokeLater(new Runnable() {
						public void run() {
							try {
								WorkerMenu frame = new WorkerMenu();
								frame.setVisible(true);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					});
				} else {

					JOptionPane.showMessageDialog(null, "Wrong Code", "Error", JOptionPane.ERROR_MESSAGE);
				}

			}
		});
		contentPane.add(loginButton, "8, 10, fill, fill");
	}
}