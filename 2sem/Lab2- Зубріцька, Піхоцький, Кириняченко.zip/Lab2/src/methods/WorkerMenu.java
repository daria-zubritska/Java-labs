package methods;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.RowSpec;

public class WorkerMenu extends JFrame {
	private JTextField nameField;
	private JTextField newNameField;
	private JButton workWithGroupsButton;
	private JButton workWithGoodsButton;
	private JButton changeGoodsButton;
	private JLabel actLabel;
	private JComboBox goodsActComboBox;
	private JComboBox groupActComboBox;
	private JButton groupActChangingButton;
	private JButton goodsActChangingButton;
	private JLabel goodLabel;
	private JComboBox goodComboBox;
	private JButton goodChangingButton;
	private JLabel nameLabel;
	private JButton nameButton;
	private JLabel newNameLabel;
	private JButton newNameButton;
	int count = 1;
	int changeGoods = 0;
	String productName = "";
	String groupName = "";
	String description = "";
	String manufacturer = "";
	int amount = 0;
	double price = 0;

	/**
	 * Create the frame.
	 */
	public WorkerMenu() {
		getContentPane().setBackground(new Color(255, 255, 204));
		setBounds(100, 100, 1600, 900);
		getContentPane().setLayout(new FormLayout(
				new ColumnSpec[] { ColumnSpec.decode("131px"), ColumnSpec.decode("max(151dlu;default):grow"),
						ColumnSpec.decode("237px"), ColumnSpec.decode("106px"), ColumnSpec.decode("237px"),
						ColumnSpec.decode("102px"), ColumnSpec.decode("249px"), ColumnSpec.decode("max(42dlu;default)"),
						ColumnSpec.decode("119px"), ColumnSpec.decode("max(146dlu;default)"), },
				new RowSpec[] { RowSpec.decode("193px"), RowSpec.decode("50px"), RowSpec.decode("69px"),
						RowSpec.decode("50px"), RowSpec.decode("75px"), RowSpec.decode("50px"),
						RowSpec.decode("max(50dlu;default)"), RowSpec.decode("max(39dlu;default)"),
						RowSpec.decode("max(47dlu;default)"), RowSpec.decode("max(39dlu;default)"), }));

		workWithGroupsButton = new JButton("Work with groups");
		workWithGroupsButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				actLabel.setText("You are working with groups now. What do you want to do?");
				nameField.setVisible(false);
				newNameField.setVisible(false);
				actLabel.setVisible(true);
				goodsActChangingButton.setVisible(false);
				goodsActComboBox.setVisible(false);
				groupActComboBox.setVisible(true);
				groupActChangingButton.setVisible(true);
				goodLabel.setVisible(false);
				goodComboBox.setVisible(false);
				goodChangingButton.setVisible(false);
				nameLabel.setVisible(false);
				nameButton.setVisible(false);
				newNameLabel.setVisible(false);
				newNameButton.setVisible(false);
				changeGoods = 0;
			}
		});
		workWithGroupsButton.setBackground(new Color(255, 255, 255));
		workWithGroupsButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		getContentPane().add(workWithGroupsButton, "3, 2, fill, fill");

		workWithGoodsButton = new JButton("Work with products");
		workWithGoodsButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				actLabel.setText("You are working with goods now. What do you want to do?");
				nameField.setVisible(false);
				newNameField.setVisible(false);
				groupActChangingButton.setVisible(false);
				groupActComboBox.setVisible(false);
				actLabel.setVisible(true);
				goodsActComboBox.setVisible(true);
				goodsActChangingButton.setVisible(true);
				goodLabel.setVisible(false);
				goodComboBox.setVisible(false);
				goodChangingButton.setVisible(false);
				nameLabel.setVisible(false);
				nameButton.setVisible(false);
				newNameLabel.setVisible(false);
				newNameButton.setVisible(false);
				changeGoods = 0;
			}
		});
		workWithGoodsButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		workWithGoodsButton.setBackground(new Color(255, 255, 255));
		getContentPane().add(workWithGoodsButton, "5, 2, fill, fill");

		changeGoodsButton = new JButton("Change products quantity");
		changeGoodsButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				actLabel.setText("You are changing amount of products now");
				nameField.setVisible(true);
				newNameField.setVisible(true);
				groupActChangingButton.setVisible(false);
				groupActComboBox.setVisible(false);
				actLabel.setVisible(false);
				goodsActComboBox.setVisible(false);
				goodsActChangingButton.setVisible(false);
				goodLabel.setVisible(false);
				goodComboBox.setVisible(false);
				goodChangingButton.setVisible(false);
				nameLabel.setVisible(true);
				nameButton.setVisible(false);
				newNameLabel.setVisible(true);
				newNameButton.setVisible(true);
				nameLabel.setText("Enter name of the product");
				newNameLabel.setText("How its quantity has changed?");
				changeGoods = 1;
			}
		});
		changeGoodsButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		changeGoodsButton.setBackground(new Color(255, 255, 255));
		getContentPane().add(changeGoodsButton, "7, 2, fill, fill");

		actLabel = new JLabel("You are working with groups now. What do you want to do?");
		actLabel.setVisible(false);
		actLabel.setFont(new Font("Tahoma", Font.PLAIN, 28));
		actLabel.setHorizontalAlignment(SwingConstants.CENTER);
		getContentPane().add(actLabel, "2, 3, 8, 1");

		goodsActComboBox = new JComboBox();
		goodsActComboBox.setVisible(false);
		goodsActComboBox.setForeground(new Color(102, 102, 102));
		goodsActComboBox.setFont(new Font("Tahoma", Font.PLAIN, 20));
		goodsActComboBox.setModel(new DefaultComboBoxModel(new String[] { "add", "edit", "delete" }));
		goodsActComboBox.setMaximumRowCount(3);
		goodsActComboBox.setBackground(new Color(255, 255, 255));
		getContentPane().add(goodsActComboBox, "2, 4, 7, 1, fill, fill");

		groupActComboBox = new JComboBox();
		groupActComboBox.setVisible(false);
		groupActComboBox.setForeground(new Color(102, 102, 102));
		groupActComboBox.setFont(new Font("Tahoma", Font.PLAIN, 20));
		groupActComboBox.setModel(new DefaultComboBoxModel(new String[] { "add", "edit", "delete" }));
		groupActComboBox.setMaximumRowCount(3);
		groupActComboBox.setBackground(new Color(255, 255, 255));
		getContentPane().add(groupActComboBox, "2, 4, 7, 1, fill, fill");

		goodsActChangingButton = new JButton("Enter");
		goodsActChangingButton.setVisible(false);
		goodsActChangingButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (goodsActComboBox.getSelectedItem().equals("add")) {
					newNameLabel.setText("Enter name of the new good");
					nameField.setVisible(false);
					nameLabel.setVisible(false);
					nameButton.setVisible(false);
					newNameLabel.setVisible(true);
					newNameButton.setVisible(true);
					newNameField.setVisible(true);
				}
				if (goodsActComboBox.getSelectedItem().equals("edit")) {
					newNameLabel.setText("Enter new name of the group");
					nameField.setVisible(false);
					nameLabel.setVisible(false);
					nameButton.setVisible(false);
					newNameLabel.setVisible(false);
					newNameButton.setVisible(false);
					newNameField.setVisible(false);
					goodLabel.setVisible(true);
					goodComboBox.setVisible(true);
					goodChangingButton.setVisible(true);
				}
				if (goodsActComboBox.getSelectedItem().equals("delete")) {
					nameField.setVisible(true);
					nameLabel.setVisible(true);
					nameButton.setVisible(false);
					nameLabel.setText("Enter group name");
					newNameLabel.setText("Enter name of the product, that you want to delete");
					newNameLabel.setVisible(true);
					newNameButton.setVisible(true);
					newNameField.setVisible(true);
				}
			}
		});
		goodsActChangingButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		goodsActChangingButton.setBackground(new Color(255, 255, 255));
		getContentPane().add(goodsActChangingButton, "9, 4, fill, fill");
		groupActChangingButton = new JButton("Enter");
		groupActChangingButton.setVisible(false);
		groupActChangingButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (groupActComboBox.getSelectedItem().equals("add")) {
					newNameLabel.setText("Enter name of the new group");
					nameField.setVisible(false);
					nameLabel.setVisible(false);
					nameButton.setVisible(false);
					newNameLabel.setVisible(true);
					newNameButton.setVisible(true);
					newNameField.setVisible(true);
				}
				if (groupActComboBox.getSelectedItem().equals("edit")) {
					newNameLabel.setText("Enter name of the group, that you want to change");
					nameLabel.setVisible(true);
					nameButton.setVisible(false);
					newNameLabel.setVisible(true);
					newNameButton.setVisible(true);
					nameField.setVisible(true);
					newNameField.setVisible(true);
				}
				if (groupActComboBox.getSelectedItem().equals("delete")) {
					nameField.setVisible(false);
					nameLabel.setVisible(false);
					nameButton.setVisible(false);
					newNameLabel.setText("Enter name of the group, that you want to delete");
					newNameLabel.setVisible(true);
					newNameButton.setVisible(true);
					newNameField.setVisible(true);
				}
			}
		});
		groupActChangingButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		groupActChangingButton.setBackground(new Color(255, 255, 255));
		getContentPane().add(groupActChangingButton, "9, 4, fill, fill");

		goodLabel = new JLabel("What do you want to change?");
		goodLabel.setVisible(false);
		goodLabel.setFont(new Font("Tahoma", Font.PLAIN, 28));
		goodLabel.setHorizontalAlignment(SwingConstants.CENTER);
		getContentPane().add(goodLabel, "2, 5, 8, 1");

		goodComboBox = new JComboBox();
		goodComboBox.setVisible(false);
		goodComboBox.setForeground(new Color(102, 102, 102));
		goodComboBox.setModel(new DefaultComboBoxModel(
				new String[] { "product name", "group", "description", "manufacturer", "amount", "unit price" }));
		goodComboBox.setBackground(new Color(255, 255, 255));
		goodComboBox.setFont(new Font("Tahoma", Font.PLAIN, 20));
		getContentPane().add(goodComboBox, "2, 6, 7, 1, fill, fill");

		goodChangingButton = new JButton("Enter");
		goodChangingButton.setVisible(false);
		goodChangingButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				nameLabel.setVisible(true);
				nameButton.setVisible(true);
				newNameLabel.setVisible(true);
				newNameButton.setVisible(true);
				nameField.setVisible(true);
				newNameField.setVisible(true);
				if (goodComboBox.getSelectedItem().equals("product name")) {
					nameLabel.setText("Enter name of the product, that you want to change");
					nameLabel.setVisible(true);
					nameButton.setVisible(false);
					newNameLabel.setVisible(true);
					newNameLabel.setText("Enter new product name");
					newNameButton.setVisible(true);
					nameField.setVisible(true);
					newNameField.setVisible(true);
				}
				if (goodComboBox.getSelectedItem().equals("group")) {
					nameLabel.setText("Enter name of the product, that you want to change");
					nameLabel.setVisible(true);
					nameButton.setVisible(false);
					newNameLabel.setVisible(true);
					newNameLabel.setText("Enter new product group");
					newNameButton.setVisible(true);
					nameField.setVisible(true);
					newNameField.setVisible(true);
				}
				if (goodComboBox.getSelectedItem().equals("description")) {
					nameLabel.setText("Enter name of the product, that you want to change");
					nameLabel.setVisible(true);
					nameButton.setVisible(false);
					newNameLabel.setVisible(true);
					newNameLabel.setText("Enter new product description");
					newNameButton.setVisible(true);
					nameField.setVisible(true);
					newNameField.setVisible(true);
				}
				if (goodComboBox.getSelectedItem().equals("manufacturer")) {
					nameLabel.setText("Enter name of the product, that you want to change");
					nameLabel.setVisible(true);
					nameButton.setVisible(false);
					newNameLabel.setVisible(true);
					newNameLabel.setText("Enter new product manufacturer");
					newNameButton.setVisible(true);
					nameField.setVisible(true);
					newNameField.setVisible(true);
				}
				if (goodComboBox.getSelectedItem().equals("amount")) {
					nameLabel.setText("Enter name of the product, that you want to change");
					nameLabel.setVisible(true);
					nameButton.setVisible(false);
					newNameLabel.setVisible(true);
					newNameLabel.setText("Enter new product amount");
					newNameButton.setVisible(true);
					nameField.setVisible(true);
					newNameField.setVisible(true);
				}
				if (goodComboBox.getSelectedItem().equals("unit price")) {
					nameLabel.setText("Enter name of the product, that you want to change");
					nameLabel.setVisible(true);
					nameButton.setVisible(false);
					newNameLabel.setVisible(true);
					newNameLabel.setText("Enter new product unit price");
					newNameButton.setVisible(true);
					nameField.setVisible(true);
					newNameField.setVisible(true);
				}
			}
		});
		goodChangingButton.setBackground(new Color(255, 255, 255));
		goodChangingButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		getContentPane().add(goodChangingButton, "9, 6, fill, fill");

		nameLabel = new JLabel("Enter old name of the group");
		nameLabel.setVisible(false);
		nameLabel.setFont(new Font("Tahoma", Font.PLAIN, 28));
		nameLabel.setHorizontalAlignment(SwingConstants.CENTER);
		getContentPane().add(nameLabel, "2, 7, 8, 1");

		nameField = new JTextField();
		nameField.setVisible(false);
		nameField.setFont(new Font("Tahoma", Font.PLAIN, 20));
		getContentPane().add(nameField, "2, 8, 7, 1, fill, fill");
		nameField.setColumns(10);

		nameButton = new JButton("Enter");
		nameButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (groupActComboBox.getSelectedItem().equals("edit") && groupActComboBox.isVisible()) {
					try {
						Good.resetGroup(nameField.getText(), newNameField.getText());
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					}
				}
			}
		});
		nameButton.setVisible(false);
		nameButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		nameButton.setBackground(new Color(255, 255, 255));
		getContentPane().add(nameButton, "9, 8, fill, fill");

		newNameLabel = new JLabel("Enter new name of the group");
		newNameLabel.setVisible(false);
		newNameLabel.setFont(new Font("Tahoma", Font.PLAIN, 28));
		newNameLabel.setHorizontalAlignment(SwingConstants.CENTER);
		getContentPane().add(newNameLabel, "2, 9, 8, 1");

		newNameField = new JTextField();
		newNameField.setVisible(false);
		newNameField.setFont(new Font("Tahoma", Font.PLAIN, 20));
		getContentPane().add(newNameField, "2, 10, 7, 1, fill, fill");
		newNameField.setColumns(10);

		newNameButton = new JButton("Enter");
		newNameButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (groupActComboBox.getSelectedItem().equals("add") && groupActComboBox.isVisible()) {
					try {
						new Group(newNameField.getText());
						JOptionPane.showMessageDialog(null, "New group was successfully added", "Success",
								JOptionPane.INFORMATION_MESSAGE);
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					}
				}
				if (groupActComboBox.getSelectedItem().equals("delete") && groupActComboBox.isVisible()) {
					Group.removeGroup(newNameField.getText());
					JOptionPane.showMessageDialog(null, "Group was successfully deleted", "Success",
							JOptionPane.INFORMATION_MESSAGE);
				}
				if (groupActComboBox.getSelectedItem().equals("edit") && groupActComboBox.isVisible()) {
					try {
						Good.resetGroup(nameField.getText(), newNameField.getText());
						JOptionPane.showMessageDialog(null, "Group was successfully edited", "Success",
								JOptionPane.INFORMATION_MESSAGE);
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					}
				}
				if (goodsActComboBox.getSelectedItem().equals("add") && goodsActComboBox.isVisible()) {
					
					switch (count) {
					case 1:
						productName = newNameField.getText();
						newNameLabel.setText("Enter group of the new product");
						count++;
						break;
					case 2:
						groupName = newNameField.getText();
						newNameLabel.setText("Enter description of the new product");
						count++;
						break;
					case 3:
						description = newNameField.getText();
						newNameLabel.setText("Enter manufacturer of the new product");
						count++;
						break;
					case 4:
						manufacturer = newNameField.getText();
						newNameLabel.setText("Enter amount of the new product");
						count++;
						break;
					case 5:
						amount = 1;
						try {
							amount = Integer.parseInt(newNameField.getText());
						} catch (NumberFormatException e) {
							amount = 0;
						}
						newNameLabel.setText("Enter price of the new product");
						count++;
						break;
					case 6:
						price = 1;
						try {
							price = Integer.parseInt(newNameField.getText());
						} catch (NumberFormatException e) {
							price = 0;
						}
						
						count = 1;
						try {
							new Good(groupName, productName, description, manufacturer, amount, price);
							JOptionPane.showMessageDialog(null, "New product was successfully added", "Success",
									JOptionPane.INFORMATION_MESSAGE);
							
						} catch (FileNotFoundException e) {
							e.printStackTrace();
						}
						
						break;
					}
				}
				if (goodComboBox.getSelectedItem().equals("product name")
						&& goodsActComboBox.getSelectedItem().equals("edit") && goodsActComboBox.isVisible()) {
					Good g = Good.getGoodByName(nameField.getText());
					try {
						Good.reSet(g.getName(), nameField.getText(), g.getName(), newNameField.getText(), g.getDescription(), g.getProducer(), g.getAmount(), g.getValue());
						JOptionPane.showMessageDialog(null, "Product name was successfully changed", "Success",
								JOptionPane.INFORMATION_MESSAGE);
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if (goodComboBox.getSelectedItem().equals("group") && goodsActComboBox.getSelectedItem().equals("edit")
						&& goodsActComboBox.isVisible()) {
					Good g = Good.getGoodByName(nameField.getText());
					try {
						Good.reSet(g.getName(), nameField.getText(), newNameField.getText(), g.getNameG(), g.getDescription(), g.getProducer(), g.getAmount(), g.getValue());
						JOptionPane.showMessageDialog(null, "Product was successfully moved", "Success",
								JOptionPane.INFORMATION_MESSAGE);
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if (goodComboBox.getSelectedItem().equals("description")
						&& goodsActComboBox.getSelectedItem().equals("edit") && goodsActComboBox.isVisible()) {
					Good g = Good.getGoodByName(nameField.getText());
					try {
						Good.reSet(g.getName(), g.getNameG(), g.getName(), g.getNameG(), newNameField.getText(), g.getProducer(), g.getAmount(), g.getValue());
						JOptionPane.showMessageDialog(null, "Product`s description was successfully changed", "Success",
								JOptionPane.INFORMATION_MESSAGE);
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if (goodComboBox.getSelectedItem().equals("manufacturer")
						&& goodsActComboBox.getSelectedItem().equals("edit") && goodsActComboBox.isVisible()) {
					Good g = Good.getGoodByName(nameField.getText());
					try {
						Good.reSet(g.getName(), nameField.getText(), g.getName(), g.getNameG(), g.getDescription(), newNameField.getText(), g.getAmount(), g.getValue());
						JOptionPane.showMessageDialog(null, "Product`s manufacturer was successfully changed", "Success",
								JOptionPane.INFORMATION_MESSAGE);
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if (goodComboBox.getSelectedItem().equals("amount") && goodsActComboBox.getSelectedItem().equals("edit")
						&& goodsActComboBox.isVisible()) {
					Good g = Good.getGoodByName(nameField.getText());
					try {
						Good.reSet(g.getName(), nameField.getText(), g.getName(), g.getNameG(), g.getDescription(), g.getProducer(), Integer.parseInt(newNameField.getText()), g.getValue());
						JOptionPane.showMessageDialog(null, "Product`s amount was successfully changed", "Success",
								JOptionPane.INFORMATION_MESSAGE);
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if (goodComboBox.getSelectedItem().equals("unit price")
						&& goodsActComboBox.getSelectedItem().equals("edit") && goodsActComboBox.isVisible()) {
					Good g = Good.getGoodByName(nameField.getText());
					try {
						Good.reSet(g.getName(), nameField.getText(), g.getName(), g.getNameG(), g.getDescription(), g.getProducer(), g.getAmount(), Double.parseDouble(newNameField.getText()));
						JOptionPane.showMessageDialog(null, "Product`s unit price was successfully changed", "Success",
								JOptionPane.INFORMATION_MESSAGE);
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if (goodsActComboBox.getSelectedItem().equals("delete") && goodsActComboBox.isVisible()) {
					Good.remove(nameField.getText(), newNameField.getText());
					JOptionPane.showMessageDialog(null, "Product was successfully deleted", "Success",
							JOptionPane.INFORMATION_MESSAGE);
				}
				if (changeGoods == 1) {
					Good.changeGoodAmount(nameField.getText(), Integer.parseInt(newNameField.getText()));
					JOptionPane.showMessageDialog(null, "Amount of product was successfully changed", "Success",
							JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		newNameButton.setVisible(false);
		newNameButton.setBackground(new Color(255, 255, 255));
		newNameButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		getContentPane().add(newNameButton, "9, 10, fill, fill");
	}

}