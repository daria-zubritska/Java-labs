package methods;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Good extends Group {
	String nameG;
	String description;
	String producer;
	int amount;
	double value;
	static int amountOfGood;

	Good(String name, String nameG, String description, String producer, int amount, double value)
			throws FileNotFoundException {
		super(name);
		if(amountOfGroups == 0) return;
		for (ArrayList<Good> entry : group.values()) {
			for (int i = 0; i < entry.size(); i++) {
				if (!Group.group.containsKey(name) || entry.get(i).getNameG().indexOf(nameG) != -1)
					return;
			}
		}
		if (Group.group.containsKey(name) == false)
			return;
		else
			amountOfGood++;
			Group.group.get(name).add(this);
		this.nameG = nameG;
		this.description = description;
		this.producer = producer;
		if(amount >= 0) this.amount = amount;
		else this.amount = 0;
		
		this.value = value;
		String[] a = new String[amountOfGood];
		int i = 0;
		for (Good entry : group.get(name)) {
			a[i] = entry.toString();
			i++;
		}
		try (FileWriter writer = new FileWriter(name + ".txt", false)) {
			for (String aa : a) {
				if (aa == null)
					continue;
				String text = aa;
				writer.write(text);
				writer.write("\n");
			}
			writer.flush();
		} catch (IOException ex) {

			System.out.println(ex.getMessage());
		}

	}

	public static void reSet(String name, String nameG, String nameToReset, String nameGToReset, String description,
			String producer, int amount, double value) throws FileNotFoundException {
		if(amountOfGroups == 0) return;
		if(amountOfGood == 0) return;
		remove(name, nameG);
		Good g = new Good(nameToReset, nameGToReset, description, producer, amount, value);
		amountOfGood++;
		
		String[] a = new String[amountOfGood];
		int i = 0;
		for (Good entry : group.get(name)) {
			a[i] = entry.toString();
			i++;
		}
		try (FileWriter writer = new FileWriter(name + ".txt", false)) {
			for (String aa : a) {
				if (aa == null)
					continue;
				String text = aa;
				writer.write(text);
				writer.write("\n");
			}
			writer.flush();
		} catch (IOException ex) {

			System.out.println(ex.getMessage());
		}
	}

	public static void remove(String name, String nameG) {
		if(amountOfGroups == 0) return;
		if(amountOfGood == 0) return;
		if(name == null) System.out.print("ouch");
		for (ArrayList<Good> entry : group.values()) {
			for (int i = 0; i < entry.size(); i++) {
				if (entry.get(i).getNameG().compareToIgnoreCase(nameG) == 0)
					entry.remove(i);

			}
		}
		String[] a = new String[amountOfGood];
		int i = 0;
		if(group.get(name) == null) {
			amountOfGood--;
			return;
		}
		for (Good entry : group.get(name)) {
			
			a[i] = entry.toString();
			i++;
		}
		try (FileWriter writer = new FileWriter(name + ".txt", false)) {
			for (String aa : a) {
				if (aa == null)
					continue;
				String text = aa;
				writer.write(text);
				writer.write("\n");
			}
			writer.flush();
		} catch (IOException ex) {

			System.out.println(ex.getMessage());
		}
		amountOfGood--;
	}

	public String getNameG() {
		return nameG;
	}

	public void setNameG(String nameG) {
		this.nameG = nameG;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getProducer() {
		return producer;
	}

	public void setProducer(String producer) {
		this.producer = producer;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}
	
	public String getName() {
		for (String entry : group.keySet()) {
			for (int i = 0; i< group.get(entry).size(); i++) {
				if (group.get(entry).get(i).getNameG().compareToIgnoreCase(nameG) == 0) {
					return entry;
				}
			}
		}
		return null;
	}

	public static Good getGoodByName(String nameG) {
		if(amountOfGroups == 0) return null;
		if(amountOfGood == 0) return null;
		for (ArrayList<Good> entry : group.values()) {
			for (Good g : entry) {
				if (g.getNameG().compareToIgnoreCase(nameG) == 0) {
					return g;
				}
			}
		}
		return null;
	}

	public static void changeGoodAmount(String nameG, int changeHow) {
		if(amountOfGroups == 0) return;
		if(amountOfGood == 0) return;
		String name = "";
		for (ArrayList<Good> entry : group.values()) {
			for (Good g : entry) {
				if (g.getNameG().compareToIgnoreCase(nameG) == 0) {
					int newAmount = g.getAmount();
					newAmount += changeHow;
					if (newAmount >= 0) {
						g.setAmount(newAmount);
						name = g.getName();
					} else {
						g.setAmount(0);
						name = g.getName();
					}
				}
			}
		}
		String[] a = new String[amountOfGood];
		int i = 0;
		for (Good entry : group.get(name)) {
			a[i] = entry.toString();
			i++;
		}
		try (FileWriter writer = new FileWriter(name + ".txt", false)) {
			for (String aa : a) {
				if (aa == null)
					continue;
				String text = aa;
				writer.write(text);
				writer.write("\n");
			}
			writer.flush();
		} catch (IOException ex) {

			System.out.println(ex.getMessage());
		}
	}

	public static String getAllInfo() {
		if(amountOfGroups == 0) return null;
		if(amountOfGood == 0) return null;
		
		String str = "";
		if(group == null) return null;
		for (ArrayList<Good> entry : group.values()) {
			for (Good g : entry) {
				str += g.toString() + "\n";
			}
		}
		return str;
	}

	public static String getGroupInfo(String nameG) {
		if(amountOfGroups == 0) return null;
		if(amountOfGood == 0) return null;
		

		String str = "";
		if(group.get(nameG) == null) return null;
		for (Good g : group.get(nameG)) {
			str += g.toString() + "\n";
		}
		
		return str;
	}
	
	public static double getAllValue() {
		if(amountOfGroups == 0) return -1;
		if(amountOfGood == 0) return -1;
		double info = 0;
		
		if(group == null) return -1;
		for (ArrayList<Good> entry : group.values()) {
			for (Good g : entry) {
				info += g.getValue()*g.getAmount();
			}
		}
		return info;
	}
	
	public static double getGroupValue(String nameG) {
		if(amountOfGroups == 0) return -1;
		if(amountOfGood == 0) return -1;
		double info = 0;

		if(group.get(nameG) == null) return -1;
		for (Good g : group.get(nameG)) {
			info += g.getValue()*g.getAmount();
		}
		return info;
	}

	@Override
	public String toString() {
		return "Product name: " + nameG + "; Description: " + description + "; Manufacturer: " + producer + "; Amount: " + amount
				+ "; Unit price: " + value + ";";
	}

}