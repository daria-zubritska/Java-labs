package methods;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class Group {
	String name;
	static int amountOfGroups;
	ArrayList array = new ArrayList<Good>();
	static public HashMap<String, ArrayList<Good>> group = new HashMap<>();

	Group(String name) throws FileNotFoundException {

		if (!Group.group.containsKey(name)) {
			amountOfGroups++;
			this.name = name;
			this.array = new ArrayList<>();
			group.put(name, this.array);
			String[] a = new String[amountOfGroups];
			int i = 0;
			for (String entry : group.keySet()) {
				a[i] = entry;
				i++;
			}
			try (FileWriter writer = new FileWriter("Groups.txt", false)) {
				for (String aa : a) {
					if (aa == null)
						continue;
					String text = aa;
					writer.write(text);
					writer.write("\n");
				}
				writer.flush();
			} catch (IOException ex) {

				System.out.println(ex.getMessage());
			}
		} else
			return;

	}

	public static void resetGroup(String nameToReset, String name) throws FileNotFoundException {
		if(amountOfGroups==0) return;
		if (!group.containsKey(name) && group.containsKey(nameToReset)) {
			Group g = new Group(name);
			group.get(name).addAll(group.get(nameToReset));
			
				for (int i = 0; i < group.get(nameToReset).size(); i++) {
					Good g1 = group.get(nameToReset).get(i);
						Good.reSet(nameToReset, g1.getNameG(), name, g1.getNameG(), g1.getDescription(), g1.getProducer(), g1.getAmount(), g1.getValue());
				}

			removeGroup(nameToReset);
			amountOfGroups++;
			
			String[] a = new String[amountOfGroups];
			int i = 0;
			for (String entry : group.keySet()) {
				a[i] = entry;
				i++;
			}
			
			try (FileWriter writer = new FileWriter("Groups.txt", false)) {
				for (String aa : a) {
					if (aa == null)
						continue;
					String text = aa;
					writer.write(text);
					writer.write("\n");
				}
				writer.flush();
			} catch (IOException ex) {

				System.out.println(ex.getMessage());
			}
			
			
		}
	}

	public static void removeGroup(String name) {
		if (amountOfGroups == 0)
			return;
		if (group.containsKey(name)) {
			group.get(name).clear();
			group.remove(name);
			amountOfGroups--;
			String[] a = new String[amountOfGroups];
			int i = 0;
			for (String entry : group.keySet()) {
				a[i] = entry;
				i++;
			}

			try (FileWriter writer = new FileWriter("Groups.txt", false)) {
				for (String aa : a) {
					if (aa == null)
						continue;
					String text = aa;
					writer.write(text);
					writer.write("\n");
				}
				writer.flush();
			} catch (IOException ex) {

				System.out.println(ex.getMessage());
			}
		} else
			return;

	}

	public ArrayList<Good> getArray() {
		return array;
	}

	public void setArray(ArrayList array) {
		this.array = array;
	}

	@Override
	public String toString() {
		return "Group [name=" + name + ", array=" + array + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static int getAmountOfGroups() {
		return amountOfGroups;
	}

	public static void setAmountOfGroups(int amountOfGroups) {
		Group.amountOfGroups = amountOfGroups;
	}

	public static HashMap<String, ArrayList<Good>> getGroup() {
		return group;
	}

	public static void setGroup(HashMap<String, ArrayList<Good>> group) {
		Group.group = group;
	}
}