
/*
 * Написати клас StudentsGrades, що містить приватний масив цілих чисел,
 *  в якому зберігаються оцінки групи студентів (оцінки можуть мати значення від 0 до 100).
 *   Клас повинен містити публічні методи для зчитування масиву (getter),
 *    присвоєння йому значення іншого масиву (setter) та додавання даних до нього (adder),
 *     а також методи, які повертають такі статистичні дані:

1) максимальна оцінка в групі
2) мінімальна оцінка в групі
3) середній бал групи
4) кількість студентів в яких бал вищий за середній
5) кількість студентів в яких бал нижчий за середній
6) кількість студентів з відмінною оцінкою
7) кількість студентів з оцінкою "добре"
8) кількість студентів з оцінкою "задовільно"
9) кількість студентів з оцінкою "не задовільно"
10) вивести всі оцінки (метод toString())

Оцінки задаються від 0 до 100. "0-59" - незадовільно, "60-70" - задовільно, "71-90" - добре, "91-100" - відмінно.

Написати клас-тестер із функцією main, в ході якої створюється об'єкт класу StudentsGrades, 
зчитуються з клавіатури оцінки студентів та друкуються усі вищеперераховані статистичні дані.
 * File: StudentsGrades.java
 * Author: Zubritska
 * */

public class StudentsGrades {
	
	private double[] grades;
	
	private int num = 0;
	
	/***
	 * Створює новий массив з оцінками
	 * 
	 * @param gradesLimit - максимальна кількість оцінок у массиві
	 */
	StudentsGrades(int gradesLimit){
		grades = new double[gradesLimit];
	}
	
	/***
	 * Заміняє массив массивом користувача
	 * 
	 * @param gradesArray - массив користувача
	 */
	public void setGrades(double[] gradesArray) {
		this.grades = gradesArray;
		num = gradesArray.length;
	}
	
	/***
	 * Повертає массив оцінок
	 */
	public double[] getGrades() {
		return grades;
	}
	
	/***
	 * Повертає 1, якщо оцінка успішно додана, 0 - закінчився массив, -1 - некоректна оцінка
	 * 
	 * @param grade - оцінка, яку потрібно додати до массиву
	 */
	public int TryAdd(double grade) {
		
		if(grade < 0||grade>100){
			return -1;
		}
		else if(num < grades.length) {
			grades[num] = grade;
			num++;
		
			return 1;
		}
		
		return 0;
	}
	
	/***
	 * Повертає максимальне значення з масиву оцінок
	 */
	public double max() {
		
		double max=0;
		
		for(int i=0; i<num; i++) {
			if(this.grades[i]>max) max = grades[i];
		}
		
		return max;
	}
	
	/***
	 * Повертає мінімальне значення з масиву оцінок
	 */
	public double min() {
		
		double min=100;
		
		for(int i=0; i<num; i++) {
			if(grades[i]<min) min = grades[i];
		}
		
		return min;
	}
	
	/***
	 * Повертає середній бал
	 */
	public double averageGrade() {
		double average=0;
		
		double sum=0;
		for(int i=0; i<num;i++) {
			sum = sum + grades[i];
		}
		
		average = sum/num;
		
		return average;
	}
	
	/***
	 * Повертає кількість оцінок вищих за середню
	 */
	public int higherThanAverage() {
		
		int numHigh = 0;
		for(int i=0; i<num; i++) {
			if(grades[i]>averageGrade()) {
				numHigh++;
			}
		}
		
		return numHigh;
	}
	
	/***
	 * Повертає кількість оцінок нижчих за середню
	 */
	public int lowerThanAverage() {
		
		int numLow = 0;
		for(int i=0; i<num; i++) {
			if(grades[i]<averageGrade()) {
				numLow++;
			}
		}
		
		return numLow;
	}
	
	/***
	 * Повертає кількість оцінок 91-100
	 */
	public int exelentGrades() {
		
		int numEx = 0;
		for(int i=0; i<num; i++) {
			if(grades[i]>=91) {
				numEx++;
			}
		}
		
		return numEx;
	}
	
	/***
	 * Повертає массив оцінок 71-90
	 */
	public int goodGrades() {
		
		int numEx = 0;
		for(int i=0; i<num; i++) {
			if(grades[i]>=71 && grades[i]<=90) {
				numEx++;
			}
		}
		
		return numEx;
	}
	
	/***
	 * Повертає кількість оцінок 60-70
	 */
	public int enoughGrades() {
		
		int numEx = 0;
		for(int i=0; i<num; i++) {
			if(grades[i]>=60 && grades[i]<=70) {
				numEx++;
			}
		}
		
		return numEx;
	}
	
	/***
	 * Повертає кількість оцінок 0-59
	 */
	public int notEnoughGrades() {
		
		int numEx = 0;
		for(int i=0; i<num; i++) {
			if(grades[i]>=0 && grades[i]<=59) {
				numEx++;
			}
		}
		
		return numEx;
	}
	
	/***
	 * Повертає String масиву оцінок
	 */
	public String ToString() {
		
		String gradesStr = "";
		
		for(int i=0; i<num; i++) {
			gradesStr = gradesStr + grades[i] + "\n";
		}
		
		return gradesStr;
	}
}

