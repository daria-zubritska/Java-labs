import java.awt.BorderLayout;
import java.io.File;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;


public class TreeApp extends JFrame{
    private JTree diskCh;
    private JLabel selectedLabel;
    DefaultMutableTreeNode disk;
    
    TreeApp() throws IOException{
    	super("Disk selection");
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	
    	DefaultMutableTreeNode root = new DefaultMutableTreeNode("Root");
    	
    	File[] disks = File.listRoots();
    	
    	for(int i = 0; i<disks.length; i++) {
    		
    		disk = new DefaultMutableTreeNode(disks[i]);
    		root.add(disk);
    		
    		File[] file = disks[i].listFiles();
    		if(file == null) continue;
    		for(int j = 0; j<file.length; j++) {
    			DefaultMutableTreeNode fileNode = new DefaultMutableTreeNode(file[j]);
    			disk.add(fileNode);
    			
    			File[] moreFiles = file[j].listFiles();
    			if(moreFiles == null) continue;
    			for(int k = 0; k<moreFiles.length; k++) {
    				DefaultMutableTreeNode fileNode1 = new DefaultMutableTreeNode(moreFiles[k]);
        			fileNode.add(fileNode1);
    			}
    		}
    	
    	}

        diskCh = new JTree(root);
        add(diskCh);
        add(new JScrollPane(diskCh));
        diskCh.setRootVisible(false);
        diskCh.setShowsRootHandles(true);
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("JTree App");        
        this.pack();
        this.setVisible(true);
        
        selectedLabel = new JLabel();

        add(selectedLabel, BorderLayout.SOUTH);
        
        diskCh.getSelectionModel().addTreeSelectionListener(new TreeSelectionListener() {
            @Override
            public void valueChanged(TreeSelectionEvent e) {
                selectedLabel.setText(e.getPath().toString());
            }
        });
        
    }
           
}