import java.io.IOException;

import javax.swing.SwingUtilities;

/*Написати графічну програму, що показує файлову систему у вигляді дерева і дозволяє по ній переміщуватися, розкриваючи та закриваючи підкаталоги
 * 
 * File: TreeTester.java
 * Author: Zubritska*/

public class TreeTester {

	public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
					new TreeApp();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        });

	}

}
