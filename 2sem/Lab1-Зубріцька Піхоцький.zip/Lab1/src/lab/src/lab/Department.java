package lab.src.lab;

public class Department extends Faculty {
	String nameD;
	static int counterD;
	int indexD;
	Student[] students;
	Educator[] educators;
	int amountOfStudents;
	int amountOfEducators;

	public Department(String nameF, String nameD, int i) {
		super(nameF);
		this.nameD = nameD;
		if (fac[i] == null) {
			System.out.println("Sorry, you must creat a faculty at first!");
			return;
		}
		this.indexD = getFac(i).amountOfDep;
		this.students = new Student[10];
		this.educators = new Educator[10];
		this.amountOfStudents = 0;
		this.amountOfEducators = 0;
	}

	public Department() {
		//порожній конструктор для виклика методів у коді
	}

	public void addDepartemnt(String nameD, int i) {
		Department depart = new Department(fac[i].getNameF(), nameD, i);

		if (fac[i].dep.length > fac[i].amountOfDep)
			fac[i].dep[fac[i].amountOfDep] = depart;
		else {
			Student temp[] = new Student[fac[i].amountOfDep + 10];
			temp = students;
			for (int k = 0; k < dep.length; k++)
				temp[k] = students[k];
			fac[i].dep = temp;
		}
		counterD++;
		fac[i].amountOfDep++;
	}

	public void reSet(int i, int j, int facTochange, String nameD) {

		if (fac[facTochange] == null)
			return;
		else if (fac[i].dep[j] == fac[facTochange].dep[j]) {
			fac[i].dep[j] = new Department(fac[i].getNameF(), nameD, i);
		} else {
			delete(i, j);
			fac[facTochange].dep[getCounter(facTochange)] = new Department(fac[facTochange].getNameF(), nameD, i);
			fac[facTochange].amountOfDep++;
			counterD++;
		}
	}

	public void delete(int i, int j) {
		fac[i].dep[j] = null;

		fac[i].dep[j] = fac[i].dep[getCounter(i)];
		fac[i].amountOfDep--;
		counterD--;
	}

	public Department getDepartment(int i, int j) {
		return fac[i].dep[j];
	}

	public String getNameD() {
		return nameD;
	}

	public void setNameD(String nameD) {
		this.nameD = nameD;
	}

	public int getCounter(int i) {
		return fac[i].amountOfDep;
	}

}
