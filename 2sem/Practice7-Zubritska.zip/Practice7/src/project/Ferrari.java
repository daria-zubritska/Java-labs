package project;

public class Ferrari extends SportCar {
	
	Ferrari(String color){
		setColor(color);
		this.maxSpeed = 120;
	}
	
	public void setColor(String color) {
		this.carColor = color;
	}
	
	public String toString() {
		String str = "";
		
		str = this.carColor + " " + "Ferrari ";
		
		if(isFull) {
			str += "заправлена і готова для поїздки. Її максимальна швидкість " + this.maxSpeed;
		}
		else {
			str += "стоїть з порожнім баком.";
		}
		
		return str;
	}

}
