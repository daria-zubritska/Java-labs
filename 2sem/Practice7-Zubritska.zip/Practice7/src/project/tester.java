package project;

public class tester {
	
	public static void main(String[] arg) {
		Ferrari f = new Ferrari("Червона");
		f.fuelCar();
		System.out.println(f.getMaxSpeed());
		System.out.println(f.toString());
		
		Porsche p = new Porsche("Синя");
		System.out.println(p.getMaxSpeed());
		System.out.println(p.toString());
		p.fuelCar();
		System.out.println(p.toString());
		
		Truck t1 = new Truck("Білий");
		t1.fuelCar();
		System.out.println(t1.getMaxWeight());
		System.out.println(t1.toString());
		t1.loadPackages(20);
		System.out.println(t1.toString());
		
		MiniVan m = new MiniVan("Сірий");
		System.out.println(m.getMaxWeight());
		System.out.println(m.toString());
		m.fuelCar();
		System.out.println(m.toString());
	}

}
