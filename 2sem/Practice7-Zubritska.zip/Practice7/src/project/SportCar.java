package project;

public abstract class SportCar implements Car {
	
	public String carColor;
	public int maxSpeed;
	public boolean isFull = false;
	
	public void setColor(String color) {}
	
	public void fuelCar() {
		if(!isFull)
			this.isFull = true;
	}
	
	public int getMaxSpeed() {
		return this.maxSpeed;
	}
	
	public String toString() {
		String str = "";
		
		return str;
	}
}
