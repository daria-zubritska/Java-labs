
public class Error extends Exception {
	
	Error(){
		super();
	}
	
	Error(String msg){
		System.err.println(msg);
	}
	

}
