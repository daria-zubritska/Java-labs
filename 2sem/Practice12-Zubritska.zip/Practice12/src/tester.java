/*Написати свій власний клас виняток і продемонструвати його використання.
 * File: tester.java
 * Author: Zubritska
 * */
public class tester extends Error {

	public static void main(String[] args) {
		
		try {
			acting();
		} catch (Error e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			System.out.println("Hello");
		}
		try {
			act();
		} catch (Error e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void acting() throws Error {
		throw new Error();
	}
	
	public static void act() throws Error {
		throw new Error("U peasant");
	}
	
}
