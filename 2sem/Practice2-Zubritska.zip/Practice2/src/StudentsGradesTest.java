import java.io.IOException;

public class StudentsGradesTest{

	public static void main(String[] args) throws IOException {
		
		int limit = DataInput.getInt("Введіть кількість студентів: ");
		
		StudentsGrades grades = new StudentsGrades(limit);
		
		for(int i = 0; i<limit; i++) {
			
			int grade = DataInput.getInt("Введіть оцінку: ");
			
			if(grades.TryAdd(grade)==1) {
				System.out.println();
			}
			else if(grades.TryAdd(grade)==0){
				System.out.println();
			}
			else if(grades.TryAdd(grade)==-1) {
				System.out.println();
			}
			
		}
		
		
		System.out.println("Максимальна оцінка: "+grades.max());
		
		System.out.println("Мінімальна оцінка: "+grades.min());
		
		System.out.println("Середня оцінка: "+grades.averageGrade());
		
		System.out.println("Кількість вищих за середню: "+grades.higherThanAverage());
		
		System.out.println("Кількість нижчих за середню: "+grades.lowerThanAverage());
		
		System.out.println("Кількість відмінно: "+grades.exelentGrades());
		
		System.out.println("Кількість добре: "+grades.goodGrades());
		
		System.out.println("Кількість задовільно: "+grades.enoughGrades());
		
		System.out.println("Кількість незадовільно: "+grades.notEnoughGrades());
		
		System.out.println("Всі оцінки: "+grades.ToString());
		
		double[] listGrades1 = grades.listToHigh();
		
		System.out.println("З нижчої до вищої: ");
		
		for(int i = 0; i<listGrades1.length; i++) {
			System.out.println(listGrades1[i]);
		}
		
		double[] listGrades2 = grades.listToLow();
		
		System.out.println("З вищої до нижчої: ");
		
		for(int i = 0; i<listGrades2.length; i++) {
			System.out.println(listGrades2[i]);
		}
		
		
		double[] newGrades = {0,20,10,30};
		
		grades.setGrades(newGrades);
		
		System.out.println("Всі оцінки: "+grades.ToString());
	}
	
}
