
/*
 * До попереднього практичного додати метод, що вміє сортувати масив оцінок
 *  студентів за зростанням та за спаданням.
 * 
 * File: StudentsGrades.java
 * Author: Zubritska
 * */

public class StudentsGrades {
	
	
	
	private double[] grades;
	
	private int num = 0;
	
	/***
	 * Створює новий массив з оцінками
	 * 
	 * @param gradesLimit - максимальна кількість оцінок у массиві
	 */
	StudentsGrades(int gradesLimit){
		grades = new double[gradesLimit];
	}
	
	/***
	 * Заміняє массив массивом користувача
	 * 
	 * @param gradesArray - массив користувача
	 */
	public void setGrades(double[] gradesArray) {
		this.grades = gradesArray;
		num = gradesArray.length;
	}
	
	/***
	 * Повертає массив оцінок
	 */
	public double[] getGrades() {
		return grades;
	}
	
	/***
	 * Повертає 1, якщо оцінка успішно додана, 0 - закінчився массив, -1 - некоректна оцінка
	 * 
	 * @param grade - оцінка, яку потрібно додати до массиву
	 */
	public int TryAdd(double grade) {
		
		if(grade < 0||grade>100){
			return -1;
		}
		else if(num < grades.length) {
			grades[num] = grade;
			num++;
		
			return 1;
		}
		
		return 0;
	}
	
	/***
	 * Повертає максимальне значення з масиву оцінок
	 */
	public double max() {
		
		double max=0;
		
		for(int i=0; i<num; i++) {
			if(this.grades[i]>max) max = grades[i];
		}
		
		return max;
	}
	
	/***
	 * Повертає мінімальне значення з масиву оцінок
	 */
	public double min() {
		
		double min=100;
		
		for(int i=0; i<num; i++) {
			if(grades[i]<min) min = grades[i];
		}
		
		return min;
	}
	
	/***
	 * Повертає середній бал
	 */
	public double averageGrade() {
		double average=0;
		
		double sum=0;
		for(int i=0; i<num;i++) {
			sum = sum + grades[i];
		}
		
		average = sum/num;
		
		return average;
	}
	
	/***
	 * Повертає кількість оцінок вищих за середню
	 */
	public int higherThanAverage() {
		
		int numHigh = 0;
		for(int i=0; i<num; i++) {
			if(grades[i]>averageGrade()) {
				numHigh++;
			}
		}
		
		return numHigh;
	}
	
	/***
	 * Повертає кількість оцінок нижчих за середню
	 */
	public int lowerThanAverage() {
		
		int numLow = 0;
		for(int i=0; i<num; i++) {
			if(grades[i]<averageGrade()) {
				numLow++;
			}
		}
		
		return numLow;
	}
	
	/***
	 * Повертає кількість оцінок 91-100
	 */
	public int exelentGrades() {
		
		int numEx = 0;
		for(int i=0; i<num; i++) {
			if(grades[i]>=91) {
				numEx++;
			}
		}
		
		return numEx;
	}
	
	/***
	 * Повертає массив оцінок 71-90
	 */
	public int goodGrades() {
		
		int numEx = 0;
		for(int i=0; i<num; i++) {
			if(grades[i]>=71 && grades[i]<=90) {
				numEx++;
			}
		}
		
		return numEx;
	}
	
	/***
	 * Повертає кількість оцінок 60-70
	 */
	public int enoughGrades() {
		
		int numEx = 0;
		for(int i=0; i<num; i++) {
			if(grades[i]>=60 && grades[i]<=70) {
				numEx++;
			}
		}
		
		return numEx;
	}
	
	/***
	 * Повертає кількість оцінок 0-59
	 */
	public int notEnoughGrades() {
		
		int numEx = 0;
		for(int i=0; i<num; i++) {
			if(grades[i]>=0 && grades[i]<=59) {
				numEx++;
			}
		}
		
		return numEx;
	}
	
	/***
	 * Повертає String масиву оцінок
	 */
	public String ToString() {
		
		String gradesStr = "";
		
		for(int i=0; i<num; i++) {
			gradesStr = gradesStr + grades[i] + "\n";
		}
		
		return gradesStr;
	}
	
	public double[] listToHigh() {
		
		double[] list = grades;
		
		for(int i = 0; i<num; i++) {
			double min = list[i];
	        int min_i = i; 
	        
	        for (int j = i+1; j < num; j++) {
	            
	            if (list[j] < min) {
	                min = list[j];
	                min_i = j;
	            }
	        }
	        
	        if (i != min_i) {
	            double tmp = list[i];
	            list[i] = list[min_i];
	            list[min_i] = tmp;
	        }
		}
		
		return list;
	}
	
	public double[] listToLow() {
		
		double[] list = grades;
		
		for(int i = 0; i<num; i++) {
			double max = list[i];
	        int max_i = i; 
	        
	        for (int j = i+1; j < num; j++) {
	            
	            if (list[j] > max) {
	                max = list[j];
	                max_i = j;
	            }
	        }
	        
	        if (i != max_i) {
	            double tmp = list[i];
	            list[i] = list[max_i];
	            list[max_i] = tmp;
	        }
		}
		
		return list;
	}
}

