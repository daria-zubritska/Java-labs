/*
 * За аналогією дописати метод, що читає і повертає стрічку символів в клас DataInput.

Написати програму, що: зчитує студентів групи і записує в масив

виводить на екран інформацію про студентів
виводить на екран всіх студентів які починаються на вказану літеру (літеру прочитати з клавіатури)

File: Students.java
Author: Zubritska
 */

import java.io.IOException;

public class Students {
	
	
	
	public static void main(String[] args) throws IOException {
		
		int arraySpace = DataInput.getInt("Введіть кількість студентів: ");
		
		String[][] students = new String[arraySpace][2]; 
		
		for(int i = 0; i<arraySpace; i++) {
			System.out.println("Введіть ім'я студента: ");
			students[i][0] = DataInput.readLine();
			
			int grade = randomGrade();
			
			students[i][1] = Integer.toString(grade);
		}
		
		printInfo(students);
		
		specificLetter(students);
		
	}
	
	private static void specificLetter(String[][] students) throws IOException {
		System.out.println("Введіть першу літеру: ");
		
		char letter = DataInput.getChar();
		
		String student = "";
		
		for(int i = 0; i<students.length; i++) {
			String name = students[i][0];
			
			char ch = name.charAt(0);
		
			if(Character.toLowerCase((char)ch) == Character.toLowerCase((char)letter)) {
				
				student = "";
				for(int j = 0; j<2; j++) {
					student = student + students[i][j];
				}
				
				System.out.println(student);
			}
		}
	}
	
	private static void printInfo(String[][] students) {
		
		String student = "";
		
		for(int i = 0; i<students.length; i++) {
			
			student = "";
			for(int j = 0; j<2; j++) {
				student = student + students[i][j] + " ";
			}
			
			System.out.println(student);
		}
		
	}
	
	private static int randomGrade() {
		
		double randomGrade= (Math.random() * ((100 - 0) + 1)) + 0;
		
		int randomGradeInt = (int) Math.round(randomGrade);
		
		return randomGradeInt;
	}

}
