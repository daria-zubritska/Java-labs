package project;

/*Перша спроба моделювання.

Уявімо собі ситуацію. Нам потрібно написати програму, що буде управляти зоомагазином.

В нас є тварини(оберіть самостійно), наприклад пінгвін і медвідь. А також є працівник зоопарку 
(роль його оберіть самостійно), наприклад доглядач тварин.

Зробіть класи які будуть характеризувати вказані дійові особи системи, опишіть поля і методи, 
що їм притаманні (методи можуть бути порожні).
 * 
 * */

class Worker{
	void feed() {
		System.out.println("Працівник магазину погодував кошеня та собаку.");
	}
	
	void groomDogs() {
		System.out.println("Працівник магазину розчісав собаку.");
	}
}


class Dog{
	void bark() {
		System.out.println("Собака гавкає.");
	}
	
	void dogEatFood() {
		System.out.println("Собака їсть.");
	}
}

class Kitten{
	void meow() {
		System.out.println("Кошеня нявчить.");
	}
	
	void kittensEatFood() {
		System.out.println("Кошеня їсть.");
	}
}

public class Zoo {

	public static void main(String[] arg) {
		
		Worker a = new Worker();
		
		a.feed();
		a.groomDogs();
		
		Dog b = new Dog();
		
		b.bark();
		b.dogEatFood();
		
		Kitten c = new Kitten();
		
		c.kittensEatFood();
		c.meow();
		
	}
	
}
