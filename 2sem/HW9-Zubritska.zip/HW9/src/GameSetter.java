import java.util.Random;

public class GameSetter {

	Random rand = new Random();

	private int limit;
	private int score = 0;
	private int rounds = 0;
	private int amount;
	boolean plusMinus;
	int first;
	int second;
	int res;
	
	GameSetter(){
		limit = 0;
		amount = 0;
	}

	GameSetter(int uLimit, int uAmount) {
		limit = uLimit;
		amount = uAmount;
	}

	private void round() {

		if (rand.nextBoolean()) {
			plusMinus = true;
			first = rand.nextInt(limit);
			second = rand.nextInt(limit);

			while (first + second > limit) {
				first = rand.nextInt(limit);
				second = rand.nextInt(limit);
			}

			res = first + second;
		} else {
			plusMinus = false;
			first = rand.nextInt(limit);
			second = rand.nextInt(limit);

			while (first - second < 0) {
				first = rand.nextInt(limit);
				second = rand.nextInt(limit);
			}

			res = first - second;
		}
	}

	public String getExercise() {
		rounds++;

		if (rounds <= amount)
			round();

		if (plusMinus)
			return first + " + " + second + " =";
		else
			return first + " - " + second + " =";
	}

	public boolean check(int ans) {
		if (ans == res) {
			score++;
			return true;
		}
		return false;
	}
	
	public int getScore() {
		return score;
	}
	
	public int getAmount() {
		return amount;
	}
}
