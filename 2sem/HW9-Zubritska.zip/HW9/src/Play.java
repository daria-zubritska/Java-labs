import javax.swing.SwingUtilities;

/*Написати програму "Математична гра", що виводить приклади на додавання і віднімання з 2,3-х дій і просить у користувача відповідь. В якості обмеження користувач вказує максимальне число до якого він вже знає числа. Наприклад, користувач ввів 6 і кількість прикладів - 4, йому виводяться приклади: 2+2=, 4+2=, 3+3=, 6-2=. Це гра з графічним інтерфейсом.
 * 
 * File: Play.java
 * Author: Zubritska*/

public class Play {

	public static void main(String[] args) {
		
		Runnable FileChooserThread = new Runnable() {
			public void run() {
				new UserFrame();
			}
		};
		
		SwingUtilities.invokeLater(FileChooserThread);
	}

}
