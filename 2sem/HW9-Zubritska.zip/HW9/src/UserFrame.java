import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class UserFrame extends JFrame implements ActionListener {

	private JPanel game;
	private JPanel game2;
	private JPanel gameEnd;
	private JTextField answerField;
	private JButton submitAnswer;
	private JButton submit;
	private JTextField limit;
	private JTextField amount;
	private int counter = 0;

	int lim;
	int am;

	GameSetter newGame;

	UserFrame() {
		super("'Funny' game");
		newGame = new GameSetter();
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setSize(500, 300);

		this.setVisible(true);
		initFirstMenu();
		add(game);

		pack();
	}

	private void initFirstMenu() {
		game = new JPanel(new GridLayout(3, 2));

		game.add(new JLabel("Enter limit: "));
		limit = new JTextField();
		limit.setSize(100, 20);
		game.add(limit);

		game.add(new JLabel("Enter amount: "));
		amount = new JTextField();
		amount.setSize(100, 20);
		game.add(amount);

		submit = new JButton("Submit");
		submit.addActionListener(this);
		game.add(submit);
	}

	private void initSecond(int lim, int am) {

		game2 = new JPanel(new GridLayout(2, 2));

		game2.add(new JLabel(newGame.getExercise()));
		answerField = new JTextField();
		answerField.setSize(100, 20);
		game2.add(answerField);

		submitAnswer = new JButton("Submit");
		submitAnswer.addActionListener(this);
		game2.add(submitAnswer);

		add(game2);

	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == submitAnswer) {
			if (answerField.getText().equals("")) {
				newGame.check(Integer.parseInt(answerField.getText()));
				answerField.removeAll();
				game2.removeAll();
				game2.revalidate();

				if (counter + 1 < newGame.getAmount()) {
					counter++;
					initSecond(lim, am);
				} else {
					JOptionPane.showMessageDialog(null, "Correct: " + newGame.getScore() + "/" + newGame.getAmount(),
							"THE END", JOptionPane.PLAIN_MESSAGE);
				}
			} else {
				JOptionPane.showMessageDialog(null, "Do not leave empty fields.", "Error", JOptionPane.ERROR_MESSAGE);
			}

		} else if (e.getSource() == submit) {
			if (!limit.getText().equals("") && !amount.getText().equals("")) {

				lim = Integer.parseInt(limit.getText().toString());
				am = Integer.parseInt(amount.getText().toString());

				game.removeAll();
				game.revalidate();
				game.repaint();
				newGame = new GameSetter(lim, am);
				initSecond(lim, am);
			} else {
				JOptionPane.showMessageDialog(null, "Do not leave empty fields.", "Error", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
}
