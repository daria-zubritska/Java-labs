package project;

public class tester {

	public static void main(String[] args) {
		
		ReadSpecialWords rw = new ReadSpecialWords("text.txt");
		
		System.out.println("Кількість слів: " + rw.getWordsNum());
		System.out.println("Кількість унікальних слів: " + rw.getSpecialNum());

		System.out.println("Унікальні слова: ");
		
		String[] str = rw.getSpecialWords();
		
		for(int i = 0; i<rw.getSpecialNum(); i++) {
			System.out.println(str[i]);
		}
		
		System.out.println("Унікальні слова за алфавітом(- скільки цього слова у тексті): ");
		
		String[] alph = rw.getSpecialByAlphabet();
		
		for(int i = 0; i<rw.getSpecialNum(); i++) {
			System.out.println(alph[i]);
		}
	}

}
