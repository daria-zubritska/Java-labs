package project;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StreamTokenizer;

public class ReadSpecialWords {
	
	private String[] words = new String[100];
	private int num = 0;
	public int specNum = 1;
	private String[] special;

	ReadSpecialWords(String fileName){
		StreamTokenizer st;
		
		try {
			st = new StreamTokenizer(new BufferedReader(new FileReader(fileName)));
			while (st.nextToken()!=StreamTokenizer.TT_EOF) {
				switch (st.ttype) {
					case StreamTokenizer.TT_NUMBER :
						System.out.println(" num: "+st.nval);
						break ;
					case StreamTokenizer.TT_WORD :
						if(num<100) {
							words[num] = st.sval;
						}else {
							String[] time = words;
							words = new String[num];
							words = time;
							words[num] = st.sval;
						}
						System.out.println(" word: "+st.sval);
						num++;
						break ;
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public int getWordsNum() {
		return num;
	}
	
	public int getSpecialNum() {
		
		return specNum;
	}

	public String[] getSpecialWords() {
		
		special = new String[num];
		special[0] = words[0];
		
		for(int i = 1; i< num; i++) {
			for(int j = 0; j<specNum; j++) {
				if(special[j].equalsIgnoreCase(words[i])) {
					break;
				}else if(j == specNum-1) {
					special[specNum] = words[i];
					specNum++;
					break;
				}
			}
		}
		
		return special;
	}
	
	public String[] getSpecialByAlphabet() {
		
		String[] alphabet = this.special;
		int alp = 0;
		
		for(int i = 0; i< alphabet.length; i++) {
			if(alphabet[i] == null) break;
			alp++;
		}
		
		boolean isSorted = false;
		String word;
		
		while (!isSorted) {
			isSorted = true;
			for (int i1 = 0; i1 < alp-1; i1++) {
				if (alphabet[i1].compareTo(alphabet[i1 + 1]) > 0) {
					word = alphabet[i1];
					alphabet[i1] = alphabet[i1+1];
					alphabet[i1+1] = word;
					isSorted = false;
				}
			}
		}
		
		for(int i = 0; i< alp; i++) {
			int count = 0;
			
			for(int j = 0; j< num; j++) {
				if(alphabet[i].equalsIgnoreCase(words[j])) {
					count++;
				}
			}
			
			alphabet[i] = alphabet[i] + " - " + count;
			
		}
		
		return alphabet;
	}
	
	
	
}
