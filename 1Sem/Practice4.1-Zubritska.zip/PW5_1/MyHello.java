/*
 *написати hello world
 *
 * file: MyHello.java
 * Auth
 */

import acm.graphics.*;
import acm.program.*;

public class MyHello extends GraphicsProgram{

	public void run(){
		this.setSize(300, 400);
		add(new GLabel("Hello, world", 100, 75));
	}
}
