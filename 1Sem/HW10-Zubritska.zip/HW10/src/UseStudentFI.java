/*
 * Написати клас, який описує студента НаУКМА використовуючи наступні елементи:

змінні екземпляра
змінні класу
public і private методи
javadoc
toString

Та клас який використовує клас Student.
 * 
File: UseStudent.java
Author:Zubritska
 * 
 */


import acm.program.*;
import java.lang.Math;
import acm.util.*;



public class UseStudentFI extends ConsoleProgram{

	public void run(){
		
		StudentFI s;
		String studentName;
		String yesNo;
		
		do {
		println("Введіть ім'я студента:");
		studentName = readLine();
			
		s = new StudentFI(studentName);
		
		println(s);//??
		
		println("Бажаєте продовжити?(Так, Ні)");
		
		yesNo = readLine();
		
		}while(yesNo.compareToIgnoreCase("так")==0);
		
		println("Завершую роботу");
	}
}