import acm.util.RandomGenerator;

/*
 * Написати клас, який описує студента НаУКМА використовуючи наступні елементи:

змінні екземпляра
змінні класу
public і private методи
javadoc
toString

Та клас який використовує клас Student.
 * 
File: Student.java
Author:Zubritska
 * 
 */

/**
 * Створює профайл студента факультету інформатики
 * @author Daria Zubritska
 */
public class StudentFI extends Student {
	
	private static RandomGenerator rgen = RandomGenerator.getInstance(); 
	
	boolean complete1;
	boolean complete2;
	
	/** 
     * Створює профайл студента факультету інформатики
     * @param name - повне ім'я студента
     */	
	public StudentFI(String name) {
		super(name);
		this.complete1=rgen.nextBoolean();
		this.complete2=rgen.nextBoolean();
	}
	
	/**
	 * Виводить дані про студента факультету інформатики
	 */
	public String toString() {
		String javaProg= "не закінчив слухати дисципліну";
		String math= "не закінчив слухати дисципліну";
		
		if(complete1) {
			javaProg= "закінчив слухати дисципліну";
		}
		
		
		if(complete2) {
			math= "закінчив слухати дисципліну";
		}
		
		String status="offline";
		String homeworkStatus1 = "";
		String homeworkStatus2 = "";
		String homeWork1="не здано";
		String homeWork2="не здано";
		
		if(this.isOnlineStudy) {
			status = "online";
		
		
		
		if(this.isHomeWorkDone1) {
			homeWork1 = "здано";
		}
		homeworkStatus1 = " Домашнє завдання " + homeWork1;
		
		if(this.isHomeWorkDone2) {
			homeWork2 = "здано";
		}
		
		homeworkStatus2 = " Домашнє завдання " + homeWork2;
		}
		else {
			homeworkStatus1 = " Невідомий статус домашнього завдання";
			homeworkStatus2 = " Невідомий статус домашнього завдання";
		}
		
		return super.toString()+" навчається "+status+"\n"+ "Програмування Java: "+javaProg+". "+homeworkStatus1+"\n"+"Математичний аналіз: "+math+". "+homeworkStatus2;
		
	}
	
}
