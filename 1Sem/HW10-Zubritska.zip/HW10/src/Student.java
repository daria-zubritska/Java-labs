import acm.util.RandomGenerator;

/*
 * Написати клас, який описує студента НаУКМА використовуючи наступні елементи:

змінні екземпляра
змінні класу
public і private методи
javadoc
toString

Та клас який використовує клас Student.
 * 
File: Student.java
Author:Zubritska
 * 
 */

/**
 * Створює профайл студента
 * @author Daria Zubritska
 */
public class Student {
	private static RandomGenerator rgen = RandomGenerator.getInstance(); 
	
	
	public boolean isOnlineStudy;
	public String name;
	private int year;
	public boolean isHomeWorkDone1;
	public boolean isHomeWorkDone2;
	//private String status;
	//private String homeworkStatus = "";
	///private String homeWork;
	
	 /** 
     * Повертає чи навчається студент онлайн або офлайн
     */	
	public boolean isOnline(){
		
		return isOnlineStudy;
	}
	
    /** 
     * Створює профайл студента
     * @param name - повне ім'я студента
     */	
	public Student(String name){
		this.name = name;
		this.isOnlineStudy= rgen.nextBoolean();
		this.year=rgen.nextInt(1,4);
		this.isHomeWorkDone1= rgen.nextBoolean();
		this.isHomeWorkDone2= rgen.nextBoolean();
	}
	
	/*private void status() {//???
		
		if(this.isOnlineStudy) {
			status = "online";
		}
		else {
			status = "offline";
		}
	}
	
	private void homeWork() {//???
		
		if(this.isHomeWorkDone) {
			homeWork = "здано";
		}
		else {
			homeWork = "не здано";
		}
		homeworkStatus = " домашнє завдання" + homeWork;
	}*/
	
	public String getName() {
		return this.name;
	}
	
	public int getYear() {
		return this.year;
	}
	
	/*public String getStatus() {
		return this.status;
	}
	
	public String getHomeWorkStatus() {
		return this.homeworkStatus;
	}*/
	
	/**
	 * Виводить інформацію про студента та спосіб його навчання
	 */
	public String toString() {
		

		return "Студент " + this.name + " курс " + this.year;
	}
	
}
