/*
 * Це заготовка для першого практичного зайняття
 * світ має назву lection1
 */
import stanford.karel.*;

public class FirstProgram extends Karel{
	
	public void run(){
		move();
		pickBeeper();
		move();
		turnLeft();
		move();
		move();
		move();
		move();
		move();
		turnLeft();
		turnLeft();
		turnLeft();
		move();
		move();
		move();
		move();
		turnLeft();
		turnLeft();
		turnLeft();
		move();
		move();
		turnLeft();
		turnLeft();
		turnLeft();
		move();
		move();
		turnLeft();
		move();
		move();
		turnLeft();
		move();
		putBeeper();
		turnLeft();
		move();
		turnLeft();
		move();
		turnLeft();
		turnLeft();
		turnLeft();
		move();
		turnLeft();
		turnLeft();
		turnLeft();
		move();
		move();
		turnLeft();
		turnLeft();
		turnLeft();
		move();
		move();
		move();
		turnLeft();
		turnLeft();
		turnLeft();
		move();
		move();
		move();
		move();
		move();
		move();
		turnLeft();
		turnLeft();
	}
}
