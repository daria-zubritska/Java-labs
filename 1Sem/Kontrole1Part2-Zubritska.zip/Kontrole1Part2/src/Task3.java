/*
 * var.716
 * 
 * File: Task3.java
 * Author: Зубріцька Дар'я
 **/

import acm.program.*;

public class Task3 extends ConsoleProgram{

	public void run(){
		int x=readInt("Введіть x:");
		int k=readInt("Введіть k:");
		
		for(int i=1; i<=k;i++) {
			double a= sequence(x,k);
			println(i+"-"+a);
		}
		
	}
	
	private double sequence(int x,int k) {
		double formula;
		if(k>0) {
			formula=multiply(x,k-1)/factorial(k-1);
			return formula;
		}
		else {
			return formula=1;
		}
	}
	private int multiply(int x,int k) {
		int mult=x;
		if(k>0) {
			mult=mult*multiply(mult,k-1);
			return mult;
		}
		else {
			return mult=1;
		}
		
	}
	
	private int factorial(int k) {
		int fact;
		if(k>0) {
			fact=k*factorial(k-1);
			return fact;
		}
		else {
			fact=1;
			return fact;
		}
	}
}
