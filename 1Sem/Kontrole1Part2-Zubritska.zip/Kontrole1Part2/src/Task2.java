/*
 * var.716
 * 
 * File: Task2.java
 * Author:Зубріцька Дар'я
 * 
 **/


import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

public class Task2 extends GraphicsProgram{
	private RandomGenerator rgen = RandomGenerator.getInstance(); 
	
	private static final int WORLDX=250;
	private static final int WORLDY=400;
	
	private static final int n=3;

	public void run(){
		this.setSize(WORLDX, WORLDY);
		
		buildRectangles();
	}
	
	
	private void buildRectangles() {
		int x;
		int y;
		int width;
		int height;
		
		for(int i=0; i<n; i++) {
			x= rgen.nextInt(0,WORLDX);
			y= rgen.nextInt(63,WORLDY);
			width= rgen.nextInt(1,WORLDX);
			height= rgen.nextInt(1,WORLDY);
			
			while((x+width)>=WORLDX-10) {
				x= rgen.nextInt(0,WORLDX);
				width= rgen.nextInt(1,WORLDX);
			}
			while((y+height)>=WORLDY-63) {
				y= rgen.nextInt(63,WORLDY);
				height= rgen.nextInt(1,WORLDY);
			}
			
			add(new GRect(x,y,width,height));
		}
	}
}

