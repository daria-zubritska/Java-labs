/*
 * var.716
 * 
 * File: Task1.java
 * Author: Зубріцька Дар'я
 **/


import stanford.karel.*;

public class Task1 extends SuperKarel{
	
	public void run(){
		while(true) {
			if(frontIsClear()) {
				move();
			}
			else {
				changeRow();
			}
			moveToBeeper();
			if(facingNorth()) {
				while(notFacingEast()) {
					turnRight();
				}
				break;
			}
			pickBeeper();
			returnToOneOne();
		}
	}
	
	private void moveToBeeper() {
		while(noBeepersPresent()) {
			
			if(frontIsBlocked()) {
				
				if(facingEast()) {
					turnLeft();
					if(frontIsClear()) {
						move();
						turnLeft();
					}
					else {
						break;
				}
				}
				else {
					if(facingWest()) {
						turnRight();
						if(frontIsClear()) {
							move();
							turnRight();
						}
						else {
							break;
					}
				}
				}
			}
			else {
				move();
			}
		}
		
	}
	
	private void changeRow() {
		if(facingEast()) {
			turnLeft();
			if(frontIsClear()) {
				move();
				turnLeft();
			}
			else {
				while(notFacingEast()) {
					turnRight();
			}
		}
		}
		else {
			if(facingWest()) {
				turnRight();
				if(frontIsClear()) {
					move();
					turnRight();
				}
				else {
					while(notFacingEast()) {
						turnRight();
					}
			}
		}
		}
		}
	
	private void returnToOneOne() {
		if(notFacingWest()) {
			turnAround();
		}
		while(frontIsClear()) {
			move();
		}
		turnLeft();
		while(frontIsClear()) {
			move();
		}
		turnLeft();
		putBeeper();
		if(frontIsClear()) {
			move();
		}
		else {
			changeRow();
		}
	}

}
