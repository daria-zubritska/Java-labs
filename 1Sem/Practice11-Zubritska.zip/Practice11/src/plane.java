/*написати гру в якій літак має збивати цілі, що розміщені на землі
 
 File: plane.java
Author:Zubritska
 * 
 */


import acm.program.*; 
import acm.graphics.*; 
import java.lang.Math;
import acm.util.*;
import java.awt.*; 
import java.awt.event.*; 

public class plane extends GraphicsProgram {
	private static RandomGenerator rgen = RandomGenerator.getInstance();
	/**delay */
	private static final int DELAY=10;
	
	/**set the size of the window*/
	private static final int WINDOWX=600;
	private static final int WINDOWY=500;
	
	/**set the size of the plane*/
	private static final int PLANE_SPEED = 2;
	private static final int PLANE_WIDTH=30;
	private static final int PLANE_HEIGHT=10;
	
	/**set the bomb*/
	private static final int BOMB_SPEED = 10;
	private static final int BOMB_HEIGHT = 10;
	private static final int BOMB_WIDTH = 5;
	
	/**set aims*/
	private static final int AIM_SPEED = 3;
	private static final int AIM_WIDTH=40;
	private static final int AIM_HEIGHT=30;
	private static final int INDENTX=10;
	private static final int INDENTY=4;

	public void run(){
		setup();
		while(!gameOver()) {
			movePlane();
			moveBomb();
			checkForCollisions();
			pause(DELAY);
		}
		
		if(buildCount==0 && plane.getHeight()>limit.getHeight()) {
			removeAll();
			GLabel winner = new GLabel("Winner");
			add(winner, (WINDOWX-winner.getWidth())/2, (WINDOWY-winner.getHeight())/2);
		}else if(plane.getHeight()+plane.getY() > limit.getY()) {
			removeAll();
			GLabel gameOver = new GLabel("Game Over");
			add(gameOver, (WINDOWX-gameOver.getWidth())/2, (WINDOWY-gameOver.getHeight())/2);
		}
		
	}
	
	private void setup() {
		this.setSize(WINDOWX,WINDOWY);
		plane= new GOval(PLANE_WIDTH,PLANE_HEIGHT);
		plane.setFilled(true);
		add(plane,(0-PLANE_WIDTH),0);
		
		planeToRight = true;
		
		addAims();
		
		addMouseListeners();
	}
	
	private void addAims() {
		
		limit = new GLine(0,WINDOWY-95-(INDENTY+AIM_HEIGHT)*3, WINDOWX,WINDOWY-95-(INDENTY+AIM_HEIGHT)*3);
		limit.setColor(Color.GRAY);
		add(limit);
		
		int secCount=0;
		
		for(int i=0; i*(INDENTX+AIM_WIDTH)<WINDOWX; i++) {
			int r = rgen.nextInt(1,3);
			for(int j=0; j<r;j++) {
			
				aim = new GRect(AIM_WIDTH,AIM_HEIGHT);
				aim.setFilled(true);
				add(aim, i*(INDENTX+AIM_WIDTH), WINDOWY-95-j*(INDENTY+AIM_HEIGHT));
			
			}
			secCount = secCount + r;
		}
		
		buildCount = secCount;
	}
	
	public void mousePressed(MouseEvent e) {
		if(bomb==null) {
			bomb = new GOval(BOMB_WIDTH,BOMB_HEIGHT);
			bomb.setFilled(true);
			bomb.setColor(Color.RED);
			add(bomb, plane.getX()+2, plane.getY()+1);
		}
	}
	
	private void movePlane() {
		if (planeToRight) { 
			plane.move(PLANE_SPEED, 0); 
			if (plane.getX() >= WINDOWX-PLANE_WIDTH) { 
				planeToRight = false; 
				plane.move(0, PLANE_HEIGHT); 
			} 
		} else { 
			plane.move(-PLANE_SPEED, 0); 
			if (plane.getX() <= 0) { 
				planeToRight = true; 
				plane.move(0, PLANE_HEIGHT); 
			} 
		} 
	}
	
	
	private void moveBomb() {
		if(bomb!=null) {
			bomb.move(0, BOMB_SPEED);
		}
		
		GObject collider = getCollidingObject();
		if (collider !=null) {
			remove(collider); 
			buildCount--;
			bomb.setLocation(0, WINDOWY+100);
			bomb = null;
			
		}
			
	}
	
	private GObject getCollidingObject() {
		if(bomb!=null) {
			if((getElementAt(bomb.getX()+BOMB_WIDTH/2, bomb.getY()+BOMB_HEIGHT/2))!=null) {
	         	return getElementAt(bomb.getX(), bomb.getY());
	      	}
			else {
				return null;
			}
		}
		return null;
	}

	private void checkForCollisions() {
		collideWithAim();
		collideWithScreen();
	}
	
	private void collideWithScreen() {
		if (bomb != null) { 
			if (bomb.getY() >= WINDOWY) { 
				remove(bomb); 
				bomb = null; 
			} 
		} 
	}
	
	private void collideWithAim() {
		
	}
	
	private boolean gameOver() {
		
		return (buildCount==0 && plane.getHeight()>limit.getHeight()) || (plane.getHeight()+plane.getY() > limit.getY());
	}
	
	private GOval plane;
	private GOval bomb;
	private GRect aim;
	private int buildCount;
	private GLine limit;
	private boolean planeToRight;
	
}
