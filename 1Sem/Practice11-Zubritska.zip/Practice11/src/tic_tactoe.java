/*написати гру в хрестики нулики на дошці розмірності 3*3
 * 
File: tic_tactoe.java
Author:Zubritska
 * 
 */


import acm.program.*; 
import acm.graphics.*; 
import java.lang.Math;
import acm.util.*;
import java.awt.*; 
import java.awt.event.*; 

public class tic_tactoe extends GraphicsProgram{
	private static RandomGenerator rgen = RandomGenerator.getInstance(); 
	
	/**set the size of the window*/
	private static final int WINDOWX=600;
	private static final int WINDOWY=500;

	public void run(){
	setup();
	
	while(!isGameOver) {
		pause(10);
	}
	
	GLabel click = new GLabel("Click to proceed");
	add(click, (WINDOWX-click.getWidth())/2, (0+click.getHeight())/2+20);
	
	waitForClick();
	removeAll();
	
	if(slotCalc!=10) {
		if(fig==11) {
			GLabel winnerX = new GLabel("X - Winner");
			add(winnerX, (WINDOWX-winnerX.getWidth())/2, (WINDOWY-winnerX.getHeight())/2);
		}
		else{
			GLabel winnerO = new GLabel("O - Winner");
			add(winnerO, (WINDOWX-winnerO.getWidth())/2, (WINDOWY-winnerO.getHeight())/2);
		}
	}
	else {
		GLabel draw = new GLabel("Draw");
		add(draw, (WINDOWX-draw.getWidth())/2, (WINDOWY-draw.getHeight())/2);
	}
}
	
	private void setup() {
		this.setSize(WINDOWX,WINDOWY);
		
		setupGrid();
		
		addMouseListeners();
	}
	
	public void mouseReleased(MouseEvent e) {
		
		if(isGameOver){
			return;
		}
		
		if(slotCalc%2==0) {
			fig = hum;
		}
		else {
			fig = bot;
		}
		
		GPoint clickPoint  = new GPoint(e.getX(), e.getY());
		if(slot1.contains(clickPoint)) {
			if(slot1Free) {
				drawFigure(slot1.getX(),slot1.getY(),fig);
				slot1Free=false;
				slotCalc++;
				slot1Fig=fig;
			}
			
			
		}else if(slot2.contains(clickPoint)) {
			if(slot2Free) {
				drawFigure(slot2.getX(),slot2.getY(),fig);
				slot2Free=false;
				slotCalc++;
				slot2Fig=fig;
			}
			
		}else if(slot3.contains(clickPoint)) {
			if(slot3Free) {
				drawFigure(slot3.getX(),slot3.getY(),fig);
				slot3Free=false;
				slotCalc++;
				slot3Fig=fig;
			}
			
		}else if(slot4.contains(clickPoint)) {
			if(slot4Free) {
				drawFigure(slot4.getX(),slot4.getY(),fig);
				slot4Free=false;
				slotCalc++;
				slot4Fig=fig;
			}
			
		}else if(slot5.contains(clickPoint)) {
			if(slot5Free) {
				drawFigure(slot5.getX(),slot5.getY(),fig);
				slot5Free=false;
				slotCalc++;
				slot5Fig=fig;
			}
			
		}else if(slot6.contains(clickPoint)) {
			if(slot6Free) {
				drawFigure(slot6.getX(),slot6.getY(),fig);
				slot6Free=false;
				slotCalc++;
				slot6Fig=fig;
			}
			
		}else if(slot7.contains(clickPoint)) {
			if(slot7Free) {
				drawFigure(slot7.getX(),slot7.getY(),fig);
				slot7Free=false;
				slotCalc++;
				slot7Fig=fig;
			}
			
		}else if(slot8.contains(clickPoint)) {
			if(slot8Free) {
				drawFigure(slot8.getX(),slot8.getY(),fig);
				slot8Free=false;
				slotCalc++;
				slot8Fig=fig;
			}
			
		}else if(slot9.contains(clickPoint)) {
			if(slot9Free) {
				drawFigure(slot9.getX(),slot9.getY(),fig);
				slot9Free=false;
				slotCalc++;
				slot9Fig=fig;
			}
			
		}
		
		isGameOver = gameOver();
	}

	
	
	
	private void drawFigure(double slotX, double slotY, int fig) {
		if(fig==11) {
			GLine leftTop= new GLine(slotX+3, slotY+3, slotX+97, slotY+97);
			add(leftTop);
			
			GLine rightTop= new GLine(slotX+97, slotY+3, slotX+3, slotY+97);
			add(rightTop);
		}
		else if(fig== -11) {
			GOval circle = new GOval(slotX+3, slotY+3, 94,94);
			add(circle);
		}
	}
	
	
	private void setupGrid() {
		slot1 = new GRect(100,100);
		slot2 = new GRect(100,100);
		slot3 = new GRect(100,100);
		slot4 = new GRect(100,100);
		slot5 = new GRect(100,100);
		slot6 = new GRect(100,100);
		slot7 = new GRect(100,100);
		slot8 = new GRect(100,100);
		slot9 = new GRect(100,100);
		
		add(slot1,(WINDOWX-300)/2, (WINDOWY-300)/2);
		add(slot2,(WINDOWX-300)/2+100, (WINDOWY-300)/2);
		add(slot3,(WINDOWX-300)/2+200, (WINDOWY-300)/2);
		
		add(slot4,(WINDOWX-300)/2, (WINDOWY-300)/2+100);
		add(slot5,(WINDOWX-300)/2+100, (WINDOWY-300)/2+100);
		add(slot6,(WINDOWX-300)/2+200, (WINDOWY-300)/2+100);
		
		add(slot7,(WINDOWX-300)/2, (WINDOWY-300)/2+200);
		add(slot8,(WINDOWX-300)/2+100, (WINDOWY-300)/2+200);
		add(slot9,(WINDOWX-300)/2+200, (WINDOWY-300)/2+200);
		
	}
	
	private boolean gameOver() {
		if(slot1Fig==slot2Fig&&slot1Fig==slot3Fig) {
			return true;
		}
		else if(slot1Fig==slot4Fig&&slot1Fig==slot7Fig) {
			return true;
		}
		else if(slot1Fig==slot5Fig&&slot1Fig==slot9Fig) {
			return true;
		}
		else if(slot2Fig==slot5Fig&&slot2Fig==slot8Fig) {
			return true;
		}
		else if(slot3Fig==slot6Fig&&slot3Fig==slot9Fig) {
			return true;
		}
		else if(slot3Fig==slot5Fig&&slot3Fig==slot7Fig) {
			return true;
		}
		else if(slot4Fig==slot5Fig&&slot4Fig==slot6Fig) {
			return true;
		}
		else if(slot7Fig==slot8Fig&&slot7Fig==slot9Fig) {
			return true;
		}
		else if(slotCalc==9) {
			slotCalc++;
			return true;
		}
		else {
			return false;
		}
	}
	
	private int hum=11;
	private int bot=-11;
	
	private boolean isGameOver = false;
	
	private GRect slot1;
	private GRect slot2;
	private GRect slot3;
	private GRect slot4;
	private GRect slot5;
	private GRect slot6;
	private GRect slot7;
	private GRect slot8;
	private GRect slot9;
	
	private boolean slot1Free=true;
	private boolean slot2Free=true;
	private boolean slot3Free=true;
	private boolean slot4Free=true;
	private boolean slot5Free=true;
	private boolean slot6Free=true;
	private boolean slot7Free=true;
	private boolean slot8Free=true;
	private boolean slot9Free=true;
	
	private int fig = 0;
	private int slot1Fig=1;
	private int slot2Fig=2;
	private int slot3Fig=3;
	private int slot4Fig=4;
	private int slot5Fig=5;
	private int slot6Fig=6;
	private int slot7Fig=7;
	private int slot8Fig=8;
	private int slot9Fig=9;
	
	private int slotCalc=0;
}


