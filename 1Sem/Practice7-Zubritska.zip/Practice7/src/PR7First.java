/*
 *1) Програма має рахувати числа Фібоначі і виводити результати на екран у формі:
0 - 0
1 - 1
2 - 1
3 - 2
і так далі
Кількість чисел Фібоначі, що необхідно вивести вводить користувач.

2)Програма має рахувати n! Число n вводить користувач.

3)Написати программу обчислення кількості (ми не знаємо кількість цифр)
 десяткових цифр натурального числа. Не використовувати стрічки, суто математичні операції.

File: PR7First.java
Author:Zubritska
 * 
 */


import acm.program.*;
import java.lang.Math;

public class PR7First extends ConsoleProgram{
	
	public void run(){
		
		//1)
		int fibbaInput= readInt("Введіть кількість чисел Фібоначчі:");
		
		for(int i = 0; i < fibbaInput; i++) {
			int fib = fibonacci( i);
			println(i+ " - "+ fib );
		}
		
		//2)
		int factorialInput= readInt("Введіть n для n!:");
		int a = factorial(factorialInput);
		println("n!="+a);
		
		//3)
		int number= readInt("Введіть число:");
		int d=0;
		for(int i=0;Math.pow(10, i)<number;i++) {
			d=i+1;
		}
		println("У числі "+d+" цифр");
		
	}
	
	private int fibonacci( int f) {
		if(f == 0) {
			return 0;
		}
		else if(f > 1) {
			return fibonacci(f-1) + fibonacci(f-2);
		}
		else {
			return 1;
		}
	}
	
	private int factorial(int n) {
		int fact;
		if(n>0) {
			fact=n*factorial(n-1);
			return fact;
		}
		else {
			fact=1;
			return fact;
		}
	}
	
}
