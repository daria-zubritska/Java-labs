/*Розв'яжіть рівняння та виведіть на екран результат.

y=x^4
y=ax^2+bx+c
y=ax+c

Значення a, b, c, у задається з клавіатури.

File: Add2.java
Author:Zubritska
 *
 */


import acm.program.*;
import java.lang.Math;

public class Add2 extends ConsoleProgram{
	
	public void run(){
		double a=readInt("Введіть число a:");
		double b=readInt("Введіть число b:");
		double c=readInt("Введіть число c:");
		double y=readInt("Введіть число y:");
		
		println("y=x^4 x="+Math.pow(y, 1.0/4));
		
		square(a,b,c,y);
		
		println("y=ax+c x="+((y-c)/a));
	}
	
	private void square(double a,double b,double c,double y) {
		double discriminant= Math.pow(b, 2)-(4*a*c);
		double discriminantSqrt = Math.pow(discriminant, 1.0/2);
		
		println("y=ax^2+bx+c x1="+((-b+discriminantSqrt)/(2*a)));
		println("y=ax^2+bx+c x2="+((-b-discriminantSqrt)/(2*a)));
	}
}
