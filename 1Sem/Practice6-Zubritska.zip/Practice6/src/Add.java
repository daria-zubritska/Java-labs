/*Обчисліть значення функції та виведіть його на екран.

у=МАХ(a, b, c, d)
y=x^4
y=ax^2+bx+c

Значення a, b, c, d, х задається з клавіатури.

File: Add.java
Author:Zubritska
 * 
 */


import acm.program.*;

public class Add extends ConsoleProgram{
	
	public void run(){
		
		int a=readInt("Введіть число a:");
		int b=readInt("Введіть число b:");
		int c=readInt("Введіть число c:");
		int d=readInt("Введіть число d:");
		int x=readInt("Введіть число x:");
		
		println("MAX(a,b,c,d)="+max(a,b,c,d));
		
		println("x^4="+(x*x*x*x));
		
		println("ax^2+bx+c="+(a*x*x+b*x+c));
	}
	
	private int max(int a, int b, int c, int d) {
		int max = 0;
		
		if(a>=b) {
			if(a>=c) {
				if(a>=d) {
					max=a;
				}
				else {
					max=d;
				}
			}
			else {
				if(c>=d) {
					max=c;
				}
			}
		}
		else {
			if(b>=c) {
				if(b>=d) {
					max=b;
				}
				else {
					max=d;
				}
			}
			else {
				if(c>=d) {
					max=c;
				}
				else {
					max=d;
				}
			}
		}
		
		return max;
	}
	
	

}
