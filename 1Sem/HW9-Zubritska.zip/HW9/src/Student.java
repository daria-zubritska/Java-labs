import acm.util.RandomGenerator;

/*
 * Написати клас, який описує студента НаУКМА використовуючи наступні елементи:

змінні екземпляра
змінні класу
public і private методи
javadoc
toString

Та клас який використовує клас Student.
 * 
File: Student.java
Author:Zubritska
 * 
 */

/**
 * Створює профайл студента
 * @author Daria Zubritska
 */
public class Student {
	private static RandomGenerator rgen = RandomGenerator.getInstance(); 
	
	
	private boolean isOnlineStudy;
	public String name;
	private int year;
	private boolean isHomeWorkDone;
	
	 /** 
     * Повертає чи навчається студент онлайн або офлайн
     */	
	public boolean isOnline(){
		
		return isOnlineStudy;
	}
	
    /** 
     * Створює профайл студента
     * @param name - повне ім'я студента
     */	
	public Student(String name){
		this.name = name;
		this.isOnlineStudy= rgen.nextBoolean();
		this.year=rgen.nextInt(1,4);
		this.isHomeWorkDone= rgen.nextBoolean();
	}
	
	/**
	 * Виводить іеформацію про студента та спосіб його навчання
	 */
	public String toString() {
	
		String status = "offline";
		String homeworkStatus = "";
		if(this.isOnlineStudy) {
			status = "online";
			
			String homeWork = "не здано";
			if(this.isHomeWorkDone) {
				homeWork = "здано";
			}
			
			homeworkStatus = " домашнє завдання" + homeWork;
		}

		return "Судент " + this.name + " курс " + this.year + " навчається " + status + homeworkStatus;
	}
	
}
