/*
 * розкладі рейсів літаків дні тижня позначаються номерами від 1 до 7.
 *  Припустимо, що в програмі дні тижня подаються enum типом Weekd.
 *   Написати програму, що у відповідь на введення номера дня виводить
 *    текстове подання дня тижня.
 * 
 * File: Second.java
 * Author: Zubritska
 * 
 * */


import acm.graphics.*;
import acm.program.*;
import acm.util.*;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;



public class Second extends ConsoleProgram {
	
	public enum Week {MONDAY(1), TUESDAY(2), WEDNESDAY(3), THURSDAY(4), FRIDAY(5), SATURDAY(6), SUNDAY(7);
		private int dayNumber;
		Week(int dayNumber){
			this.dayNumber = dayNumber; 
		}
		public int getDayNumber() {
			return this.dayNumber;
		}
		}
	
	public void run() {
		int n = readInt();
		
		for(int i = 0; i < Week.values().length; i++) {
			Week week = Week.values()[i];
			if(week.getDayNumber() == n) {
				println(week.toString());	
			}
			
		}
	}
}
