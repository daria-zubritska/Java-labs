/*
 * Написати программу, що робить перевірку, чи є значення символьної змінної, що введена з клавіатури: 
цифрою від '0' до '9';
малою латинською літерою;
латинською літерою (великою чи малою)

File: First.java
Author: Zubritska
 * */

import acm.graphics.*;
import acm.program.*;
import acm.util.*;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;


public class First extends ConsoleProgram {
	
	public void run() {
		String us = readLine("Введіть один символ:");
		char user = us.charAt(0);
		indicate(user);
		
	}
	
	private void indicate(char user) {
		
		if(Character.isLetter(user) && (('A' < user && user <'Z') || ('a' < user && user < 'z'))) {
			println("Це латинська літера");
			if(Character.isUpperCase(user)) {
				println("Велика латинська літера");
			}
			else {
				println("Маленька латинська літера");
			}
		}
		else if(Character.isDigit(user)){
			
			println("Це цифра від 0 до 9");
		}
		else {
			println("Це символ або кирилиця");
		}
		
	}
}