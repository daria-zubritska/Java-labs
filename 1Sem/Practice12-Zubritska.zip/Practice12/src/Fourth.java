/*Написати "найпростіший калькулятор", 
 * що отримує на вхід 2 числа і операцію над ними після чого повертає результат обчислень.
 * 
 * File:Fourth.java
 * Author:Zubriska
 * 
 * */

import acm.graphics.*;
import acm.program.*;
import acm.util.*;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;


public class Fourth extends ConsoleProgram {
	
	public void run() {
		double a = readDouble("Введіть перше число: ");
		double b = readDouble("Введіть друге число: ");
		
		String sign = readLine("Введіть операцію над цими числами: ");
		
		char sig = sign.charAt(0);
		
		double result=0;
		if(sig == '+') {
			result = a+b;
		}
		else if(sig == '-') {
			result = a-b;
		}
		else if(sig == '*') {
			result = a*b;
		}
		else if(sig == '/') {
			result = a/b;
		}
		
		println("Результат: "+result);
	}
}
