/*Написати процедуру обчислення за цілим N>3 таких натуральних A і B, що 5A-2B=N, 
 * причому A+B мінімально.
 * 
 * File: Fifth.java
 * Author: Zubritska
 * */

import acm.graphics.*;
import acm.program.*;
import acm.util.*;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;


public class Fifth extends ConsoleProgram {
	
	public void run() {
		int N = readInt("Введіть N: ");
		int A = 0;
		int B = 0;
		
		while(N<=3) {
			N = readInt("Введіть N>3: ");
		}
		
		int min = 250;
		int minA = 0;
		int minB = 0;
		
		while(B<50) {
			while(A<50) {
				int result = 5*A-2*B;
				if(result == N) {
					if(A+B < min) {
						min = A+B;
						minA = A;
						minB = B;
					}
				}
				A++;
			}
			A=0;
			B++;
		}
		if(minA==0 && minB==0) {
			println("Розв'язку немає");
		}
		else {
			println("A="+minA+" "+"B="+minB);
		}
		
	}
}
