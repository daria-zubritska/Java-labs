/*
 * За понеділком іде вівторок тощо, а за неділею – понеділок. 
 * Написати функцію обчислення за днем тижня (типу Weekd) наступного за ним дня.
 * 
 * File: Third.java
 * Author: Zubritska
 * */


import acm.graphics.*;
import acm.program.*;
import acm.util.*;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;


public class Third extends ConsoleProgram {
	
	public enum Week {MONDAY(1), TUESDAY(2), WEDNESDAY(3), THURSDAY(4), FRIDAY(5), SATURDAY(6), SUNDAY(7);
		private int dayNumber;
		Week(int dayNumber){
			this.dayNumber = dayNumber; 
		}
		public int getDayNumber() {
			return this.dayNumber;
		}
		public Week getNext() {
		return (this.ordinal() < Week.values().length - 1) ? Week.values()[this.ordinal() + 1]: Week.values()[0];
	}
	}
	
	public void run() {
		while(true) {
			int n = readInt();
	
			for(int i = 0; i < Week.values().length; i++) {
				Week week = Week.values()[i];
				if(week.getDayNumber() == n) {
					println(week.getNext());	
				}
				
			}
		}
	}
}
