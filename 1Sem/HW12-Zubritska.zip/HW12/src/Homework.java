/*Написати програму, що зчитує з клавіатури стрічку і повертає (кожен пункт оформити у вигляді методу)

кількість слів (в слові можуть зустрічатися: тільки літери; тільки символи; літери+символи+цифри; літери+символи; літери+цифри; символи(окрім крапки та коми)+цифри; якщо відділені пропусками символи цифри, або цифри та кома чи крапка, то даний ланцюжок є числом)
кількість чисел
стрічку в якій прибрані усі символи крім літер
стрічку в якій множинні проміжки перетворені в один проміжок ("А   пр" ="А пр")
стрічку яка містить лише слова, що починаються з великої літери ("А   пр" ="А")
 * 
 * 
 File: Homework.java
Author:Zubritska
 * 
 */


import acm.program.*; 
import acm.graphics.*; 
import java.lang.Math;
import acm.util.*;
import java.awt.*; 
import java.awt.event.*; 

public class Homework extends ConsoleProgram {
	public void run() {
		
		String sample = readLine();
		
		//кількість слів 
		int result1 = quantityWords(sample);
		println("Кількість слів:"+result1);
		
		//кількість чисел 
		int result2 = quantityNum(sample);
		println("Кількість чисел:"+result2);
		
		//стрічку в якій прибрані усі символи крім літер
		String result3 = RemoveSymbols(sample);
		println("Стрічка в якій прибрані усі символи крім літер:"+result3);
		
		
		//множинні проміжки в один
		String result4 = leaveOneSpace(sample);
		println("Множинні проміжки в один:"+result4);
		
		//лише слова з великої літери
		String result5 = UpperCase(sample);
		println("Лише слова з великої літери:"+result5);
		
	}

	private int quantityWords(String sample) {
		
		int result = 0;
		
		boolean isFirstLetterFound = false;
		boolean isProbablyWord = false;
		
		for(int i = 0; i < sample.length(); i++) {
			
			char currentChar =  sample.charAt(i);
			
			if(isFirstLetterFound == false && !Character.isSpaceChar(currentChar)) {
				isFirstLetterFound = true;

				if(!(Character.isDigit(currentChar) || currentChar == ',' || currentChar == '.')) {
					isProbablyWord = true;
				}
				
			}else{
				if(isFirstLetterFound) {

					if(isProbablyWord == false 
							&& !(Character.isDigit(currentChar) || currentChar == ',' || currentChar == '.')
							&& !Character.isSpaceChar(currentChar)) {
						isProbablyWord = true;
					}
			
					
					if(Character.isSpaceChar(currentChar) || i == sample.length()-1){
						if(isProbablyWord) {
							result++;
							isFirstLetterFound = false;
							isProbablyWord = false;
						}
						else if(!isProbablyWord){
							isFirstLetterFound = false;
						}
					}
					
				}
			}
		}
		
		return result;
	}
	
	private int quantityNum(String sample) {
		
		int result = 0;
		
		boolean isFirstLetterFound = false;
		boolean isProbablyWord = false;
		
		for(int i = 0; i < sample.length(); i++) {
			
			char currentChar =  sample.charAt(i);
			
			if(isFirstLetterFound == false && !Character.isSpaceChar(currentChar)) {
				isFirstLetterFound = true;

				if(!(Character.isDigit(currentChar) || currentChar == ',' || currentChar == '.')) {
					isProbablyWord = true;
				}
				
			}else{
				if(isFirstLetterFound) {

					if(isProbablyWord == false 
							&& !(Character.isDigit(currentChar) || currentChar == ',' || currentChar == '.')
							&& !Character.isSpaceChar(currentChar)) {
						isProbablyWord = true;
					}
			
					
					if(Character.isSpaceChar(currentChar) || i == sample.length()-1){
						if(isProbablyWord) {
							isFirstLetterFound = false;
							isProbablyWord = false;
						}
						else if(!isProbablyWord){
							result++;
							isFirstLetterFound = false;
						}
					}
					
				}
			}
		}
		return result;
	}

	private String RemoveSymbols(String sample) {
		
		String result = new String();
		
		for(int i = 0; i < sample.length(); i++) {
			
			char currentChar =  sample.charAt(i);
			
			
			if(Character.isLetter(currentChar) || Character.isSpaceChar(currentChar)) {
				result += currentChar;
			}
		}
		
		return result;
	}
	
	private String leaveOneSpace(String sample) {
		
		String result = sample;
		
		do {
			result = result.replace("  ", " ");
		}
		while(result.indexOf("  ") >= 0);

		return result;
	}
	
	private String UpperCase(String sample) {
		
		String result = new String();
		
	
		boolean isFirstUpperLetterFound = false;
		
		for(int i = 0; i < sample.length(); i++) {
			
			char currentChar =  sample.charAt(i);
			
			if(isFirstUpperLetterFound == false && Character.isLetter(currentChar) && Character.isUpperCase(currentChar)) {
				isFirstUpperLetterFound = true;
				
				result += currentChar;
			}else{
				
				if(isFirstUpperLetterFound == true) {
					result += currentChar;
					if(Character.isSpaceChar(currentChar)) {
						isFirstUpperLetterFound = false;
					}
				}
				
			}
		}
		
		return result;
	}
}
