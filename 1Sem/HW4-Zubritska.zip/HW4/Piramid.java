/*
 Карелу необхідно побудувати піраміду з біперів. Основою для піраміди є ширина всього світу.

Світ може бути будь-якої ширини. Кількість вулиць не парна.

Керол може закінчити роботу програми в будь-якій позиції.

file: Piramid.java
Author:Zubritska
 */

import stanford.karel.*;

public class Piramid extends SuperKarel{

	public void run(){
		fillFirstRow();
		changeRow();
		if(facingEast()) {
		fillSecondRow();
		while(true) {
			changeRow();
			if(notFacingEast()) {
				turnAround();
				break;
				}
			fillAccordingTo();
			if(notFacingEast()) {
				turnAround();
				break;
			}
		}
		}
		else {
			turnAround();
		}
	}
	
	private void fillFirstRow() {
		while(frontIsClear()) {
			putBeeper();
			move();
		}
		putBeeper();
	}
	
	private void changeRow() {
		turnLeft();
		if(frontIsClear()) {
		move();
		turnLeft();
		if(frontIsClear()) {
			move();
		while(true) {
			checkDown();
			if(beepersPresent()) {
				move();
				turnLeft();
				if(frontIsClear()) {
					move();
				}
				else {
					break;
				}
			}
			else {
				move();
				turnLeft();
				stepBack();
				break;
			}
		}
		turnAround();
		}
		}
		else {
			turnLeft();
			}
	}
	
	private void fillAccordingTo() {
		move();
		while(true) {
			checkDownToFill();
			if(beepersPresent()) {
				move();
				turnRight();
				putBeeper();
				move();
			}
			else {
				move();
				turnLeft();
				move();
				if(beepersPresent()) {
					pickBeeper();
					turnAround();
				}
				break;
			}
		}
	}
	
	private void checkDown() {
		turnLeft();
		move();
		turnAround();
	}
	
	private void fillSecondRow() {
		move();
		while(frontIsClear()) {
			putBeeper();
			move();
		}
	}
	
	private void stepBack() {
		turnAround();
		move();
		turnAround();
	}
	
	private void checkDownToFill() {
		turnRight();
		move();
		turnAround();
	}
}
