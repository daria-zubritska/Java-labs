/*
 * Намалювати різнокольоровий будинок в якого будуть:
вікна
двері
криша
димоход
дим
 * file: House.java
 * Author: Zubritska
 */

import java.awt.Color;
import acm.graphics.*;
import acm.program.*;
import java.awt.*;

public class House extends GraphicsProgram{

	public void run(){
		this.setSize(500, 600);
		sky();
		fundament();
		door();
		windows();
		roof();
		chimney();
		grass();
	}
		private void fundament() {
			GRect fundament = new GRect(150,150,200,170);
			fundament.setFilled(true);
			fundament.setColor(Color.DARK_GRAY);
			fundament.setFillColor(Color.DARK_GRAY);
			add(fundament);
		}
		
		private void door() {
			GRect door = new GRect(150,220, 50, 100);
			door.setFilled(true);
			door.setFillColor(Color.BLUE);
			door.setColor(Color.black);
			add(door);
		
			GLine handle = new GLine(180,280,190,280);
			add(handle);
		}
		
		private void windows() {
			GRect window1 = new GRect(220,230,50,50);
			window1.setFilled(true);
			window1.setFillColor(Color.CYAN);
			window1.setColor(Color.black);
			add(window1);
		
			GRect window2 = new GRect(280,230,50,50);
			window2.setFilled(true);
			window2.setFillColor(Color.CYAN);
			window2.setColor(Color.black);
			add(window2);
		
			GLine window1Cross = new GLine(220,255,270,255);
			add(window1Cross);
		
			GLine window2Cross = new GLine(280,255,330,255);
			add(window2Cross);
		}
		
		private void roof() {
			int roofX1;
			int roofX2;
			roofX1=110;
			roofX2=150;
			for(int i=0; i<200; i++) {
				roofX1++;
				roofX2++;
				GLine roofLeft = new GLine(roofX1, 210,roofX2,120);
				roofLeft.setColor(Color.ORANGE);
				add(roofLeft);
			}
		
			roofX1=390;
			roofX2=350;
			for(int i=0; i<200; i++) {
				roofX1--;
				roofX2--;
				GLine roofLeft = new GLine(roofX1, 210,roofX2,120);
				roofLeft.setColor(Color.ORANGE);
				add(roofLeft);
			}
	}
		
		private void chimney() {
			GRect chimney = new GRect(310,100, 30,50);
			chimney.setFilled(true);
			chimney.setFillColor(Color.DARK_GRAY);
			add(chimney);
			
			GOval smoke1 = new GOval(315,70,30,20);
			smoke1.setFilled(true);
			smoke1.setFillColor(Color.GRAY);
			add(smoke1);
			
			GOval smoke2 = new GOval(335,50,60,20);
			smoke2.setFilled(true);
			smoke2.setFillColor(Color.GRAY);
			add(smoke2);
			
			GOval smoke3 = new GOval(355,10,90,30);
			smoke3.setFilled(true);
			smoke3.setFillColor(Color.GRAY);
			add(smoke3);
		}
		
		private void grass() {
			int grassX;
			grassX=0;
			for(int i=0;i<600;i++) {
				GLine grass = new GLine(grassX,310,grassX,330);
				grass.setColor(Color.green);
				add(grass);
				grassX+=3;
			}
			grassX=1;
			for(int i=0;i<599;i++) {
				GLine grass = new GLine(grassX,315,grassX,335);
				grass.setColor(Color.green);
				add(grass);
				grassX+=3;
			}
		}
		
		private void sky(){
			GRect sky = new GRect(0,0,500,315);
			sky.setFilled(true);
			sky.setFillColor(Color.cyan);
			add(sky);
		}
}
