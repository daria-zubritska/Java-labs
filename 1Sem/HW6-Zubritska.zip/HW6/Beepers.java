/*
*Написати програму, що намалює стовпчики з біперів через кожні 50(або інше задане число) пікселів. Кольори біперів чергуються. Висота кожного наступного стовпчика більша за попередню на 2(або інше задане число) біперів. Розмір біперів 50х50 (або інше задане число).

Біпер робити з чотирьох ліній.

Використати: константи, цикли.

File:Chekerboard.java
Author:Zubritska
 */

import java.awt.Color;
import acm.graphics.*;
import acm.program.*;
import java.lang.Math;

public class Beepers extends GraphicsProgram{
	private static final int GAP=50;
	private static final int BEEPSIZE=40;
	private static final int WINDOWX=700;
	private static final int WINDOWY=800;
	private static final int YMINUS=66;
	private static final int XMINUS=2;
	
	public void run(){
		this.setSize(WINDOWX,WINDOWY);
		double xNot0=Math.sqrt((Math.pow(BEEPSIZE, 2)/2));
		double yNot0=WINDOWY-YMINUS-Math.sqrt((Math.pow(BEEPSIZE, 2)/2));
		
		beeper(xNot0,yNot0);
	}
	
	
	private void drawBeeper(double xNot0, double yNot0,  int i, int j, Color color) {
		
		double x11=i*(2*xNot0+GAP);
		double y11=yNot0-j*(GAP+xNot0*2);
		double x12=xNot0+i*(2*xNot0+GAP);
		double y12=WINDOWY-YMINUS-j*(GAP+xNot0*2);
		double x21=xNot0+i*(2*xNot0+GAP);
		double y21=yNot0-xNot0-j*(GAP+xNot0*2);
		double x22=xNot0+xNot0+i*(2*xNot0+GAP);
		double y22=WINDOWY-YMINUS-xNot0-j*(GAP+xNot0*2);

		double cx11 = x11;
		double cy11 = y11;
		double cx12 = x12;
		double cy12 = y12;
		
		while(true) {
			GLine colorLine = new GLine(cx11,cy11,cx12,cy12);
			colorLine.setColor(color);
			add(colorLine);
			cx11+=0.01;
			cy11-=0.01;
			cx12+=0.01;
			cy12-=0.01;
			
			if((cx11 >= x21) ||  (cy11 <= y21) || (cx12 >= x22) || (cy12 <= y22)) {
				break;
			}
		}
		
		GLine leftDown = new GLine(x11,y11,x12,y12);
		add(leftDown);
		GLine rightUp = new GLine(x21,y21,x22,y22);
		add(rightUp);
		GLine leftUp = new GLine(x11,y11,x21,y21);
		add(leftUp);
		GLine rightDown = new GLine(x12,y12,x22,y22);
		add(rightDown);
		
	}
	
	private void beeper(double xNot0,double yNot0) {
		
		for(int i=0;(i+1)*(2*xNot0+GAP)<WINDOWX;i++) {

			for(int j=0;j<=2*i;j++) {
				int r;
				int g;
				
				r=i*30;
				g=j*20;
				if(r>255) r=0;
				if(g>255) g=0;

				Color c = new Color(r, g, 0);
				
				drawBeeper(xNot0, yNot0, i, j, c);

				if((j+1)*(GAP+xNot0*2)>=WINDOWY-YMINUS) {
					break;
				}
			 }

		}
	}
}
