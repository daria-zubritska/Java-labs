/*
 * Написати програму, що намалює шахову доску.

Використати: константи, цикли.

File:Chekerboard.java
Author:Zubritska
 */

import java.awt.Color;
import acm.graphics.*;
import acm.program.*;

public class Checkerboard extends GraphicsProgram{
	private static final int ROWS = 4;
	private static final int COLUMNS = 4;
	private static final int WINDOWX = 400;
	private static final int WINDOWY = 400;
	
	public void run(){
		int sqSizeX=(WINDOWX-30)/COLUMNS;
		int sqSizeY=(WINDOWY-67)/ROWS;
		this.setSize(WINDOWX,WINDOWY);

		for (int i = 0; i<ROWS; i++){
			for (int j = 0; j<COLUMNS; j++){
				int x = j*sqSizeX;
				int y = i*sqSizeY;
				GRect sq = new GRect(x,y,sqSizeX,sqSizeY);
				sq.setFilled(((i+j)%2)!=0);
				add(sq);
			}
		}
	}
	
}
