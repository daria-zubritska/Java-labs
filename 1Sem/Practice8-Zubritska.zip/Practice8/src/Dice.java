/*Написати програму, що дозволяє двом гравцям, грати в кості. Кількість кубиків, що кидає кожен гравець визначається на початку гри. Кількість сторін у кубика також задається на початку гри.

За бажанням гра може тривати визначену кількість кроків, або питається у гравців після кожного ходу.

В кінці має бути визначений переможець.
 
File: Dice.java
Author:Zubritska
 * 
 */


import acm.program.*;
import java.lang.Math;
import acm.util.*;


public class Dice extends ConsoleProgram{
	private RandomGenerator rgen = RandomGenerator.getInstance(); 

	
	public void run(){
		int sides = readInt("Задайте кількість сторін на кубиках:");
		int playerOneDices = readInt("Кількість кубиків першого гравця:");
		int playerTwoDices = readInt("Кількість кубиків другого гравця:");
		println("1- задати кількість раундів, 2- грати доки не буде введено 0");
		int mode = readInt("Обрати режим: ");
		
		do {
			if(mode==1) {
				int nRounds=readInt("Ввести кількість раундів:"); 
				playTheGameOne(nRounds,playerOneDices,playerTwoDices,sides);
				break;
			}
			else {
				if(mode==2) {
					playTheGameTwo(playerOneDices,playerTwoDices,sides);
					break;
				}
				else {
					mode = readInt("Обрати режим: ");
				}
			}
		}while(true);
		
	}
	
	private void playTheGameOne(int nRounds, int playerOneDices, int playerTwoDices, int sides) {
		int playerOneCount=0;
		int playerTwoCount=0;
		
		for(int i=0; i<nRounds; i++) {
			for(int j=0;j<playerOneDices;j++) {
				playerOneCount=playerOneCount+rgen.nextInt(1,sides);
			}
			println("Раунд "+(i+1)+" Рахунок першого гравця: "+playerOneCount);
			
			for(int j=0;j<playerOneDices;j++) {
				playerTwoCount=playerTwoCount+rgen.nextInt(1,sides);
			}
			println("Раунд "+(i+1)+" Рахунок другого гравця: "+playerTwoCount);
		}
		
		if(playerOneCount>playerTwoCount) {
			println("Виграв номер 1");
		}
		else {
			if(playerOneCount<playerTwoCount) {
				println("Виграв номер 2");
			}
			else {
				println("Нічия");
			}
		}
	}
	
	private void playTheGameTwo(int playerOneDices, int playerTwoDices, int sides) {
		int playerOneCount=0;
		int playerTwoCount=0;
		int end = 1;
		int i=0;
		
		while(end!=0) {
			
			for(int j=0;j<playerOneDices;j++) {
				playerOneCount=playerOneCount+rgen.nextInt(1,sides);
			}
			println("Раунд "+(i+1)+" Рахунок першого гравця: "+playerOneCount);
			
			for(int j=0;j<playerOneDices;j++) {
				playerTwoCount=playerTwoCount+rgen.nextInt(1,sides);
			}
			println("Раунд "+(i+1)+" Рахунок другого гравця: "+playerTwoCount);
			
			i++;
			end = readInt("Введіть 0, щоб завершити:");
		}
		if(playerOneCount>playerTwoCount) {
			println("Виграв номер 1");
		}
		else {
			if(playerOneCount<playerTwoCount) {
				println("Виграв номер 2");
			}
			else {
				println("Нічия");
			}
		
		}
	}
}
