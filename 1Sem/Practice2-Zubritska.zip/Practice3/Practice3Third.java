import stanford.karel.*;

public class Practice3Third extends SuperKarel{

	public void run(){
		
		while(true) {
			
		if(leftIsBlocked()) {
			turnRight();
			while(frontIsClear()) {
				if(noBeepersPresent()) {
					putBeeper();
				}
				move();
			}
		}
		else {
			turnLeft();
			
			while(frontIsClear()) {
				move();
				}
			
			turnAround();
			
			while(frontIsClear()) {
				if(noBeepersPresent()) {
					putBeeper();
				}
				
				move();
		}
		}
		
		turnLeft();
		if(noBeepersPresent()) {
			putBeeper();
		}
		
		if(frontIsClear()) {
			for(int i=0; i<4; i++) {
				move();
			}
		}
		else {
			break;
		}
		}
	}


	}
