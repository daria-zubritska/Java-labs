import stanford.karel.*;

public class Practice3First extends SuperKarel{

	public void run(){
		
		putBeeper();
		turnLeft();
		move();
		putBeeper();
		move();
		putBeeper();
		move();
		putBeeper();
		move();
		putBeeper();
		move();
		putBeeper();
		move();
		putBeeper();
		turnLeft();
		turnLeft();
		turnLeft();
		move();
		putBeeper();
		move();
		turnLeft();
		turnLeft();
		turnLeft();
		move();
		putBeeper();
		move();
		turnLeft();
		move();
		putBeeper();
		turnLeft();
		turnLeft();
		turnLeft();
		move();
		putBeeper();
		move();
		putBeeper();
		move();
		turnLeft();
		turnLeft();
		turnLeft();
		move();
		putBeeper();
		move();
		turnLeft();
		move();
		putBeeper();
		turnLeft();
		turnLeft();
		turnLeft();
		move();
		turnLeft();
		turnLeft();
	}
}
