import stanford.karel.*;

public class HW3First extends SuperKarel{

	public void run(){ //not done
		putBeeper();
		
		while(true) {
			stepOne();
			stepTwo();
			
			if(frontIsBlocked()) {
				if(facingEast()) {
					if(leftIsBlocked())
					{
						break;
					}
				}
				else {
					if(rightIsBlocked())
					{
						break;
					}					
				}
			}
		}

	}
	
	private void stepOne() {
		
		if(frontIsBlocked()) {
			if(facingEast()) {
				if(leftIsClear()) {
					turnLeft();
					move();
					turnLeft();
				}
			}
			else {
				if(rightIsClear()) {
					turnRight();
					move();
					turnRight();
				}
			}		
		}
		else {
			move();
		}
	}
	
	private void stepTwo() {
		
		if(frontIsBlocked()) {
			if(facingEast()) {
				if(leftIsClear()) {
				turnLeft();
				move();
				turnLeft();
				putBeeper();
				}
			}
			else {
				if(rightIsClear()) {
				turnRight();
				move();
				turnRight();
				putBeeper();
				}
			}		
		}
		else {
			move();
			putBeeper();
		}
	}
}
