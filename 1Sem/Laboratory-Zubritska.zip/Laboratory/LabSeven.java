/*
 * Послідовність сум {sn}, де sn=1+x+x^2/2!+…+x^n/n!, за умови 0<=x<1 "достатньо швидко"
 *  сходиться до ex. Запрограмувати обчислення ex при x [0;1) із точністю ep , тобто
 *   за потрібне число приймається перше sn таке, що | sn-sn-1 |<ep .
 * 
 * 
 * File: LabSeven.java
 * Author:Zubritska
 */

import acm.program.*;
import java.lang.Math;
import acm.util.*;


public class LabSeven extends ConsoleProgram{

	public void run(){
		double ep=readDouble("Введіть епсілон:");
		double x=readDouble("Введіть x:");
		while(x>=1||x<0) {
			x=readDouble("Введіть значення x [0;1):");
			
		}
		
		println("e^x="+myCalc(x,ep));
		
	}
	
	public double factorial(double I) {
        if (I > 1) {
            return I * factorial(I - 1);
        } else {
            return 1;
        }
    }

    public double mult(double myX, double myE) {
        double result = myX;
        if (myE == 0) {
            result = 1;
        }
        
        for (int i = 1; i < myE; i++) {
            result *= myX;
        }
        return result;
    }

    public double myCalc(double myX, double ep) {

    	double sum = 0;
        double lastSum = 1;

        int i = 0;
        int limit = 100;
        
        double acc = 0;
        double result = 0;
        do {
        	
        	result = mult(myX,i) / factorial(i);
        	
        	println("resul i" + i + " :" + result);
        	
        	sum  += result;
        	acc = Math.abs(sum - lastSum);
        	
        	println("Step " + i + " - Sn: " + sum + " Sn-1: " + lastSum + "  Accuracity: " + acc );
        	
        	i++;
        	lastSum = sum;
        }while(acc < ep && i < limit);
        
        sum  -= result;

        return sum;
    }
}