/*
 * Написати програму, що зчитує з клавіатури цілі числа (по одному числу за раз),
 *  поки користувач не введе число 0 (ви маєте бути в змозі легко поміняти цю 
 *  умову на якесь інше число). По закінченню вводу ваша програма має вивести
 *   найменше і найбільше число.

Якщо користувач введе лише одне число, програма має повідомити що це число і
 найбільше і найменше
Якщо користувач в першій же стрічці введе символ закінчення вводу, тоді
 вважається, що жодного числа не було введено і програма має це повідомити.
 
 * File: LabFive.java
 * Author:Zubritska
 */

import acm.program.*;
import java.lang.Math;
import acm.util.*;


public class LabFive extends ConsoleProgram{

	public void run(){
		
		int max =0;
		int min =0;
		boolean firstNum = true;
		
		do {
			int current = readInt("?");
			
			if(current !=0 ) {
			
				if(firstNum) {
					min = current;
					max = current;
					
					firstNum =false;
				}
				else {
				
					if(max<current) max=current;
			
					if(min>current) min=current;
				}
			}
			else {
				break;
			}
			
		}while(true);
		
	if(min!=0) {
		println("Максимальне значення:"+max);
		println("Мінімальне значення:"+min);
	}
	else {
		println("Ви не ввели жодного значення");
	}

	}
}
