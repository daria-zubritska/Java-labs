/*Напишіть програму що малює піраміду. Піраміда складається з горизонтальних рядів цеглин. 
 * В кожному наступному ряду кількість цеглин зменшується на один.
 * Піраміда має розташовуватися по центру горизонталі вікна. 
 * Мають бути використані наступні константи:

BRICK_WIDTH - 30 пікселів
BRICK_HEIGHT - 12 пікселів
BRICKS_IN_BASE - 14
 * 
 * File: LabOne.java
 * Author:Zubritska
 */

import acm.program.*;
import java.lang.Math;
import acm.graphics.*;
import acm.program.*;


public class LabOne extends GraphicsProgram{
	
	private static final int BRICK_WIDTH=30;
	private static final int BRICK_HEIGHT=12;
	private static final int BRICKS_IN_BASE=14;
	private static final int WORLDX=1000;
	private static final int WORLDY=500;

	public void run(){
		this.setSize(WORLDX,WORLDY);
		
		build();
	}
	
	private void build() {
		int firstBrickX=WORLDX/2-((BRICK_WIDTH*BRICKS_IN_BASE)/2);
		int firstRowY=WORLDY-63-BRICK_HEIGHT;
		int base=BRICKS_IN_BASE;
		
			for(int j=0;base>=1; j++) {
				
				int BrickX=firstBrickX+j*(BRICK_WIDTH/2);
				int RowY=firstRowY-j*BRICK_HEIGHT;
				
			for(int i=0; i<base;i++) {
				add(new GRect(BrickX+i*BRICK_WIDTH,RowY,BRICK_WIDTH,BRICK_HEIGHT));
			}
			
			base--;
			}

	}

}
