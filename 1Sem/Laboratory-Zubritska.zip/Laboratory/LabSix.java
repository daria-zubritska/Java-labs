/*
 * Опис алгоритму:

візьміть позитивне ціле число, назвемо його n
якщо n парне, поділимо його на 2
якщо n не парне, помножимой його на 3 і додамо 1
продовжувати цей процес поки n не буде дорівнювати 1
Напишіть програму, що реалізує вказаний алгоритм і наочно проілюструє його виконання.
 В кінці обов'язково повідомити кількість кроків.
 * 
 * 
 * File: LabSix.java
 * Author:Zubritska
 */

import acm.program.*;
import java.lang.Math;
import acm.util.*;


public class LabSix extends ConsoleProgram{

	public void run(){
		int n=readInt();
		
		toOne(n);
	}
	
	private void toOne(int n) {
		int i=0;
		do {
			if(n%2==0) {
				println(n+"/2="+n/2);
				n=n/2;
				i++;
			}
			else {
				println(n+"*3+1="+(n*3+1));
				n=n*3+1;
				i++;
			}
		}while(n!=1);
		println(i+" кроків");
				
	}
}
