/*
 * Ви маєте написати програму, що малює зображення "мішень для лучника".
 * Мішень має розташовуватися по центру вікна. Мають бути використані константи:

 

ширира світу;
висота світу;
кількість кругів.
 * 
 * File: LabTwo.java
 * Author:Zubritska
 */

import acm.program.*;

import java.awt.Color;
import java.lang.Math;
import acm.graphics.*;
import acm.program.*;



public class LabTwo extends GraphicsProgram{
	private static final int WORLDX=600;
	private static final int WORLDY=500;
	private static final int N_CIRCLES=6;
	private static final int RADIUS=20;

	public void run(){
		this.setSize(WORLDX,WORLDY);
		
		//is needed to see all the circles in case if there is pair quantity of them
		this.setBackground(Color.GRAY);
		
		build();
	}
	
	private void build() {
		for(int i=N_CIRCLES; i>0;i--) {
			GOval circle = new GOval(WORLDX/2-RADIUS-i*RADIUS,(WORLDY-63)/2-RADIUS-i*RADIUS,RADIUS+i*2*RADIUS,RADIUS+i*2*RADIUS);
			circle.setFilled(true);
			if(i%2==0) {
				circle.setColor(Color.WHITE);
				circle.setFillColor(Color.WHITE);
			}else {
				circle.setColor(Color.RED);
				circle.setFillColor(Color.RED);
			}
			
			add(circle);
		}
	}
}
