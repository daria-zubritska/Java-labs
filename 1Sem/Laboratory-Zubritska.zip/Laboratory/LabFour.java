/*Написати програму, що запитує у користувача два числа
 *  і обраховує корень квадратний з суми їх квадратів.
 *  
 * File: LabFour.java
 * Author:Zubritska
 */

import acm.program.*;
import java.lang.Math;

public class LabFour extends ConsoleProgram{

	public void run(){
		int a=readInt("a:");
		int b=readInt("b:");
		
		println("c="+Math.sqrt((Math.pow(a,2)+Math.pow(b, 2))));
		
	}
}
