/*
 * Послідовність сум {sn}, де sn=1-x^2/2!+…+(-1)^n*x^2n/(2n)!, за умови
 *  |x|<= p /4 "достатньо швидко" сходиться до cos(x).
 *   Запрограмувати обчислення cos(x) при x [-p /4; p/4] з точністю ep 
 *   , тобто за потрібне число приймається перше sn таке, що | sn-sn-1 |<ep .
 * 
 * 
 * File: LabEight.java
 * Author:Zubritska
 */

import acm.program.*;
import java.lang.Math;
import acm.util.*;

public class LabEight extends ConsoleProgram{
	private final static double PI=3.14;

	public void run(){
		
		double ep=readDouble("Введіть епсілон:");
		double x=readDouble("Введіть x:");
		while(x>PI/4||x<-PI/4) {
			x=readDouble("Введіть значення x [-p/4;p/4]:");
			
		}
		
		println("cos(x)="+myCalc(x,ep));
	}
	
	private double myCalc(double X, double ep) {
		double sum = 0;
        double lastSum = 1;

        int i = 0;
        int limit = 100;
        
        double acc = 0;
        double result = 0;
        do {
        	
        	result = mult(-1, i)*mult(X, 2*i) / factorial(2*i);
        	
        	println("result i" + i + " :" + result);
        	
        	sum  += result;
        	acc = Math.abs(sum - lastSum);
        	
        	println("Step " + i + " - Sn: " + sum + " Sn-1: " + lastSum + "  Accuracity: " + acc );
        	
        	i++;
        	lastSum = sum;
        }while(acc < ep && i < limit);
        
        sum  -= result;

        return sum;
	}
	
	public double factorial(double I) {
        if (I > 1) {
            return I * factorial(I - 1);
        } else {
            return 1;
        }
    }
	
	public double mult(double myX, double myE) {
        double result = myX;
        if (myE == 0) {
            result = 1;
        }
        
        for (int i = 1; i < myE; i++) {
            result *= myX;
        }
        return result;
    }
}
