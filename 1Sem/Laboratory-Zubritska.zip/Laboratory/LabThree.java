/*
 * Написати програму, що малює часткову діаграму класів acm.program, як показано в прикладі
 * Діаграма має розташовуватися по центру вікна.
 * 
 * File: LabThree.java
 * Author:Zubritska
 */

import acm.program.*;

import java.awt.Font;
import java.lang.Math;
import acm.graphics.*;
import java.lang.Object;


public class LabThree extends GraphicsProgram{
	private static final int WORLDX=600;
	private static final int WORLDY=400;

	public void run(){
		this.setSize(WORLDX,WORLDY);
		
		double WorldX=700;
		double WorldY=500;
		double difX=WORLDX/WorldX;
		double difY=WORLDY/WorldY;
		double cellX=150*difX;
		double cellY=70*difY;
		double indentX=20*difX;
		
		drawBorders(cellX,cellY,indentX);
		
		label(cellX,cellY,indentX, difX, difY);
		
		drawConnection(cellX,cellY,indentX);
	}
	
	private void drawBorders(double cellX, double cellY, double indentX) {
		
		GRect topCell = new GRect((WORLDX-cellX)/2, (WORLDY-4*cellY)/2, cellX, cellY);
		add(topCell);
		
		GRect middleCell = new GRect((WORLDX-cellX)/2, (WORLDY-4*cellY)/2+2*cellY, cellX, cellY);
		add(middleCell);
		
		GRect leftCell = new GRect((WORLDX-cellX)/2-cellX-indentX, (WORLDY-4*cellY)/2+2*cellY, cellX, cellY);
		add(leftCell);
		
		GRect rightCell = new GRect((WORLDX-cellX)/2+cellX+indentX, (WORLDY-4*cellY)/2+2*cellY, cellX, cellY);
		add(rightCell);
	}
	
	private void label(double cellX, double cellY, double indentX, double difX, double difY) {
		
		GLabel program = new GLabel("Program", ((WORLDX-cellX)/2+40*difX), (WORLDY-4*cellY)/2+40*difY);
		Font currentFont = program.getFont();
		int font = (int) (15*difX);
		Font newFont = new Font(currentFont.getFamily(), currentFont.getStyle(), font);
		println(currentFont);
		program.setFont(newFont);
		add(program);
		
		GLabel middle = new GLabel("GraphicsProgram", ((WORLDX-cellX)/2+17*difX), (WORLDY-4*cellY)/2+40*difY+2*cellY);
		middle.setFont(newFont);
		add(middle);
		
		GLabel left = new GLabel("ConsoleProgram", ((WORLDX-cellX)/2+17*difX-cellX-indentX), (WORLDY-4*cellY)/2+40*difY+2*cellY);
		left.setFont(newFont);
		add(left);
		
		GLabel right = new GLabel("DialogProgram", ((WORLDX-cellX)/2+17*difX+cellX+indentX), (WORLDY-4*cellY)/2+40*difY+2*cellY);
		right.setFont(newFont);
		add(right);
	}
	
	private void drawConnection(double cellX, double cellY, double indentX) {
		GLine toMiddle = new GLine((WORLDX-cellX)/2+cellX/2,(WORLDY-4*cellY)/2+cellY, (WORLDX-cellX)/2+ cellX/2,(WORLDY-4*cellY)/2+2*cellY );
		add(toMiddle);
		
		GLine toLeft = new GLine((WORLDX-cellX)/2+cellX/2,(WORLDY-4*cellY)/2+cellY, (WORLDX-cellX)/2-cellX/2-indentX,(WORLDY-4*cellY)/2+2*cellY );
		add(toLeft);
		
		GLine toRight = new GLine((WORLDX-cellX)/2+cellX/2,(WORLDY-4*cellY)/2+cellY, (WORLDX-cellX)/2+2*cellX-cellX/2+indentX,(WORLDY-4*cellY)/2+2*cellY );
		add(toRight);
	}
}
