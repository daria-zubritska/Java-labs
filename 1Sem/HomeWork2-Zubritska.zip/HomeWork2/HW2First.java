import stanford.karel.*;

public class HW2First extends SuperKarel{

	public void run(){
		
		while(noBeepersPresent()) {
		if(frontIsClear()) {
			move();
		}
		else {
			turnRight();
			move();
			turnLeft();
		}
		}
		
		pickBeeper();
		
		turnAround();
		
		while(frontIsClear()) {
			move();
		}
		
		turnRight();
		
		while(frontIsClear()) {
			move();
		}
		
		turnRight();
		
	}
}
