/*
1 метод, що 10 разів виводить на екран ім'я й прізвище.
2 метод, що виводить таблицю квадратів перших десяти цілих позитивних чисел.
3 метод, що виводить таблицю квадратів перших п'яти цілих позитивних непарних чисел.
4 метод, що обчислює суму перших n цілих позитивних цілих чисел. Кількість сумуємих чисел повинна вводитися під час роботи програми.
5 метод, що обчислює суму перших n членів ряду 1, 3, 5, 7, .... Кількість сумуємих чисел повинна вводитися під час роботи програми.
6 метод, що обчислює суму перших n членів ряду 1+1/2+1/3+1/4+...
7 метод, що виводить таблицю ступенів двійки (від нульової до десятої).
8 метод, що обчислює факторіал уведеного із клавіатури числа.
9 метод, що виводить таблицю значень функції y = -2,4х^2+5х-3 у діапазоні від -2 до 2 із кроком 0,5.
10 метод, що генерує 10 випадкових чисел у діапазоні від 1 до 10, виводить ці числа на екран й обчислює їх середнє арифметичне.
11 метод, що виводить на екран таблицю вартості, наприклад, яблук у діапазоні від 100 гм. до 1 кг із кроком 100.
12 метод перевірки вміння складати й віднімати числа в межах 100. Програма повинна вивести 10 прикладів, причому в кожному прикладі зменшуване повинне бути більше або дорівнює що віднімає, тобто не допускається пропонувати випробуваному приклади з негативним результатом. Оцінка виставляється за наступним правилом: за 10 правильних відповідей - "відмінно", за 9 й 8 -"добре", за 7 й 6 - "задовільно", за 5 і менш - "погано".
13 метод, що обчислює суму й середнє арифметичне послідовності позитивних чисел, які вводяться із клавіатури.
14 метод, що визначає максимальне число з уведеної із клавіатури послідовності позитивних чисел (довжина послідовності не обмежена).
15 метод, що перевіряє, чи є ціле число, уведене користувачем, простим.
16 метод, що "задумує" число в діапазоні від 1 до 100 і пропонує користувачеві вгадати число за 7 спроб. На кожному кроці комп'ютер повідомляє "більше" або "менше" загадане ним число відносно введеного користувачем.
File: methods.java
Author:Zubritska
 * 
 */


import acm.program.*;
import java.lang.Math;
import acm.util.*;

public class methods extends ConsoleProgram{
	private static RandomGenerator rgen = RandomGenerator.getInstance(); 

	public void run(){
		//1
		String name = readLine("Введіть ім'я:");
		nameTenTimes(name);
		
		//2
		println("квадрати перших десяти цілих позитивних чисел");
		tenFirstMult();
		
		//3
		println("квадрати перших п'яти цілих позитивних непарних чисел");
		fiveOddMult();
		
		//4
		int n=readInt("Введіть n:");
		sumN(n);
		
		//5
		int oddN=readInt("Введіть n:");
		sumOddN(oddN);
		
		//6
		int obN = readInt("Введіть n:");
		sumObN(obN);
		
		//7
		println("таблиця ступенів двійки (від нульової до десятої)");
		for(int i=0; i<11; i++) {
			int a =twoMult(i);
			println(i+"-"+a);
		}
		
		//8
		int factN=readInt("Введіть n:");
		int a = factorial(factN);
		println("Факторіал числа:"+a);
		
		//9
		println("Вирішення функції y = -2,4х^2+5х-3 у діапазоні від -2 до 2 із кроком 0,5");
		answers();
		
		//10
		println("Виводить десять рандомних чисел та шукає їх середнє арифметичне.");
		tenRandom();
		
		//11
		double cost = readDouble("Введіть вартість 100 грам: ");
		gramms(cost);
		
		//12
		println("Тестуємо вміння рахувати");
		test();
		
		//13
		println("Введіть 10 чисел: ");
		sumArif();
		
		//14
		println("Шукає найбільше. Потрібно ввести 0, щоб зупинити.");
		max();
		
		//15
		int simpN=readInt("Введіть цілe число:");
		simpleNumber(simpN);
		
		//16
		int x= rgen.nextInt(0, 100);
		println("Число загадане.");
		guessingTheNumber(x);
		
	}
	
	private void nameTenTimes(String name) {
		for(int i=0; i<10; i++) {
			println(name);
		}
	}
	
	private void tenFirstMult() {
		double n;
		for(int i=1; i<=10; i++) {
			n= Math.pow(i, 2);
			println(i+"-"+n);
		}
	} 
	
	private void fiveOddMult() {
		int n=0;
		int i=0;
		do {
			n++;
			if(n%2!=0) {
				i++;
				double a=Math.pow(n, 2);
				println(i+"-"+a);
			}
			
		}while(i<5);
	}
	
	private void sumN(int n) {
		int sum=0;
		for(int i=1; i<=n; i++) {
			sum= sum+i;
		}
		println("Сумма перших n чисел:"+sum);
	}
	
	private void sumOddN(int oddN) {
		int n=0;
		int i=0;
		int sum=0;
		
		do {
			n++;
			if(n%2!=0) {
				i++;
				sum=sum+n;
			}
			
		}while(i<oddN);
		
		println("Сума перших n непарних:"+sum);
	}
	
	private void sumObN(int obN) {
		double sum=0;
		for(double i=1; i<=obN; i++) {
			sum=sum+1/i;
		}
		println("Сумма перших n дробів:"+sum);
	}
	
	private int twoMult(int k) {
		int mult=2;
		if(k>0) {
			mult=mult*twoMult(k-1);
			return mult;
		}
		else{
			return 1;
		}
	}
	
	private int factorial(int n) {
		int fact=1;
		if(n>0) {
			fact=n*factorial(n-1);
			return fact;
		}
		else {
			return 1;
		}
	}
	
	private void answers() {
		double discriminant;
		double discriminantSqrt;
		
		for(double y=-2;y<=2; y +=0.5) {
			
			discriminant= Math.pow(5, 2)-(4*(-2.4)*(-3-y));
			discriminantSqrt = Math.pow(discriminant, 1.0/2);
			
			if(discriminantSqrt>0) {
				println("При y="+y+"х1="+((-5+discriminantSqrt)/(2*(-2.4))));
				println("х2="+((-5-discriminantSqrt)/(2*(-2.4))));
			}
			else {
				if(discriminantSqrt==0) {
					println("При y="+y+"х="+((-5+discriminantSqrt)/(2*(-2.4))));
				}
				else {
					println("При y="+y+" Немає розв'язків.");
				}
			}
		
		}
	}
	
	private void tenRandom() {
		double sum=0;
		
		for(int i=0; i<10; i++) {
			int r = rgen.nextInt(1,10);
			println((i+1)+"-"+r);
			sum +=r;
		}
		println("Середнє арифметичне: "+(sum/10));
	}
	
	private void gramms(double cost) {
		for(int i=100; i<=1000; i=i+100) {
			double newCost = cost*i/100;
			println(i+" грам - "+newCost+" грн");
		}
	}
	
	private void test() {
		int grade=0;
		int result=0;
		for(int i=0; i<10;i++) {
			
			int first=rgen.nextInt(0,100);
			int second=rgen.nextInt(0,100);
			
			boolean plusOrMinus = rgen.nextBoolean();
			
			if(plusOrMinus) {
				println(first+"+"+second+"=");
				result=first+second;
			}
			else {
				if(first>=second) {
					println(first+"-"+second+"=");
					result=first-second;
				}
				else {
					println(second+"-"+first+"=");
					result=second-first;
				}
			}
			
			int answer = readInt();
			
			if(result==answer) {
				grade++;
			}
		}
		
		if(grade==10) {
			println(grade+" відмінно");
		}
		else {
			if(grade==9||grade==8) {
				println(grade+" добре");
			}
			else {
				if(grade==7||grade==6) {
					println(grade+" задовільно");
				}
				else {
					println(grade+" погано");
				}
			}
		}
	}
	
	private void sumArif() {
		double sum = 0;
		for(int i=0;i<10;i++) {
			int n = readInt();
			
			sum += n;
		}
		println("Сумма: "+sum+" Середнє арифметичне: "+(sum/10));
	}
	
	private void max() {
		int max=0;
		
		do {
			int n=readInt();
			
			if(n>max) max=n;
			
			if(n==0) {
				break;
			}
		}while(true);
		
		println("max = "+ max);
		
	}
	
	private void simpleNumber(int n) {
		int k=0;
		for(int i=1; i<n; i++) {
			if(n%i==0) {
				if(n!=i&&i!=1) {
					k++;
				}
			}
			
		}
		if(k==0) {
			println("Число просте");
		}
		else {
			println("Число не просте");
		}
	}
	
	private void guessingTheNumber(int x) {
		int steps=0;
		do {
		int a=readInt();
		if(a==x) {
			steps++;
			println("Вірно!"+" Вам знадобилося "+steps+" спроб.");
			break;
		}
		else {
			if(a>x) {
				steps++;
				println("Менше.");
			}
			else {
				steps++;
				println("Більше.");
			}
		}
		if(steps==7) {
			println("Число не вгадане.");
			break;
		}
		}while(true);
		}
}
