/*Карел починає роботу з клітинки 1х1 обличчам на схід з необмеженою кількістю біперів
Початковий світ не містить ні стін ні біперів
Світ не повинен бути квадратним, але ви можете вважати, що він принаймні, такий же високий, як і широкий
Якщо довжина рядка непарна, тоді Карел має покласти біпер саме по центру, якщо парна тоді в одній з двох центральних клітин
Не має різниці в якому напрямку Карел дивиться в кінці.
 * 
 * File: Middle.java
 * Author: Zubritska
 */
import stanford.karel.*;

public class Middle extends SuperKarel{
	
	public void run(){
		while(true) {
		goToTheWall();
		if(noBeepersPresent()) {
			turnAround();
			putBeeper();
		}
		else {
			if(facingWest()) {
				turnAround();
			}
			break;
		}
		goToTheWall();
		if(noBeepersPresent()) {
			turnAround();
			putBeeper();
		}
		else {
			if(facingWest()) {
				turnAround();
			}
			break;
		}
		}
	}
	
	private void goToTheWall() {
		while(frontIsClear()) {
			move();
			if(beepersPresent()) {
				pickBeeper();
				moveBack();
				break;
			}
		}
		
	}
	
	private void moveBack() {
		turnAround();
		move();
		turnAround();
	}
}
