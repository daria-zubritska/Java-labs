/*
 * Написати програму, що відкриває файл на читання і формує два інших файли.
 *  Перший файл формується з непарних стрічок початкового файлу, а інший з парних.
 * 
 File: Hw3.java
Author:Zubritska
 * 
 */


import acm.program.*; 
import acm.util.*;
import java.io.*;

public class Hw3 extends ConsoleProgram {

	private BufferedReader openFile(String prompt){
		BufferedReader rd = null;
		while (rd == null){
			try{
				String name = readLine(prompt);
				rd = new BufferedReader( new FileReader(name));
			} catch (FileNotFoundException e){
				println("Файл не знайдено");
				
			} catch (IOException e){
				e.printStackTrace();
			}
			
		}
		return rd;
	}
		
		public void run(){
			BufferedReader myR = openFile("Введіть назву файлу: ");
			try {
				PrintWriter wr1 = new PrintWriter(new FileWriter("file1.txt"));
				PrintWriter wr2 = new PrintWriter(new FileWriter("file2.txt"));
				
				int row = 0;
				while (true){
					row++;
					String s;
					s = myR.readLine();
					if (s==null) break;
					println(s);
					if(row%2!=0) {
						wr1.println(s);
					}
					else {
						wr2.println(s);
					}
				}
				
				myR.close();
				wr1.close();
				wr2.close();
			}catch (IOException e) {
				throw new ErrorException(e);
			}
		}
}
