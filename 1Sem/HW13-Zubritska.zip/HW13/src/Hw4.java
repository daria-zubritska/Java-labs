/*
 * Здійснити шифрування файлу використовуючи зсув символів.
 * 
 File: Hw4.java
Author:Zubritska
 * 
 */


import acm.program.*; 
import acm.graphics.*; 
import java.lang.Math;
import acm.util.*;
import java.awt.*; 
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter; 

public class Hw4 extends ConsoleProgram {
	private final static int shift = 1;
	
	private BufferedReader myReader(String prompt){
		BufferedReader rd = null;
		while (rd == null){
			try{
				// read file name
				String name = prompt;
				rd = new BufferedReader( new FileReader(name));
			} catch (FileNotFoundException e){
				println("Файл не знайдено");
				
			} catch (IOException e){
				e.printStackTrace();
			}
			
		}
		return rd;
	}
	
	public void run() {
		String userName = readLine("Enter file name:");
		
		BufferedReader myR = myReader(userName);
		
		try {
			
			String fin = "";
			
			while (true){
				String s;
				s = myR.readLine();
				if (s==null) break;
				
		        String ciphertext = "";
		        char alphabet;
		        for(int i=0; i < s.length();i++) 
		        {
		            
		            alphabet = s.charAt(i);
		          
		            if(alphabet >= 'a' && alphabet <= 'z') 
		            {
		          
		             alphabet = (char) (alphabet + shift);
		            
		             if(alphabet > 'z') {
		               
		                alphabet = (char) (alphabet+'a'-'z'-1);
		             }
		             ciphertext = ciphertext + alphabet;
		            }
		            
		            
		            else if(alphabet >= 'A' && alphabet <= 'Z') {
		             
		             alphabet = (char) (alphabet + shift);    
		                
		             
		             if(alphabet > 'Z') {
		                 
		                 alphabet = (char) (alphabet+'A'-'Z'-1);
		             }
		             ciphertext = ciphertext + alphabet;
		            }
		            else {
		             ciphertext = ciphertext + alphabet;   
		            }
		        
		    }
		    println(s);  
		    println(" ciphertext : " + ciphertext);
		    
		    fin = ciphertext;
				
			}
			myR.close();
			
			PrintWriter wr = new PrintWriter(userName);
			wr.println(fin);
			wr.close();
			
		}catch (IOException e) {
			throw new ErrorException(e);
		}
		
	}
}
