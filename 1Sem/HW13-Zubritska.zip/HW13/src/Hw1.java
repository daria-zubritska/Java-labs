/*
 * Написати програму, що замінює підстрічку в файлі заданою стрічкою
 * 
 File: Hw1.java
Author:Zubritska
 * 
 */


import acm.program.*; 
import acm.util.*;

import java.io.*;

public class Hw1 extends ConsoleProgram {
	private BufferedReader myReader(String prompt){
		BufferedReader rd = null;
		while (rd == null){
			try{
				// read file name
				String name = prompt;
				rd = new BufferedReader( new FileReader(name));
			} catch (FileNotFoundException e){
				println("Файл не знайдено");
				
			} catch (IOException e){
				e.printStackTrace();
			}
			
		}
		return rd;
	}
	
	public void run() {
		String userName = readLine("Enter file name:");
		
		BufferedReader myR = myReader(userName);
		
		String user = readLine("Введіть слово, яке потрібно замінити:");
		
		String user2 = readLine("Введіть слово, яким потрібно замінити:");
		
		try {
			
			String fin = "";
			
			while (true){
				String s;
				s = myR.readLine();
				if (s==null) break;
				
				
				while (s.indexOf(user)>-1){
					int index = s.indexOf(user); 
				
					if (index != -1) { 
						s = s.substring(0, index) + user2 + s.substring(index + user2.length()); 
					} 
				}
				println(s);
				fin = s;
			}
			myR.close();
			
			PrintWriter wr = new PrintWriter(userName);
			wr.println(fin);
			wr.close();
			
		}catch (IOException e) {
			throw new ErrorException(e);
		}
		
	}
	
}
