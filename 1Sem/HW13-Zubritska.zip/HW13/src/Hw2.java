/*
 * Написати програму, що копіює зміст тектового файлу в інший
 *  з розширення ".bak". Назва файлу вводиться користувачем.
 * 
 File: Hw2.java
Author:Zubritska
 * 
 */


import acm.program.*; 
import acm.util.*;

import java.io.*;

public class Hw2 extends ConsoleProgram {
	
	private BufferedReader openFile(String prompt){
		BufferedReader rd = null;
		while (rd == null){
			try{
				String name = readLine(prompt);
				rd = new BufferedReader( new FileReader(name));
			} catch (FileNotFoundException e){
				println("Файл не знайдено");
				
			} catch (IOException e){
				e.printStackTrace();
			}
			
		}
		return rd;
	}
	
	public void run(){
		BufferedReader myR = openFile("Введіть назву файлу: ");
		
		try{
			String userName = readLine("Назвіть новий файл");
			PrintWriter wr = new PrintWriter(new FileWriter(userName+".bak"));
			while (true){
				String s;
				s = myR.readLine();
				if (s==null) break;
				println(s);
				wr.println(s);
			}
			myR.close();
			wr.close();
		}catch (IOException e){
			throw new ErrorException(e);
		}
	}
}
