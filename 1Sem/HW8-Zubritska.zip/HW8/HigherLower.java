/*Гра "Вгадай число"

Одна з найпростіших ігор для двох гравців є "Вгадай число". Перший гравець задумує таємне число в деякому відомому діапазоні, а другий гравець намагається вгадати число. Після кожного намагання вгадати число, перший гравець відповідає «Більше», «Менше» або «Вірно!" . У цьому проекті, ви будете будувати просту інтерактивну програму, де комп'ютер візьме на себе роль першого гравця в той час як ви граєте, як другій гравець.

Ви маєте написати програму, що загадує число в діапазоні від 1 до 100 і очікує відповідей користувача з консолі. Ви маєте рахувати кількість спроб користувача.
File: HigherLower.java
Author:Zubritska
 */

import acm.program.*;
import java.lang.Math;
import acm.util.*;


public class HigherLower extends ConsoleProgram{
	private RandomGenerator rgen = RandomGenerator.getInstance(); 

	public void run(){
		int x= rgen.nextInt(0, 100);
		println("Число загадане.");
		guessingTheNumber(x);
	}
	
	private void guessingTheNumber(int x) {
		int steps=0;
		do {
		int a=readInt();
		if(a==x) {
			steps++;
			println("Вірно!"+" Вам знадобилося "+steps+" спроб.");
			return;
		}
		else {
			if(a>x) {
				steps++;
				println("Менше.");
			}
			else {
				steps++;
				println("Більше.");
			}
		}
		}while(true);
	}
}
