/*Намалювати сонечко з променями.

Кількість променів задається константою.

Промені мають бути розміщені рівномірно.
 * 
 * File: Sun.java
 * Author: Zubritska
 */

import java.awt.Color;
import acm.graphics.*;
import acm.program.*;

public class Sun extends GraphicsProgram{
	private static final double RAYS = 50;
	private static final double PI =3.14;

	public void run(){
		this.setSize(500, 600);
		sky();
		circle();
		rays();
	}
	
	private void circle() {
		GOval sun = new GOval(200,200,100,100);
		sun.setFilled(true);
		sun.setFillColor(Color.orange);
		add(sun);
	}
	
	private void rays() {
		double rayX=400;
		double rayY=250;
		double sin;
		double cos;
		double x=360/RAYS;
		double n;
		for(int i=0; i<RAYS; i++ ) {
			n=i*x;
			if((n<=90)&&(0<n)) {
				//n=n*PI/180;
				sin = 4*n*(180-n)/(40500-n*(180-n));
				//sin = 16*n*(PI-n)/(5*PI*PI-4*n*(PI-n));
				cos = 1- sin*sin;
				rayX=250 + cos*150;
				rayY=250 + sin*150;
			}
			if((n<=180)&&(90<n)) {
				n=n-90;
				//n=n*PI/180;
				sin = 4*n*(180-n)/(40500-n*(180-n));
				//sin = 16*n*(PI-n)/(5*PI*PI-4*n*(PI-n));
				cos = 1- sin*sin;
				rayX=250 - sin*150;
				rayY=250 + cos*150;
			}
			if((n<=270)&&(180<n)) {
				n=n-180;
				//n=n*PI/180;
				sin = 4*n*(180-n)/(40500-n*(180-n));
				//sin = 16*n*(PI-n)/(5*PI*PI-4*n*(PI-n));
				cos = 1- sin*sin;
				rayX=250-cos*150;
				rayY=250-sin*150;
			}
			if((n<=360)&&(270<n)) {
				n=n-270;
				//n=n*PI/180;
				sin = 4*n*(180-n)/(40500-n*(180-n));
				//sin = 16*n*(PI-n)/(5*PI*PI-4*n*(PI-n));
				cos = 1- sin*sin;
				rayX=250 + sin*150;
				rayY=250 - cos*150;
			}
			
			GLine ray = new GLine(250,250,rayX,rayY);
			ray.setColor(Color.orange);
			add(ray);
			
		}
	}
	
	private void sky() {
		GRect sky = new GRect(0,0,500,600);
		sky.setFilled(true);
		sky.setFillColor(Color.cyan);
		add(sky);
	}
}