/*Реалізувати програму з лекції Ханойські вежі.
 *З клавіатури вводиться число дисків на першій голці
 *і голка на яку необхідно перенести диски. Ваша програма
 *має вивести в консоль послідовність дій для перенесення дисків.
 
File: HW7Third.java
Author:Zubritska
 */

import java.awt.Color;
import acm.graphics.*;
import acm.program.*;
import java.lang.Math;

public class HW7Third extends ConsoleProgram{
	
	public void run(){
		//b - final, a - first, c - for help, n - number of disks
		
		int n=readInt("Введіть кількість дисків:");
		//int a=readInt("Введіть номер початкової голки:");
		int a=1;
		int b=readInt("Введіть номер фінальної голки:");
		
		while(b==1)
		{
			b=readInt("Введіть інший номер фінальної голки:");
		}
		
		//int c=readInt("Введіть номер допоміжної голки:");
		int c;
		if(b!=2) {
			c=2;
		}
		else {
			c=3;
		}
		
		hanoi(n,a,b,c);
		
	}
	
	private void hanoi(int n,int a,int b,int c) {
		if(n>1) {
			hanoi(n-1, a, c, b);
			println("з голки "+a+ " на голку "+ b);
			hanoi(n-1, c, b, a);
		}
		else {
			println("з голки "+a+" на голку "+b);
		}
	}
	
}

