/*Програма має рахувати числа Фібоначі і виводити результати на екран у формі:

0 - 0
1 - 1
2 - 1
3 - 2
і так далі
Користувач вводить число яке обмежує значення максимального числа Фібоначі,
що має бути обраховане. Тобто вивід триває поки значення наступного числа
фібоначі не перевищує введене користувачем число.

File: HW7First.java
Author:Zubritska
 */

import acm.program.*;
import java.lang.Math;

public class HW7First extends ConsoleProgram{
	
	public void run(){
		int limitFibonacci=readInt("Введіть ліміт Фібоначчі:");
		int fib=0;
		int i=0;
		do{
			fib = fibonacci( i);
			if(fib > limitFibonacci) {
				break;
			}
			println(i+ " - "+ fib );
			i++;
		}while(true);
		
		
	}
	
	private int fibonacci( int f) {
		if(f == 0) {
			return 0;
		}
		else if(f > 1) {
			return fibonacci(f-1) + fibonacci(f-2);
		}
		else {
			return 1;
		}
	}
}
