/*Намалювати обличчя робота.

Обличчя складається з чотирьох частинок - голова, два ока, і рот

Використати константи HEAD_WIDTH, HEAD_HEIGHT, EYE_RADIUS, MOUTH_WIDTH, MOUTH_HEIGHT

File: HW7Second.java
Author:Zubritska
 */

import java.awt.Color;
import acm.graphics.*;
import acm.program.*;
import java.lang.Math;

public class HW7Second extends GraphicsProgram{
	private static final int WINDOWX=1000;
	private static final int WINDOWY=800;
	private static final int INDENT=40;
	
	private static final int HEAD_WIDTH=500;
	private static final int HEAD_HEIGHT=350;
	private static final int EYE_RADIUS=70;
	private static final int MOUTH_WIDTH=300;
	private static final int MOUTH_HEIGHT=50;
	
	public void run(){
		this.setSize(WINDOWX,WINDOWY);
		
		int xHead=(WINDOWX-HEAD_WIDTH)/2;
		int yHead=((WINDOWY-66)-HEAD_HEIGHT)/2;
		head(xHead,yHead);
		
		//int xEye1=xHead+INDENT;
		int xEye1=xHead+HEAD_WIDTH/4-EYE_RADIUS;
		int yEye1=yHead+INDENT;
		//int xEye2=xHead+HEAD_WIDTH-INDENT-2*EYE_RADIUS;
		int xEye2=xHead+(HEAD_WIDTH/4)*3-EYE_RADIUS;
		eyes(xEye1,yEye1,xEye2);
		
		int xMouth=(WINDOWX-MOUTH_WIDTH)/2;
		int yMouth=yHead+HEAD_HEIGHT-MOUTH_HEIGHT-INDENT;
		mouth(xMouth,yMouth,yEye1);
		
	}
	
	private void head(int xHead, int yHead) {
		GRect head = new GRect(xHead,yHead,HEAD_WIDTH,HEAD_HEIGHT);
		head.setFilled(true);
		head.setFillColor(Color.GRAY);
		add(head);
	}
	
	private void eyes(int xEye1,int yEye1,int xEye2) {
		GOval eye1 = new GOval(xEye1,yEye1,2*EYE_RADIUS,2*EYE_RADIUS);
		eye1.setFilled(true);
		eye1.setFillColor(Color.cyan);
		add(eye1);
		
		GOval eye2 = new GOval(xEye2,yEye1,2*EYE_RADIUS,2*EYE_RADIUS);
		eye2.setFilled(true);
		eye2.setFillColor(Color.cyan);
		add(eye2);
	}
	
	private void mouth(int xMouth,int yMouth,int yEye1) {
		if(yMouth<= yEye1+EYE_RADIUS*2) {
			do {
			yMouth=yMouth+5;
			}while(yMouth<= yEye1+EYE_RADIUS*2);
		GRect mouth = new GRect(xMouth,yMouth,MOUTH_WIDTH,MOUTH_HEIGHT);
		mouth.setFilled(true);
		mouth.setFillColor(Color.yellow);
		add(mouth);
		
		GLine mouthLine=new GLine(xMouth,yMouth+MOUTH_HEIGHT/2,xMouth+MOUTH_WIDTH,yMouth+MOUTH_HEIGHT/2);
		mouthLine.setColor(Color.DARK_GRAY);
		add(mouthLine);
		
		for(int i=0; (xMouth+i*(MOUTH_HEIGHT/2))<=xMouth+MOUTH_WIDTH; i++) {
			GLine mouthLines = new GLine(xMouth+i*(MOUTH_HEIGHT/2),yMouth,xMouth+i*(MOUTH_HEIGHT/2),yMouth+MOUTH_HEIGHT);
			mouthLines.setColor(Color.DARK_GRAY);
			add(mouthLines);
		}
		}
		else {
			
			GRect mouth = new GRect(xMouth,yMouth,MOUTH_WIDTH,MOUTH_HEIGHT);
			mouth.setFilled(true);
			mouth.setFillColor(Color.yellow);
			add(mouth);
			
			GLine mouthLine=new GLine(xMouth,yMouth+MOUTH_HEIGHT/2,xMouth+MOUTH_WIDTH,yMouth+MOUTH_HEIGHT/2);
			mouthLine.setColor(Color.DARK_GRAY);
			add(mouthLine);
			
			for(int i=0; (xMouth+i*(MOUTH_HEIGHT/2))<=xMouth+MOUTH_WIDTH; i++) {
				GLine mouthLines = new GLine(xMouth+i*(MOUTH_HEIGHT/2),yMouth,xMouth+i*(MOUTH_HEIGHT/2),yMouth+MOUTH_HEIGHT);
				mouthLines.setColor(Color.DARK_GRAY);
				add(mouthLines);
			}
			
		}
	}
}
