/*Порахувати кількість входжень заданого користувачем слова в файлі.
 * 
 File: First.java
Author:Zubritska
 * 
 */


import acm.program.*; 
import acm.util.*;
import java.awt.*; 
import java.awt.event.*; 
import java.io.*;
import java.util.*;

public class First extends ConsoleProgram {
	
	private BufferedReader openFile(String prompt){
		BufferedReader rd = null;
		while (rd == null){
			try{
				String name = readLine(prompt);
				rd = new BufferedReader( new FileReader(name));
			} catch (FileNotFoundException e){
				println("Файл не знайдено");
				
			} catch (IOException e){
				e.printStackTrace();
			}
			
		}
		return rd;
	}
	
	public void run() {
		
		BufferedReader myR = openFile("Введіть назву файлу: ");
		
		String userWord = readLine("Введіть шукане слово: ");
		
		int n = 0;
		try{
			while (true){
				String s;
				s = myR.readLine();
				if (s==null) break;
				println(s);
				
				StringTokenizer tokenizer = new StringTokenizer(s,",. -)\t\n\r");
				
				while (tokenizer.hasMoreTokens()){
					String myStr = tokenizer.nextToken();
					
					if(userWord.equalsIgnoreCase(myStr)) {
						n++;
					}
					
				}
			}
			println("Слово "+userWord+" зустрічається "+n+" разів");
			myR.close();
		}catch (IOException e){
			throw new ErrorException(e);
		}
		
	}
}
