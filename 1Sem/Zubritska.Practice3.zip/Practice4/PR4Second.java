import stanford.karel.*;

public class PR4Second extends SuperKarel{

	public void run(){ 
		turnLeft();
		while(true) {
		
		goingUp();
		goingDown();
		findExit();
		if(rightIsClear()) {
			nextLevel();
			}
		else {
			turnRight();
			break;
		}
		}
		
	}

	//going up
private void goingUp() {
	beepCollecting();
}

//going down
private void goingDown() {
	turnAround();
	beepCollecting();
	if(beepersPresent()) {
		pickBeeper();
	}
}

private void findExit() {
	turnAround();
	while(rightIsBlocked()) {
		if(frontIsClear()) {
			move();
		}
		else {
			break;
		}
	}
	
	
}

private void beepCollecting() {
	while(frontIsClear()) {
		if(beepersPresent()) {
			pickBeeper();
		}
		move();
	}
}

private void nextLevel() {
	turnRight();
	move();
	turnLeft();
}
}