import stanford.karel.*;

public class PR4First extends SuperKarel{

	public void run(){
		while(true) {
			goToBeginning();
			goForward();
			findExit();
			if(leftIsClear()) {
			nextLevel();
			}
			else {
				break;
			}
		}
	}
	
	//going to the end of the row picking up beepers on the way
	private void goForward() {
		while(frontIsClear()) {
			if(beepersPresent()) {
				pickBeeper();
			}
			move();
		}
		if(beepersPresent()) {
			pickBeeper();
		}
	}
	
	
	//finding exit to the next level
	private void findExit() {
		turnAround();
		while(leftIsBlocked()) {
			if(frontIsClear()) {
			move();
			}
			else {
				break;
			}
		}
	}
	
	
	//turning
	private void nextLevel() {
		turnLeft();
		move();
		turnRight();
	}
	
	
	//goes to the beginning of the row picking up beepers
	private void goToBeginning() {
		while(frontIsClear()) {
			if(beepersPresent()) {
				pickBeeper();
			}
			move();
		}
		turnAround();
	}
	
}
