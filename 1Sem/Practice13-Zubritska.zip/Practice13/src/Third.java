/*
 * Написати програму, що читає текстову інформацію з файлу і виводить на екран
 * 
 File: Third.java
Author:Zubritska
 * 
 */


import acm.program.*; 
import acm.util.*;
import java.awt.*; 
import java.awt.event.*; 
import java.io.*;

public class Third extends ConsoleProgram {
	
	private BufferedReader myReader(String prompt){
		BufferedReader rd = null;
		while (rd == null){
			try{
				// read file name
				String name = readLine(prompt);
				rd = new BufferedReader( new FileReader(name));
			} catch (FileNotFoundException e){
				println("Файл не знайдено");
				
			} catch (IOException e){
				e.printStackTrace();
			}
			
		}
		return rd;
	}

	public void run() {
		
		BufferedReader myR = myReader("Enter file name:");
		try {
			while (true){
				String s;
				s = myR.readLine();
				if (s==null) break;
				println(s);
			}
			myR.close();
		}catch (IOException e) {
			throw new ErrorException(e);
		}
	}
		
}
