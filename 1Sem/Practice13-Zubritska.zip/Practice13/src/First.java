/*
 * Великі числа при друку прийнято розділяти комами. Так наприклад число один мільйон
 *  при друку має виглядати - 1,000,000. 
 *  Напишіть програму, що на вхід приймає число (саме число, INT),
 *   а на вихід виводить число в наведеному вище форматі.
 *  Числа мають зчитуватися до тих пір, поки користувач не введе 0.
 *  String.valueOf використовувати не можна.
 * 
 File: First.java
Author:Zubritska
 * 
 */


import acm.program.*; 
import acm.graphics.*; 
import java.lang.Math;
import acm.util.*;
import java.awt.*; 
import java.awt.event.*; 

public class First extends ConsoleProgram {
	public void run() {
		int n;
		do {
			n = readInt("Введіть число:");
			
			if(n!=0) {
				String number = Integer.toString(n);
				println(number);
				
				println(convertToNedded(number));
			}
			
		}while(n!=0);
		println("Кінець програми");
		
	}
	
	private String convertToNedded(String number) {
		String subnum= "";
		String finnum= "";
		int j = 0;
		for(int i = number.length()-1; i>=0;i--) {
			j++;
			
			subnum = subnum + number.charAt(i);
			
			if(j==3) {
				subnum = subnum + ',';
				j=0;
			}
		}
		
		for(int i = subnum.length()-1;i>=0;i--) {
			
			finnum = finnum + subnum.charAt(i);
			
		}
		
		return finnum;
	}
	
}
