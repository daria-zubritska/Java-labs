/*
 * Написати клас який реалізує метод, що видаляє заданий символ з стрічки і повертає результат: 
public String removeAllOccurences(String str, char ch);
 * 
 File: Second.java
Author:Zubritska
 * 
 */


import acm.program.*; 
import acm.graphics.*; 
import java.lang.Math;
import acm.util.*;
import java.awt.*; 
import java.awt.event.*; 

public class Second extends ConsoleProgram {
	public void run() {
		
		String str = readLine();
		String cha = readLine();
		
		char ch = cha.charAt(0);
		
		println(removeAllOccurences(str, ch));
		
	}
	
	 public String removeAllOccurences(String str, char ch) {
		 
		 String fin = "";
		 
		 for(int i = 0; i<str.length(); i++) {
			 if(str.charAt(i)!=ch) {
				 fin = fin + str.charAt(i);
			 }
		 }
		 
		 
		 return fin;
	 }
	
}
