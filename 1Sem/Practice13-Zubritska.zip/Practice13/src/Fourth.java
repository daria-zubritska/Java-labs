/*
 * Написати програму, що шукає в тексті
 *  файлу задану фразу і виводить інформацію про її наявність
 * 
 File: Fourth.java
Author:Zubritska
 * 
 */


import acm.program.*; 
import acm.graphics.*; 
import java.lang.Math;
import acm.util.*;
import java.awt.*; 
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException; 

public class Fourth extends ConsoleProgram {
	
	private BufferedReader myReader(String prompt){
		BufferedReader rd = null;
		while (rd == null){
			try{
				// read file name
				String name = readLine(prompt);
				rd = new BufferedReader( new FileReader(name));
			} catch (FileNotFoundException e){
				println("Файл не знайдено");
				
			} catch (IOException e){
				e.printStackTrace();
			}
			
		}
		return rd;
	}
	
	public void run() {
		
		BufferedReader myR = myReader("Enter file name:");
		
		String user = readLine("Введіть слово, яке потрібно прибрати:");
		
		try {
			int k=0;
			while (true){
				String s;
				s = myR.readLine();
				if (s==null) break;
				println(s);
				
				for(int i=0; i<s.length();i++) {
				int index = s.indexOf(user); 
				
				if (index != -1) { 
					s = s.substring(0, index) +  s.substring(index + user.length()); 
					k++;
				} 
				}
				
			}
			println("Слово зустрічається "+ k);
			myR.close();
		}catch (IOException e) {
			throw new ErrorException(e);
		}
		
	}
}
